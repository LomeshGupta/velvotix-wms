"use client";

/** Backwards-compatible exports. New API calls should live in src/services/api. */
export { ApiError, apiFetch, apiFetchSchema, friendlyMessage } from "@/services/api/httpClient";

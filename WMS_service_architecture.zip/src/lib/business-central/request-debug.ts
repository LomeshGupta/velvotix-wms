import "server-only";
import { logger } from "@/lib/telemetry/logger";

/**
 * Development-only visibility for the server-to-server Business Central hop.
 * Never expose an OAuth bearer token, password, cookie, or client secret.
 */
function isBcDebugEnabled(): boolean {
  return process.env.NODE_ENV !== "production" && process.env.WMS_BC_DEBUG_REQUESTS === "true";
}

const SENSITIVE_KEY = /(password|token|secret|authorization|cookie|client.?secret|hash|pin)/i;
const MAX_DEBUG_STRING = 1_200;

function redactValue(value: unknown, depth = 0): unknown {
  if (depth > 8) return "[MAX_DEPTH]";
  if (Array.isArray(value)) return value.map((item) => redactValue(item, depth + 1));
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, item]) => [
        key,
        SENSITIVE_KEY.test(key) ? "[REDACTED]" : redactValue(item, depth + 1),
      ]),
    );
  }
  if (typeof value === "string") {
    const trimmed = value.trim();
    // BC OData actions sometimes return JSON serialized inside `value` as a string.
    // Parse that second layer so sensitive keys still get redacted in optional body logs.
    if (depth < 8 && (trimmed.startsWith("{") || trimmed.startsWith("["))) {
      try {
        return redactValue(JSON.parse(trimmed), depth + 1);
      } catch {
        // It is ordinary text, not a JSON payload.
      }
    }
    if (value.length > MAX_DEBUG_STRING) {
      return `${value.slice(0, MAX_DEBUG_STRING)}…[TRUNCATED]`;
    }
  }
  return value;
}

function safeRequestBody(body: BodyInit | null | undefined): unknown {
  if (body == null) return null;
  if (typeof body !== "string") return `[${Object.prototype.toString.call(body)} omitted]`;
  try {
    return redactValue(JSON.parse(body));
  } catch {
    // Never dump arbitrary form/text bodies: they could contain credentials.
    return body.length ? "[non-JSON body omitted]" : null;
  }
}

function safeHeaders(input: HeadersInit | undefined): Record<string, string> {
  const headers = new Headers(input);
  const safe: Record<string, string> = {};
  headers.forEach((value, key) => {
    safe[key] = SENSITIVE_KEY.test(key) ? "[REDACTED]" : value;
  });
  return safe;
}

export interface BcDebugRequest {
  operation: string;
  url: string;
  method: string;
  headers?: HeadersInit;
  body?: BodyInit | null;
  correlationId?: string;
  attempt?: number;
  userId?: string;
}

export function logBcOutgoingRequest(request: BcDebugRequest): void {
  if (!isBcDebugEnabled()) return;
  logger.info("bc.debug.outgoing_request", {
    operation: request.operation,
    url: request.url,
    method: request.method.toUpperCase(),
    headers: safeHeaders(request.headers),
    body: safeRequestBody(request.body),
    correlationId: request.correlationId,
    retryCount: request.attempt,
    userId: request.userId,
  });
}

export async function logBcOutgoingResponse(input: {
  operation: string;
  url: string;
  method: string;
  response: Response;
  correlationId?: string;
  attempt?: number;
  durationMs: number;
}): Promise<void> {
  if (!isBcDebugEnabled()) return;

  const fields: Record<string, unknown> = {
    operation: input.operation,
    url: input.url,
    method: input.method.toUpperCase(),
    status: input.response.status,
    ok: input.response.ok,
    durationMs: input.durationMs,
    correlationId: input.correlationId,
    retryCount: input.attempt,
  };

  // Response payload logging is opt-in because it may contain business data.
  if (process.env.WMS_BC_DEBUG_RESPONSE_BODY === "true") {
    try {
      const raw = await input.response.clone().text();
      try {
        fields.responseBody = redactValue(JSON.parse(raw));
      } catch {
        fields.responseBody = raw.length ? "[non-JSON response omitted]" : null;
      }
    } catch {
      fields.responseBody = "[response body unavailable]";
    }
  }

  logger.info("bc.debug.outgoing_response", fields);
}

import { apiFetchSchema } from "./httpClient";
import {
  LoginRequestSchema,
  LoginResponseSchema,
  SessionResponseSchema,
  type LoginRequest,
  type LoginResponse,
  type SessionResponse,
} from "./schemas";

/** Authentication endpoints are same-origin Next.js routes, not direct BC calls. */
export async function login(input: LoginRequest): Promise<LoginResponse> {
  const payload = LoginRequestSchema.parse(input);
  return apiFetchSchema("/api/auth/login", LoginResponseSchema, { method: "POST", body: payload });
}

export async function logout(): Promise<{ ok: boolean }> {
  return apiFetchSchema("/api/auth/logout", {
    parse(value: unknown) {
      if (!value || typeof value !== "object" || (value as { ok?: unknown }).ok !== true) {
        throw new Error("Invalid logout response");
      }
      return value as { ok: boolean };
    },
  }, { method: "POST" });
}

export async function getSession(): Promise<SessionResponse> {
  return apiFetchSchema("/api/auth/session", SessionResponseSchema);
}

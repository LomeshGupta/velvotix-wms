import { z } from "zod";

/**
 * Shared WMS API contracts. These schemas are used by the browser service layer
 * to validate payloads and response envelopes. Server routes still validate all
 * input independently; client-side validation is never an authorization boundary.
 */
const optionalText = z.string().nullish().transform((value) => value ?? undefined);
const optionalNumber = z.number().nullish().transform((value) => value ?? undefined);

export const LoginRequestSchema = z.object({
  userId: z.string().trim().min(1).max(64),
  password: z.string().min(1).max(256),
});
export type LoginRequest = z.infer<typeof LoginRequestSchema>;

export const SessionUserSchema = z.object({
  userId: z.string(),
  displayName: z.string(),
  roles: z.array(z.string()).optional().default([]),
  permissions: z.array(z.string()),
  warehouseCodes: z.array(z.string()),
  mustChangePassword: z.boolean().optional(),
}).passthrough();

export const LoginResponseSchema = z.object({
  user: SessionUserSchema,
  csrfToken: z.string(),
}).passthrough();
export type LoginResponse = z.infer<typeof LoginResponseSchema>;

export const SessionResponseSchema = z.object({
  user: z.object({
    userId: z.string(),
    displayName: z.string(),
    permissions: z.array(z.string()),
    warehouseCodes: z.array(z.string()),
  }).passthrough(),
  csrfToken: z.string(),
}).passthrough();
export type SessionResponse = z.infer<typeof SessionResponseSchema>;

export const TransactionRowSchema = z.object({
  id: z.string(),
  operationType: z.string(),
  status: z.string(),
  locationCode: z.string(),
  destinationLocationCode: optionalText,
  wmsUserId: optionalText,
  attemptCount: optionalNumber,
  errorCode: optionalText,
  errorMessage: optionalText,
  resultDocumentNo: optionalText,
  sourceDocumentNo: optionalText,
  requestedAt: optionalText,
  completedAt: optionalText,
}).passthrough();
export type TransactionRow = z.infer<typeof TransactionRowSchema>;

export const DashboardDataSchema = z.object({
  generatedAt: z.string(),
  maxAgeSeconds: z.number(),
  source: z.string(),
  sampleSize: z.number(),
  sampleLimit: z.number(),
  counts: z.record(z.string(), z.number()),
  byType: z.record(z.string(), z.number()),
  oldestWaitingMs: z.number(),
  recent: z.array(TransactionRowSchema),
}).passthrough();
export type DashboardData = z.infer<typeof DashboardDataSchema>;

export const TransactionsResponseSchema = z.object({
  transactions: z.array(TransactionRowSchema),
}).passthrough();
export const TransactionResponseSchema = z.object({
  transaction: TransactionRowSchema,
}).passthrough();

export const WarehouseShipmentSchema = z.object({
  id: z.string(),
  number: z.string(),
  locationCode: z.string(),
  shipmentDate: optionalText,
  assignedUserId: optionalText,
  documentStatus: optionalText,
  status: optionalText,
  externalDocumentNo: optionalText,
}).passthrough();
export type WarehouseShipmentHit = z.infer<typeof WarehouseShipmentSchema>;
export const ShipmentsResponseSchema = z.object({
  shipments: z.array(WarehouseShipmentSchema),
}).passthrough();

export const WarehouseShipmentLineSchema = z.object({
  id: z.string(),
  documentNo: z.string(),
  lineNo: z.number(),
  locationCode: z.string(),
  itemNo: z.string(),
  description: z.string(),
  quantity: z.number(),
  qtyToShip: z.number(),
  qtyOutstanding: z.number(),
  qtyPicked: z.number(),
  unitOfMeasureCode: z.string(),
  binCode: optionalText,
  sourceNo: optionalText,
  sourceLineNo: optionalNumber,
  status: optionalText,
}).passthrough();
export type WarehouseShipmentLineHit = z.infer<typeof WarehouseShipmentLineSchema>;
export const ShipmentLinesResponseSchema = z.object({
  lines: z.array(WarehouseShipmentLineSchema),
}).passthrough();

export const ItemHitSchema = z.object({
  number: z.string(),
  displayName: z.string(),
  baseUnitOfMeasureCode: z.string(),
  blocked: z.boolean(),
  gtin: optionalText,
  inventory: optionalNumber,
}).passthrough();
export type ItemHit = z.infer<typeof ItemHitSchema>;
export const ItemLookupResponseSchema = z.object({ item: ItemHitSchema }).passthrough();
export const ItemsResponseSchema = z.object({ items: z.array(ItemHitSchema) }).passthrough();

const Code = (max: number) => z.string().trim().min(1).max(max).regex(/^[A-Za-z0-9._\-/ ]+$/, "Unexpected characters");
export const ReceiptPayloadSchema = z.object({
  clientKey: z.string().uuid(),
  locationCode: Code(10),
  sourceDocumentNo: Code(20).optional(),
  lines: z.array(z.object({
    itemNo: Code(20),
    quantity: z.number().positive().max(1_000_000),
    unitOfMeasureCode: Code(10).optional(),
    lotNo: Code(50).optional(),
  })).min(1).max(50),
});
export type ReceiptPayload = z.infer<typeof ReceiptPayloadSchema>;

export const WMS_OPERATION_TYPES = [
  "Put-away", "Movement", "Pick", "Pack", "Ship", "Cycle Count", "Adjustment", "Return", "Quality Inspection",
] as const;
export type WmsOperationType = (typeof WMS_OPERATION_TYPES)[number];

const OperationLineSchema = z.object({
  itemNo: Code(20),
  quantity: z.number().positive().max(1_000_000),
  unitOfMeasureCode: Code(10).optional(),
  fromBinCode: z.string().trim().max(20).optional(),
  toBinCode: z.string().trim().max(20).optional(),
  lotNo: z.string().trim().max(50).optional(),
  serialNo: z.string().trim().max(50).optional(),
  expirationDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  sourceLineNo: z.number().int().min(0).max(2_000_000_000).optional(),
  reasonCode: Code(20).optional(),
});

export const WmsOperationPayloadSchema = z.object({
  clientKey: z.string().uuid(),
  operationType: z.enum(WMS_OPERATION_TYPES),
  locationCode: Code(10),
  destinationLocationCode: Code(10).optional(),
  sourceDocumentType: z.string().trim().max(30).optional(),
  sourceDocumentNo: Code(20).optional(),
  reasonCode: Code(20).optional(),
  lines: z.array(OperationLineSchema).min(1).max(100),
}).superRefine((input, ctx) => {
  if (input.operationType === "Movement" && input.lines.some((line) => !line.fromBinCode || !line.toBinCode)) {
    ctx.addIssue({ code: "custom", path: ["lines"], message: "Inventory movement requires a source bin and destination bin on every line" });
  }
  if (input.operationType === "Put-away" && input.lines.some((line) => !line.toBinCode)) {
    ctx.addIssue({ code: "custom", path: ["lines"], message: "Put-away requires a destination bin on every line" });
  }
  if (input.operationType === "Adjustment" && !input.reasonCode && input.lines.some((line) => !line.reasonCode)) {
    ctx.addIssue({ code: "custom", path: ["reasonCode"], message: "An adjustment reason code is required" });
  }
});
export type WmsOperationPayload = z.infer<typeof WmsOperationPayloadSchema>;

export const AcceptedTransactionSchema = z.object({
  transactionId: z.string(),
  status: z.string(),
  duplicate: z.boolean(),
}).passthrough();
export type AcceptedTransaction = z.infer<typeof AcceptedTransactionSchema>;

export const MonitorDataSchema = z.object({
  generatedAt: z.string(),
  mode: z.string(),
  environment: z.string(),
  redis: z.string(),
  scheduler: z.object({
    breaker: z.string(),
    active: z.record(z.string(), z.number()),
    queued: z.record(z.string(), z.number()),
    oldestQueuedMs: z.number(),
    coordinator: z.string(),
  }).passthrough(),
  limits: z.record(z.string(), z.number()),
  metrics: z.object({
    lastSuccessAt: optionalNumber,
    authFailures: z.number(),
    operations: z.record(z.string(), z.object({
      count: z.number(), errors: z.number(), throttled: z.number(), cacheHits: z.number(), deduped: z.number(),
      p50: z.number(), p95: z.number(), p99: z.number(), queueWaitP95: z.number(),
    }).passthrough()),
  }).passthrough(),
}).passthrough();
export type MonitorData = z.infer<typeof MonitorDataSchema>;

import { apiFetchSchema } from "./httpClient";
import {
  AcceptedTransactionSchema,
  WmsOperationPayloadSchema,
  type AcceptedTransaction,
  type WmsOperationPayload,
} from "./schemas";

export async function submitOperation(input: WmsOperationPayload): Promise<AcceptedTransaction> {
  const payload = WmsOperationPayloadSchema.parse(input);
  return apiFetchSchema("/api/wms/operations", AcceptedTransactionSchema, { method: "POST", body: payload });
}

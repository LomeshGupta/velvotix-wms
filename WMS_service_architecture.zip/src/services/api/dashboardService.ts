import { apiFetchSchema } from "./httpClient";
import { DashboardDataSchema, type DashboardData } from "./schemas";

export function getDashboard(signal?: AbortSignal): Promise<DashboardData> {
  return apiFetchSchema("/api/wms/dashboard", DashboardDataSchema, { signal });
}

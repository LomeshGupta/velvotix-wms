import { apiFetchSchema } from "./httpClient";
import {
  ShipmentLinesResponseSchema,
  ShipmentsResponseSchema,
  type WarehouseShipmentHit,
  type WarehouseShipmentLineHit,
} from "./schemas";

export async function getWarehouseShipments(locationCode: string, signal?: AbortSignal): Promise<WarehouseShipmentHit[]> {
  const params = new URLSearchParams({ locationCode });
  const result = await apiFetchSchema(`/api/wms/shipments?${params.toString()}`, ShipmentsResponseSchema, { signal });
  return result.shipments;
}

export async function getWarehouseShipmentLines(input: { locationCode: string; number: string; signal?: AbortSignal }): Promise<WarehouseShipmentLineHit[]> {
  const params = new URLSearchParams({ locationCode: input.locationCode, number: input.number });
  const result = await apiFetchSchema(`/api/wms/shipment-lines?${params.toString()}`, ShipmentLinesResponseSchema, { signal: input.signal });
  return result.lines;
}

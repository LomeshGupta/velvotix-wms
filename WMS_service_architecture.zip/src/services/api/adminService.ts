import { apiFetchSchema } from "./httpClient";
import { MonitorDataSchema, type MonitorData } from "./schemas";

export function getIntegrationMonitor(signal?: AbortSignal): Promise<MonitorData> {
  return apiFetchSchema("/api/wms/admin/monitor", MonitorDataSchema, { signal });
}

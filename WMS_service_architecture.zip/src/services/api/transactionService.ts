import { apiFetchSchema } from "./httpClient";
import {
  TransactionResponseSchema,
  TransactionsResponseSchema,
  type TransactionRow,
} from "./schemas";

export async function listTransactions(input: { status?: string; top?: number; skip?: number; signal?: AbortSignal } = {}): Promise<TransactionRow[]> {
  const params = new URLSearchParams({ top: String(input.top ?? 100) });
  if (input.status) params.set("status", input.status);
  if (input.skip !== undefined) params.set("skip", String(input.skip));
  const result = await apiFetchSchema(`/api/wms/transactions?${params.toString()}`, TransactionsResponseSchema, { signal: input.signal });
  return result.transactions;
}

export async function getTransaction(id: string, signal?: AbortSignal): Promise<TransactionRow> {
  const result = await apiFetchSchema(`/api/wms/transactions/${encodeURIComponent(id)}`, TransactionResponseSchema, { signal });
  return result.transaction;
}

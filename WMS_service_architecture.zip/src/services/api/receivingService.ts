import { apiFetchSchema } from "./httpClient";
import {
  AcceptedTransactionSchema,
  ReceiptPayloadSchema,
  type AcceptedTransaction,
  type ReceiptPayload,
} from "./schemas";

export async function submitReceipt(input: ReceiptPayload): Promise<AcceptedTransaction> {
  const payload = ReceiptPayloadSchema.parse(input);
  return apiFetchSchema("/api/wms/receiving", AcceptedTransactionSchema, { method: "POST", body: payload });
}

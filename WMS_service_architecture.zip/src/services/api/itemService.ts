import { apiFetchSchema } from "./httpClient";
import {
  ItemLookupResponseSchema,
  ItemsResponseSchema,
  type ItemHit,
} from "./schemas";

export async function lookupItem(code: string, signal?: AbortSignal): Promise<ItemHit> {
  const params = new URLSearchParams({ code });
  const result = await apiFetchSchema(`/api/wms/items/lookup?${params.toString()}`, ItemLookupResponseSchema, { signal });
  return result.item;
}

export async function searchItems(input: { search?: string; top?: number; skip?: number; signal?: AbortSignal } = {}): Promise<ItemHit[]> {
  const params = new URLSearchParams();
  params.set("top", String(input.top ?? 50));
  if (input.skip !== undefined) params.set("skip", String(input.skip));
  if (input.search?.trim()) params.set("search", input.search.trim());
  const result = await apiFetchSchema(`/api/wms/items?${params.toString()}`, ItemsResponseSchema, { signal: input.signal });
  return result.items;
}

"use client";

import { useSessionStore } from "@/store/uiStore";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly retryAfterMs?: number,
    public readonly correlationId?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }

  get retryable(): boolean {
    return this.status === 429 || this.status === 503;
  }
}

const FRIENDLY: Record<string, string> = {
  QUEUE_FULL: "The system is busy. Try again in a moment.",
  RATE_LIMITED: "Too many requests. Wait a few seconds and try again.",
  CIRCUIT_OPEN: "Business Central is temporarily unavailable. Try again shortly.",
  TIMEOUT: "Business Central took too long to respond.",
  NETWORK: "Could not reach Business Central. Check the connection and try again.",
  OUTCOME_UNKNOWN: "We could not confirm the result. Check the transaction list before retrying.",
  UNAUTHENTICATED: "Your session has ended. Sign in again.",
  FORBIDDEN: "You do not have permission for this action.",
  ENDPOINT_NOT_ALLOWED: "You do not have access to this location or action.",
  CSRF: "Your session could not be verified. Reload the page and try again.",
  ITEM_NOT_FOUND: "No item matches this code.",
  BC_CONFLICT: "This receipt was already submitted with different contents. Start a new receipt.",
  VALIDATION: "Some details are missing or not valid.",
};

const API_DEBUG = process.env.NODE_ENV !== "production" && process.env.NEXT_PUBLIC_WMS_API_DEBUG === "true";
const SENSITIVE_KEY = /(password|token|secret|authorization|cookie|hash|pin)/i;

type ApiFetchOptions = {
  method?: "GET" | "POST";
  body?: unknown;
  signal?: AbortSignal;
};

function safeDebugValue(value: unknown, depth = 0): unknown {
  if (depth > 8) return "[MAX_DEPTH]";
  if (Array.isArray(value)) {
    const sample = value.slice(0, 20).map((item) => safeDebugValue(item, depth + 1));
    if (value.length > 20) sample.push(`[${value.length - 20} more entries omitted]`);
    return sample;
  }
  if (value && typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>);
    const safeEntries = entries.slice(0, 80).map(([key, item]) => [
      key,
      SENSITIVE_KEY.test(key) ? "[REDACTED]" : safeDebugValue(item, depth + 1),
    ] as const);
    if (entries.length > 80) safeEntries.push(["_omittedKeys", `${entries.length - 80} more keys omitted`] as const);
    return Object.fromEntries(safeEntries);
  }
  if (typeof value === "string" && value.length > 1200) return `${value.slice(0, 1200)}…[TRUNCATED]`;
  return value;
}

function newCorrelationId(): string {
  try {
    return globalThis.crypto.randomUUID();
  } catch {
    return `wms-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  }
}

function debugApi(event: string, details: Record<string, unknown>): void {
  if (API_DEBUG) console.info(`[WMS API] ${event}`, details);
}

export function friendlyMessage(error: unknown): string {
  if (error instanceof ApiError) {
    return FRIENDLY[error.code] ?? "Something went wrong. Try again, and contact an administrator if it continues.";
  }
  return "Something went wrong. Check your connection and try again.";
}

/**
 * Single same-origin transport for browser -> Next.js API requests.
 * Business Central is never called directly from the browser. Use the focused
 * service modules (itemService, transactionService, etc.) instead of fetch().
 */
export async function apiFetch<T>(path: string, init: ApiFetchOptions = {}): Promise<T> {
  const method = init.method ?? "GET";
  const correlationId = newCorrelationId();
  const headers: Record<string, string> = {
    Accept: "application/json",
    "x-correlation-id": correlationId,
  };

  if (init.body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET") {
    const csrf = useSessionStore.getState().csrfToken;
    if (csrf) headers["x-csrf-token"] = csrf;
  }

  const now = () => typeof performance !== "undefined" ? performance.now() : Date.now();
  const startedAt = now();
  debugApi("request", {
    correlationId,
    method,
    path,
    body: init.body === undefined ? undefined : safeDebugValue(init.body),
  });

  let response: Response;
  try {
    response = await fetch(path, {
      method,
      headers,
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
      signal: init.signal,
      credentials: "same-origin",
      cache: "no-store",
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") throw error;
    const durationMs = Math.round(now() - startedAt);
    debugApi("network-error", { correlationId, method, path, durationMs });
    throw new ApiError(0, "NETWORK", "Network error", undefined, correlationId);
  }

  const durationMs = Math.round(now() - startedAt);
  const responseCorrelationId = response.headers.get("x-correlation-id") ?? correlationId;
  debugApi("response", {
    correlationId: responseCorrelationId,
    method,
    path,
    status: response.status,
    ok: response.ok,
    durationMs,
  });

  if (response.ok) {
    const data: unknown = await response.json();
    debugApi("response-body", { correlationId: responseCorrelationId, method, path, body: safeDebugValue(data) });
    return data as T;
  }

  const payload = (await response.json().catch(() => ({}))) as {
    error?: { code?: string; message?: string; correlationId?: string };
    [key: string]: unknown;
  };
  debugApi("error-body", { correlationId: responseCorrelationId, method, path, status: response.status, body: safeDebugValue(payload) });
  const code = payload.error?.code ?? "ERROR";
  if (response.status === 401 && typeof window !== "undefined" && !window.location.pathname.startsWith("/login")) {
    window.location.assign(`/login?next=${encodeURIComponent(window.location.pathname)}`);
  }
  const retryAfter = Number(response.headers.get("retry-after"));
  throw new ApiError(
    response.status,
    code,
    payload.error?.message ?? "Request failed",
    Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : undefined,
    payload.error?.correlationId ?? responseCorrelationId,
  );
}

/** Validate a response body against its endpoint contract before returning it. */
export async function apiFetchSchema<T>(
  path: string,
  schema: { parse: (value: unknown) => T },
  init: ApiFetchOptions = {},
): Promise<T> {
  return schema.parse(await apiFetch<unknown>(path, init));
}

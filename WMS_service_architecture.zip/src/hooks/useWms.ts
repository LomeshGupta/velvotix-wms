"use client";

import { useMutation, useQuery } from "@tanstack/react-query";
import { ApiError } from "@/services/api/httpClient";
import {
  getDashboard,
} from "@/services/api/dashboardService";
import { lookupItem, searchItems } from "@/services/api/itemService";
import { submitOperation } from "@/services/api/operationService";
import { submitReceipt } from "@/services/api/receivingService";
import { getWarehouseShipmentLines, getWarehouseShipments } from "@/services/api/shipmentService";
import { getIntegrationMonitor } from "@/services/api/adminService";
import { getTransaction, listTransactions } from "@/services/api/transactionService";
import type {
  DashboardData,
  ItemHit,
  MonitorData,
  ReceiptPayload,
  TransactionRow,
  WarehouseShipmentHit,
  WarehouseShipmentLineHit,
  WmsOperationPayload,
  WmsOperationType,
} from "@/services/api/schemas";

// Keep existing exports stable for components that import their types from this hook.
export type {
  DashboardData,
  ItemHit,
  MonitorData,
  ReceiptPayload,
  TransactionRow,
  WarehouseShipmentHit,
  WarehouseShipmentLineHit,
  WmsOperationPayload,
  WmsOperationType,
} from "@/services/api/schemas";

const jitter = (ms: number) => Math.round(ms * (0.85 + Math.random() * 0.3));

/** Retry only transient capacity failures. Auth and validation errors are never retried. */
const retryPolicy = (count: number, error: unknown) => count < 2 && error instanceof ApiError && error.retryable;

export const useDashboard = () =>
  useQuery({
    queryKey: ["dashboard"],
    queryFn: ({ signal }) => getDashboard(signal),
    staleTime: 20_000,
    refetchInterval: () => jitter(45_000),
    refetchIntervalInBackground: false,
    retry: retryPolicy,
  });

export const useTransactions = (status?: string) =>
  useQuery({
    queryKey: ["transactions", status ?? "all"],
    queryFn: async ({ signal }) => ({ transactions: await listTransactions({ top: 100, status, signal }) }),
    staleTime: 15_000,
    retry: retryPolicy,
  });

const TERMINAL = new Set(["Completed", "Failed", "Cancelled", "Requires Reconciliation", "Partially Completed"]);
export const isTerminal = (status: string | undefined) => Boolean(status && TERMINAL.has(status));

/** Poll one transaction until terminal status, slowing down for long-running work. */
export const useTransaction = (id: string | null) =>
  useQuery({
    queryKey: ["transaction", id],
    enabled: Boolean(id),
    queryFn: async ({ signal }) => ({ transaction: await getTransaction(id!, signal) }),
    refetchInterval: (query) => {
      if (isTerminal(query.state.data?.status)) return false;
      const count = query.state.dataUpdateCount;
      return jitter(Math.min(8000, 1500 + count * 700));
    },
    retry: retryPolicy,
  });

export const useWarehouseShipments = (locationCode: string) =>
  useQuery({
    queryKey: ["warehouse-shipments", locationCode],
    enabled: Boolean(locationCode),
    queryFn: async ({ signal }) => ({ shipments: await getWarehouseShipments(locationCode, signal) }),
    staleTime: 15_000,
    retry: retryPolicy,
  });

export const useWarehouseShipmentLines = (locationCode: string, number: string, enabled: boolean) =>
  useQuery({
    queryKey: ["warehouse-shipment-lines", locationCode, number],
    enabled: Boolean(locationCode && number && enabled),
    queryFn: async ({ signal }) => ({ lines: await getWarehouseShipmentLines({ locationCode, number, signal }) }),
    staleTime: 15_000,
    retry: retryPolicy,
  });

export const useItemLookup = () =>
  useMutation({ mutationFn: async (code: string) => ({ item: await lookupItem(code) }) });

export const useItemSearch = (search: string) =>
  useQuery({
    queryKey: ["items", search],
    queryFn: async ({ signal }) => ({ items: await searchItems({ top: 50, search, signal }) }),
    staleTime: 60_000,
    retry: retryPolicy,
  });

export const useSubmitReceipt = () =>
  useMutation({ mutationFn: (payload: ReceiptPayload) => submitReceipt(payload) });

export const useSubmitOperation = () =>
  useMutation({ mutationFn: (payload: WmsOperationPayload) => submitOperation(payload) });

export const useMonitor = () =>
  useQuery({
    queryKey: ["monitor"],
    queryFn: ({ signal }) => getIntegrationMonitor(signal),
    refetchInterval: () => jitter(15_000),
    refetchIntervalInBackground: false,
    retry: retryPolicy,
  });

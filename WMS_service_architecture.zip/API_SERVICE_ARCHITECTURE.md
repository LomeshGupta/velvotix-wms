# WMS API service architecture

WMS now follows the easy-to-navigate, domain-service pattern used by the Sales App, adapted to WMS's stricter server-side security model.

## Where to find code

- `src/services/api/httpClient.ts` — one browser-to-Next.js transport, request/response debug logs, correlation IDs, CSRF handling, and safe error handling.
- `src/services/api/schemas.ts` — shared Zod contracts and inferred TypeScript types for payloads and response shapes.
- `src/services/api/authService.ts` — login, logout, and session APIs.
- `src/services/api/dashboardService.ts` — dashboard endpoint.
- `src/services/api/itemService.ts` — item lookup/search.
- `src/services/api/transactionService.ts` — transaction list/detail.
- `src/services/api/shipmentService.ts` — warehouse shipments and lines.
- `src/services/api/receivingService.ts` — receiving submissions.
- `src/services/api/operationService.ts` — put-away, movement, pick, pack, ship, count, adjustment, return, and quality-operation submissions.
- `src/services/api/adminService.ts` — integration monitor.
- `src/services/api/index.ts` — service barrel exports.

`src/hooks/useWms.ts` now coordinates React Query state and calls the focused services; it no longer builds API URLs itself. `src/lib/api-client.ts` remains as a backwards-compatible re-export so existing UI components are not broken.

## Request path

Browser component/hook → `src/services/api/<domain>Service.ts` → `httpClient.ts` → same-origin `/api/...` Next.js route → route/session/permission/CSRF validation → `BcGateway` → Business Central.

Business Central is intentionally **not** called directly from browser service files. The server remains the only place that holds OAuth credentials and can enforce the user's role and warehouse assignment. This is safer than cloning Sales App's generic `/api/bc?path=...` proxy, which would not fit WMS's registry and per-operation authorization model.

## Debugging

Set in `.env.local` and restart Next.js:

```env
NEXT_PUBLIC_WMS_API_DEBUG=true
WMS_BC_DEBUG_REQUESTS=true
WMS_BC_DEBUG_RESPONSE_BODY=false
```

- Browser DevTools → Console: `[WMS API] request`, `response`, and `network-error` events.
- Next.js server terminal: `bc.debug.outgoing_request` and `bc.debug.outgoing_response`.
- The `x-correlation-id` links the local API request to route/gateway logs for that operation.
- Password, token, cookie, authorization, hash, and pin fields are redacted. Response bodies remain off unless explicitly opted in; only enable that option temporarily because BC response data may be business-sensitive.

These flags are development-only for request tracing. The browser debug flag has no effect in production.

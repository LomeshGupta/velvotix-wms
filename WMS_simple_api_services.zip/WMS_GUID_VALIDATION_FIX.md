# WMS Business Central GUID validation fix

## Why login was followed by ZodError

`POST /api/auth/login 200` shows the login route returned successfully. The crash occurred later in `BcSessionStore.fetchRow()`, where the WMS code parsed the `id` returned from the Business Central `sessions.get` operation with `z.string().uuid()`.

Zod's `.uuid()` enforces RFC UUID version/variant bits. Business Central record/company GUIDs can have any hexadecimal value in the corresponding groups, while still being valid GUIDs. For example, the configured company GUID `c6a9170d-f7bb-f111-85be-7ced8d9daf2f` has the `f111` third group and does not pass the strict UUID check, but it matches the GUID shape.

## Changes made

- Added `src/lib/business-central/guid.ts` with a shared `BC_GUID_RE` matching the 8-4-4-4-12 hexadecimal GUID shape.
- Updated `BcSessionStore` to validate BC session record IDs with that shape.
- Updated `BcUserDirectory` to validate BC user record IDs the same way.
- Updated worker claim response IDs and transaction route IDs returned from / passed to BC.
- Updated `config.ts` to accept the BC company GUID shape, without loosening validation for Entra tenant/client IDs or client-generated UUID idempotency keys.

## Apply

Replace the matching files in your WMS source with the files in this ZIP, restart the Next.js development server, clear the old session cookie by logging out or deleting the `wms_sid` cookie in development, and sign in again.

Syntax transpilation passed for 101 TypeScript/TSX files. This is not a full Next.js build; the provided source archive does not include the package manifest and dependencies.

# Velvotix WMS – task-first mobile / iPad UI and Safari camera scanning

This archive contains the `src/` tree from the supplied `wmsd.zip`, with these UI files updated:

- `src/app/(wms)/dashboard/DashboardView.tsx` – big icon-led task tiles, simpler action wording, task status below the tasks.
- `src/components/layout/AppShell.tsx` – compact mobile / tablet bottom navigation below 1200px; full sidebar at 1200px and above.
- `src/components/workbench/OperationWorkbenchView.tsx` – visible 3-step guide, scan-first panel, wider iPad two-column work area, simpler instructions.
- `src/components/scanning/ScanInput.tsx` – a cross-browser ZXing camera decoder, explicit Start camera action, accessible large controls and Safari-specific errors.

No API routes, service functions, permission codes, operation payloads, quantities, document validation, or Business Central submission logic were intentionally changed. Other files in `src/` are included from the supplied source ZIP to make merging straightforward.

## Required scanner dependency

The current source ZIP did not include `package.json` or `package-lock.json`. From the root of your existing WMS project, run:

```bash
npm install @zxing/browser
```

This adds the scanner decoder to both `package.json` and `package-lock.json`. Then run:

```bash
npm run typecheck
npm run build
```

## Test the camera on iPhone Safari

1. Deploy to your HTTPS Render URL, or serve local development over HTTPS.
2. Open the WMS URL in Safari, open a warehouse task, tap **Scan with camera**, then tap **Start camera**.
3. Allow camera access when Safari asks.
4. Hold one barcode inside the amber box. The scan closes when a code is detected.
5. If access was denied earlier, enable Camera permission for that website in Safari settings and reload the page.

**Important:** `http://192.168.1.14:3000` is not a secure context for camera access on the iPhone. Browser camera capture via `getUserMedia()` requires HTTPS (with localhost as a local-development exception), as documented by MDN: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia.

Manual code entry and keyboard-wedge Bluetooth / USB scanners remain available if camera access is unavailable.

# WMS API Services (simple pattern)

The browser-side API structure now follows the service-per-area pattern used by the Sales App:

- `src/services/api/bcRequest.ts` — one shared request helper, correlation IDs, same-origin credentials, CSRF token, safe debug logs, and common errors.
- `src/services/api/authService.ts` — login, logout, session.
- `src/services/api/dashboardService.ts` — dashboard.
- `src/services/api/transactionService.ts` — transaction list and detail.
- `src/services/api/itemService.ts` — item search and lookup.
- `src/services/api/shipmentService.ts` — shipments and shipment lines.
- `src/services/api/receivingService.ts` — receipt submissions.
- `src/services/api/operationService.ts` — warehouse operation submissions.
- `src/services/api/adminService.ts` — integration monitor.
- `src/services/api/schemas.ts` — shared TypeScript response and payload types.

The hooks are only React Query glue and call service functions. UI components call services for login/logout. Existing protected Next.js route handlers and the Business Central gateway are retained, so every route still enforces authentication, permissions, CSRF, warehouse scope, and server-side OAuth. Do not put the OAuth secret or bearer token in a browser service.

## Debugging

Set `NEXT_PUBLIC_WMS_API_DEBUG=true` in `.env.local` and restart Next.js to see request/response details in the browser Console. Sensitive keys (password, token, secret, authorization, cookie, CSRF, session) are redacted.

Set `WMS_BC_DEBUG_REQUESTS=true` to inspect the actual outbound Business Central URL, method, sanitized body/headers and response status in the Next.js server terminal. The matching correlation ID connects the two logs.

Browser Network will still show same-origin `/api/...` URLs. This is intended: the server makes the Business Central request so OAuth secrets and tokens stay server-side.

## Business Central GUID validation fix

Business Central GUIDs use the standard `8-4-4-4-12` hexadecimal shape, but may not follow RFC UUID version/variant bits. WMS therefore uses `src/lib/business-central/guid.ts` for company and record IDs returned by Business Central. Entra tenant/client IDs and client-generated idempotency keys retain strict UUID validation.

This fixes errors such as `ZodError: path ["id"] Invalid UUID` when `sessions.get` returns a valid Business Central GUID that Zod's `.uuid()` rejects. After deploying, restart Next.js and sign in again. Existing malformed session data will fail the GUID-shape check rather than be accepted indiscriminately.

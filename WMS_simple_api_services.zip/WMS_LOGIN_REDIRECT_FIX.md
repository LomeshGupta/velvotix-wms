# WMS login redirect and Business Central endpoint fix

## What changed

- `VWMSAuth_Login` remains the ODataV4 codeunit action.
- After the codeunit verifies credentials, WMS now loads the user record, enabled roles, role permissions, direct permissions, and warehouse assignments from the AL API pages.
- The login response no longer reports empty `roles`, `permissions`, and `warehouseCodes` merely because authentication and profile loading were separated.
- Profile and role-catalog cache keys were versioned to prevent old empty profiles from being reused.
- If Business Central authenticates the password but the user has zero effective permissions, WMS does not create an unusable session. The login screen displays an actionable message.

## Business Central URL formats used

### Codeunit action (authentication)

`{BC_API_BASE_URL}/{tenant}/{environment}/ODataV4/VWMSAuth_Login?company={COMPANY_GUID}`

This matches the published codeunit web service name `VWMSAuth` and the `Login` ServiceEnabled procedure.

### AL API pages in this extension

The objects under `src/API/` use `PageType = API`, so they use the Business Central API route, for example:

`{BC_API_BASE_URL}/{tenant}/{environment}/api/velvotix/wms/v1.0/companies({COMPANY_GUID})/userRoles`

The same pattern is used for `authUsers`, `userWarehouses`, `userPermissions`, `roles`, `rolePermissions`, and `sessions`.

`/ODataV4/Company('CRONUS UK Ltd.')/SalesOrder` is for a normal page published as an OData web service. It is not the URL format for the AL `PageType = API` objects in this extension. Do not change the API-page routes to ODataV4 unless those objects are changed/published as normal OData web services.

## Business Central setup to verify

1. Publish/install the current AL extension version.
2. Ensure the codeunit web service name is `VWMSAuth` and the service is published.
3. Assign the Entra application the `VWMS INTEGRATION` permission set (or an equivalent set that includes the listed API pages and tables).
4. In Business Central, open the WMS user and assign at least one enabled role.
5. Ensure that role has `dashboard:view` and any other required permissions, and that the user has warehouse assignments. Direct user permissions are also supported.
6. Verify the role is enabled and the role-to-permission rows exist.

## Test

- Sign in with a valid WMS user.
- `POST /api/auth/login` should return a profile with the actual assignments.
- If no effective permissions exist, login returns `403 NO_WMS_PERMISSIONS` rather than creating a session that will be redirected back to login.
- If a profile cannot be read after codeunit login, inspect server logs and verify the API page web service/permission set.

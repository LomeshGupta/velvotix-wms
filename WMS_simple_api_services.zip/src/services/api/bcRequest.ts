"use client";

import { useSessionStore } from "@/store/uiStore";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly retryAfterMs?: number,
    public readonly correlationId?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }

  get retryable(): boolean {
    return this.status === 429 || this.status === 503;
  }
}

const FRIENDLY: Record<string, string> = {
  QUEUE_FULL: "The system is busy. Try again in a moment.",
  RATE_LIMITED: "Too many requests. Wait a few seconds and try again.",
  CIRCUIT_OPEN: "Business Central is temporarily unavailable. Try again shortly.",
  TIMEOUT: "Business Central took too long to respond.",
  NETWORK: "Could not reach Business Central. Check the connection and try again.",
  OUTCOME_UNKNOWN: "We could not confirm the result. Check the transaction list before retrying.",
  UNAUTHENTICATED: "Your session has ended. Sign in again.",
  FORBIDDEN: "You do not have permission for this action.",
  ENDPOINT_NOT_ALLOWED: "You do not have access to this location or action.",
  CSRF: "Your session could not be verified. Reload the page and try again.",
  ITEM_NOT_FOUND: "No item matches this code.",
  BC_CONFLICT: "This receipt was already submitted with different contents. Start a new receipt.",
  VALIDATION: "Some details are missing or not valid.",
};

const DEBUG = process.env.NEXT_PUBLIC_WMS_API_DEBUG === "true";
const SENSITIVE_KEY = /(password|token|secret|authorization|cookie|csrf|session|pin|hash)/i;

type JsonRecord = Record<string, unknown>;

function redact(value: unknown, depth = 0): unknown {
  if (depth > 6 || value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map((item) => redact(item, depth + 1));
  const result: JsonRecord = {};
  for (const [key, item] of Object.entries(value as JsonRecord)) {
    result[key] = SENSITIVE_KEY.test(key) ? "[REDACTED]" : redact(item, depth + 1);
  }
  return result;
}

function logRequest(correlationId: string, method: string, url: string, headers: Record<string, string>, body: unknown): void {
  if (!DEBUG) return;
  console.groupCollapsed(`[WMS API] ${method} ${url}`);
  console.log("Correlation ID:", correlationId);
  console.log("Headers:", redact(headers));
  console.log("Request body:", redact(body ?? null));
  console.groupEnd();
}

function logResponse(correlationId: string, method: string, url: string, status: number, body: unknown, durationMs: number): void {
  if (!DEBUG) return;
  console.groupCollapsed(`[WMS API] ${status} ${method} ${url} (${durationMs} ms)`);
  console.log("Correlation ID:", correlationId);
  console.log("Response:", redact(body));
  console.groupEnd();
}

function makeCorrelationId(): string {
  try {
    return globalThis.crypto.randomUUID();
  } catch {
    return `wms-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
  }
}

export function friendlyMessage(error: unknown): string {
  if (error instanceof ApiError) {
    return FRIENDLY[error.code] ?? "Something went wrong. Try again, and contact an administrator if it continues.";
  }
  return "Something went wrong. Check your connection and try again.";
}

export interface BcRequestOptions {
  method?: "GET" | "POST";
  body?: unknown;
  signal?: AbortSignal;
}

/**
 * Shared WMS API transport. Browser calls stay same-origin; the protected Next.js
 * route calls Business Central with server-side credentials. Enable the browser
 * request/response logs with NEXT_PUBLIC_WMS_API_DEBUG=true.
 */
export async function bcRequest<T>(path: string, options: BcRequestOptions = {}): Promise<T> {
  const method = options.method ?? "GET";
  const correlationId = makeCorrelationId();
  const headers: Record<string, string> = {
    Accept: "application/json",
    "x-correlation-id": correlationId,
  };

  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET") {
    const csrf = useSessionStore.getState().csrfToken;
    if (csrf) headers["x-csrf-token"] = csrf;
  }

  const requestUrl = new URL(path, window.location.origin).toString();
  const started = Date.now();
  logRequest(correlationId, method, requestUrl, headers, options.body);

  let response: Response;
  try {
    response = await fetch(path, {
      method,
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      signal: options.signal,
      credentials: "same-origin",
      cache: "no-store",
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") throw error;
    logResponse(correlationId, method, requestUrl, 0, { error: "NETWORK" }, Date.now() - started);
    throw new ApiError(0, "NETWORK", "Network error", undefined, correlationId);
  }

  const rawResponse = await response.text().catch(() => "");
  let payload: unknown = {};
  if (rawResponse) {
    try {
      payload = JSON.parse(rawResponse) as unknown;
    } catch {
      payload = { message: rawResponse.slice(0, 500) };
    }
  }
  const durationMs = Date.now() - started;
  logResponse(correlationId, method, requestUrl, response.status, payload, durationMs);

  if (response.ok) return payload as T;

  const data = payload as { error?: { code?: string; message?: string; correlationId?: string } };
  const code = data.error?.code ?? "ERROR";
  const responseCorrelation = data.error?.correlationId ?? response.headers.get("x-correlation-id") ?? correlationId;

  if (response.status === 401 && typeof window !== "undefined" && !window.location.pathname.startsWith("/login")) {
    window.location.assign(`/login?next=${encodeURIComponent(window.location.pathname)}`);
  }

  const retryAfter = Number(response.headers.get("retry-after"));
  throw new ApiError(
    response.status,
    code,
    data.error?.message ?? "Request failed",
    Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : undefined,
    responseCorrelation,
  );
}

/** Compatibility name for existing imports. */
export const apiFetch = bcRequest;

# WMS simple Business Central login flow

The sign-in path has been kept deliberately small:

1. Browser posts `{ userId, password }` to `/api/auth/login`.
2. Next.js calls the published `VWMSAuth_Login` ODataV4 action using the configured tenant, environment, and company GUID.
3. `BcGateway.invoke()` unwraps the OData response and parses its JSON string in `value`.
4. A session is created only when the action returns `success: true` and `status: "Active"`.
5. After redirecting into WMS, the protected area loads roles, permissions and warehouse assignments separately; these are not part of the codeunit login response.

## Required server settings

Set `WMS_BC_MODE=live`, `BC_TENANT_ID`, `BC_ENV_NAME`, `BC_COMPANY_ID` (the company GUID), `BC_CLIENT_ID`, `BC_CLIENT_SECRET`, and `BC_COMPANY_NAME` as applicable in `.env.local`. Keep all credentials server-side; do not use `NEXT_PUBLIC_` for secrets.

To inspect outbound Business Central requests, temporarily set `WMS_BC_DEBUG_REQUESTS=true` and restart Next.js. The server terminal prints URL, method, headers and body; fields such as password and bearer token are redacted. Disable the flag after debugging.

## Login response handling

The expected OData shape is `{ "value": "{\"success\":true,...}" }`. The gateway parses the string in `value`; the user directory checks `success` and `status`, then the login route creates the session cookie and session record. Invalid credentials do not create a session.

The provided source archive contains the `src/` tree, matching the uploaded WMS source archive; it does not contain a package manifest or dependencies, so a full application build could not be performed in this environment.

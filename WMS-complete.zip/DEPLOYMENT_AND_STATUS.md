# Velvotix WMS – changes, deployment and verification status

## Outbound flow (Create Pick -> Pick -> Pack -> Ship), checked against the real BC source
AL names, namespaces and procedure signatures were verified against the public Business Central base-app source (w1-27). That check found and fixed two compile errors in earlier code (`Whse.-Post Shipment` is in namespace `Microsoft.Warehouse.Document`; Warehouse Entry is in `Microsoft.Warehouse.Ledger`).

| Step | Page | AL handler | What it does in Business Central |
|---|---|---|---|
| Create pick | Outbound > Create pick | `VWMS Handler Create Pick` (50736) | Releases the shipment (`Whse.-Shipment Release`), then runs the standard report `Whse.-Shipment - Create Pick` for the selected lines. Whole open quantity only (BC cannot create partial picks); open quantity = Quantity - Qty. Picked - Pick Qty. |
| Pick | Outbound > Picking | `VWMS Handler Pick` (50730) | Sets Qty. to Handle (full or partial) on the pick lines of that shipment line (Take/Place, or blank action type), then registers with `Whse.-Activity-Register`. Screen offers the quantity on open picks. |
| Pack | Outbound > Packing | `VWMS Handler Pack` (50737) | BC has no standard packing step. Records cumulative packed quantity in new field **WMS Qty. Packed** on the shipment line (cannot exceed picked). |
| Ship | Outbound > Shipping | `VWMS Handler Ship` (50731) | Sets Qty. to Ship (can be lowered), refuses more than picked, and posts with `Whse.-Post Shipment` (ship only, no invoice). If Setup > **Require Packing Before Ship** is on, or the line has packed goods, shipping is limited to packed minus shipped. |

Each step re-checks user, warehouse and permission in AL. Create Pick, Pick: `picking:submit`; Pack: `packing:submit`; Ship: `shipping:submit`. After a task finishes the shipment lists reload.
Not implemented: creating the warehouse shipment from a sales order, release/reopen as separate screens (Create Pick releases automatically), unregistering a pick, ship-and-invoice.

## Inbound flow (Source document -> Warehouse receipt -> Post -> Put-away), checked against the real BC source
Names, namespaces, signatures and enum values were verified against the public Business Central base-app source (w1-27) before writing.

| Step | Page | AL handler | What it does in Business Central |
|---|---|---|---|
| Receive | Inbound > Receiving | `VWMS Handler Receipt` (50738) | **Location requires receive:** finds the open warehouse receipt for the purchase order, or creates it (releases the PO if open, then `Get Source Doc. Inbound.CreateFromPurchOrderHideDialog`). Sets *Qty. to Receive* (partial fine) and posts with `Whse.-Post Receipt`; BC then creates the put-away automatically if the location requires put-away. Also accepts an existing **warehouse receipt** number (including sales-return and transfer receipts created in BC). **Basic location (no receipt):** sets *Qty. to Receive* on the PO lines and posts the receipt only (no invoice) with `Purch.-Post`. |
| Put-away | Inbound > Put-away | `VWMS Handler Put-away` (50739) | Registers a put-away (or inventory put-away) with `Whse.-Activity-Register`: partial quantity, destination bin can be changed (standard bin validation), matching Take lines receive the same total. |

- The Receiving screen asks BC how the location is set up (new *Location Setup API*) and chooses receipt or purchase-order automatically; it explains inventory put-away locations.
- Quantities shown are BC's own: receipt line *Qty. Outstanding*, purchase line *Outstanding Quantity*, put-away line *Qty. Outstanding*.
- Scan-to-receive: lines without a document-line reference fill that item's open lines in order; with a reference the exact line is used.
- Real-world cases covered: full and partial receipts, several receipts for one PO, receipt already created in BC, sales-return/transfer receipts (as warehouse receipts), basic locations, partial and re-binned put-away, repeat submits (no duplicate receipts).
- **Not supported yet (stated, not faked):** assigning lot/serial/expiry while receiving (BC's own tracking check stops posting if tracking is incomplete); over-receipt; splitting one put-away line over several bins; creating inventory put-away documents; direct receive of sales returns/transfers at basic locations; cross-docking; posting the purchase invoice.
- New objects: API pages 50726-50734, codeunits 50738-50739, table extensions 50747-50749 (WMS User ID on Warehouse Receipt, Posted Whse. Receipt and Purch. Rcpt. headers).

## Stock modules: Movement, Adjustment, Cycle Count, Return, Quality Inspection
Every operation except Diagnostic now has a real handler. Stock changes post through the standard **Item Jnl.-Post Line** (`RunWithCheck`, the engine behind the Item Journal), so BC's own checks (availability, bins, blocked items, posting groups, item tracking) still run. The ledger entries carry document no. `WMS<entry no.>` and the WMS User ID.

| Module | AL handler | What it does |
|---|---|---|
| Movement | `VWMS Handler Movement` (50741) | Item reclassification (entry type Transfer): bin to bin, or to another warehouse. Bin-managed locations need the bin on each side. |
| Adjustment | `VWMS Handler Adjustment` (50742) | Positive/Negative Adjmt. Quantity is **signed** (positive adds, negative removes), reason code mandatory and stored on the entry. |
| Cycle Count | `VWMS Handler Cycle Count` (50743) | Quantity = **counted** quantity (0 allowed). BC's quantity is read (bin contents, or item inventory at the location) and only the difference is posted. A matching count posts nothing. Base unit of measure; one line per item and bin. |
| Return | `VWMS Handler Return` (50745) | Same standard flow as Receipt for a **sales return order**: warehouse receipt (created from the return order, put-away follows) or, at a basic location, direct receipt. Receive only, no credit memo. |
| Quality Inspection | `VWMS Handler Quality` (50744) | BC has no inspection document. PASS releases the stock (nothing moves); HOLD/REJECT moves the quantity to the quarantine bin entered on the line. |

Shared helper: `VWMS Item Journal Mgt` (50740). New API pages: 50735 Return Orders, 50736 Return Lines.
**Not supported (stated, not faked):** locations with **directed put-away and pick** (use BC's Warehouse Reclassification / Physical Inventory journals; the handlers refuse with a clear message); lot/serial/expiry entry (BC's tracking check stops posting); scrapping or vendor returns from Quality REJECT; purchase returns; crediting returns.

## Worker: why nothing was processed
The standalone worker (`src/lib/queue/worker-main.ts`) loaded configuration before the env files, so it ran in **mock mode** and never saw Business Central transactions. Fixed with the corrected entry point you supplied (env files are loaded first and it refuses to start in mock mode). The worker now also logs `worker.queue_waiting` with the reason (WMS Enabled / Auto Processing Enabled off, retry backoff) when work waits but nothing is claimed.

## Who did it (WMS username on documents and ledgers)
Field **WMS User ID** (table extensions 50740-50749) on: Warehouse Shipment Header, Posted Whse. Shipment Header, Warehouse Activity Header, Registered Whse. Activity Hdr., Warehouse Entry, Item Ledger Entry. Stamped by `VWMS Stamp` only while a WMS transaction runs (`VWMS Context`); normal BC use is unaffected. Standard "User ID" columns still show the integration account.

## Permissions
- **Catalog by category** (General, Master Data, Inbound, Outbound, Inventory, Counting, Quality and Returns, Integration, Reporting, Administration) containing all 35 codes you listed plus the codes the WMS enforces. Each entry: display name, description, allowed / not allowed, dependency, R/C/M/D/Register/Post flags, **Enforced by WMS** (Yes = checked by code; No = reference only, granting it changes nothing yet).
- Role/User Permissions pages: **Add Permissions...** (pick several from the catalog), **Add Whole Category...**, Category/description columns. No typing codes.
- **Aliases** (old names keep working): OPERATIONS:SUBMIT = TRANSACTIONS:SUBMIT, PICKING:REGISTER = PICKING:SUBMIT, RECEIVING:REGISTER = RECEIVING:SUBMIT, PUTAWAY:REGISTER = PUTAWAY:SUBMIT, INVENTORY:TRANSFER = MOVEMENTS:SUBMIT, RETURNS:PROCESS = RETURNS:SUBMIT.
- **Admin can do everything:** ADMINISTRATION:ADMINISTER implies every permission (AL and web). Role WMS-ADMIN is auto-filled with the whole catalog and re-synced on install/upgrade.
- Standard roles are created automatically (additive): WH-READONLY, WH-RECEIVER, WH-PICKER, WH-SHIPPER, WH-SUPERVISOR, WMS-ADMIN. User List > **Effective Permissions** shows what a user can really do.

## Errors
- **Root cause of the live "Unexpected error":** the web app checked errors with `instanceof GatewayError`, which fails under Next.js (the class is bundled into several server chunks), so every Business Central error became a 500 INTERNAL. Errors are now recognised by shape.
- **Edm.Date error from your log:** an empty expiration date was sent as `""`; it is now omitted.
- The unhandled-error path now logs the real cause server-side (message + stack) with the correlation ID; the browser still gets only the reference.
- Business Central validation text (for example "WMS user X does not have permission ...") is passed to the screen for client errors; server faults stay generic. Response bodies are no longer dumped to the console.
- Missing server configuration returns a clear 503 CONFIG instead of INTERNAL.

## Deployment
1. Confirm object IDs are free: tables 50711; table extensions 50740-50749; pages 50723-50736; codeunits 50730-50745; enum 50705; permission sets 50703-50705.
2. Compile in a sandbox, fix any symbol mismatches, publish. Install/upgrade seeds the catalog, standard roles and the admin role.
3. Re-assign VWMS INTEGRATION to the service principal. Assign standard warehouse posting permission sets for your BC version (verify names).
4. Give each WMS user a role and warehouses; check User List > Effective Permissions.
5. Rebuild Next.js. Run tests: `npx vitest run --config tests/vitest.config.ts`.

## Verification
| Area | Status |
|---|---|
| API routes in mock BC: receiving, pick (partial), ship (partial), duplicate key, forbidden calls naming the permission, wrong warehouse, admin, shipments/lines/bins (54 tests) | PASS |
| Permission alias/admin expansion, quantity rules, BC error extraction | PASS |
| Strict type-check of lib, API routes, features, services, hooks | PASS (only the uninstalled `zustand` package unresolved in my sandbox) |
| AL: bracket balance, duplicate object IDs | PASS |
| Outbound AL symbols vs real BC source (names, namespaces, signatures, keys) | PASS (verified against w1-27 source) |
| Inbound AL symbols vs real BC source | PASS (verified against w1-27 source) |
| Inbound routes, document lists, schema rules, location-driven flow (mock BC) | PASS |
| Item journal / sales return objects vs real BC source | PASS (verified against w1-27 source) |
| Quantity rules, schema rules, return documents, every module through the API (mock BC) | PASS |
| AL compilation | NOT TESTED |
| Pick registration / shipment posting / user stamping in real Business Central | NOT TESTED |
| Full Next.js build, UI | NOT TESTED |
| Root cause of your live INTERNAL error | FIXED and covered by regression tests (class-identity bug plus empty Edm.Date) |

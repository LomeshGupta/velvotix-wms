enum 50700 "VWMS Transaction Status"
{
    Extensible = false;
    Caption = 'WMS Transaction Status';

    value(0; Draft) { Caption = 'Draft'; }
    value(1; Submitted) { Caption = 'Submitted'; }
    value(2; Queued) { Caption = 'Queued'; }
    value(3; Processing) { Caption = 'Processing'; }
    value(4; "Awaiting Approval") { Caption = 'Awaiting Approval'; }
    value(5; Completed) { Caption = 'Completed'; }
    value(6; "Partially Completed") { Caption = 'Partially Completed'; }
    value(7; Failed) { Caption = 'Failed'; }
    value(8; Cancelled) { Caption = 'Cancelled'; }
    value(9; "Requires Reconciliation") { Caption = 'Requires Reconciliation'; }
}

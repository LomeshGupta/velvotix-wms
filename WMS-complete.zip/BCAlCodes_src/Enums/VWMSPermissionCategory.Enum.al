enum 50705 "VWMS Permission Category"
{
    Extensible = false;

    value(0; " ") { Caption = ' '; }
    value(1; General) { Caption = 'General'; }
    value(2; "Master Data") { Caption = 'Master Data'; }
    value(3; Inbound) { Caption = 'Inbound'; }
    value(4; Outbound) { Caption = 'Outbound'; }
    value(5; Inventory) { Caption = 'Inventory'; }
    value(6; Counting) { Caption = 'Counting'; }
    value(7; "Quality and Returns") { Caption = 'Quality and Returns'; }
    value(8; Integration) { Caption = 'Integration'; }
    value(9; Reporting) { Caption = 'Reporting'; }
    value(10; Administration) { Caption = 'Administration'; }
}

enum 50701 "VWMS Operation Type" implements "VWMS Operation Handler"
{
    Extensible = true;
    DefaultImplementation = "VWMS Operation Handler" = "VWMS Handler Not Implemented";
    Caption = 'WMS Operation Type';

    // Diagnostic is the only operation implemented in Phase 3: it exercises the full
    // submit -> claim -> process -> complete path without posting anything.
    value(0; Diagnostic)
    {
        Caption = 'Diagnostic';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Diagnostic";
    }
    // Every operation except Diagnostic now has a real handler.
    value(1; Receipt)
    {
        Caption = 'Receipt';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Receipt";
    }
    value(2; "Put-away")
    {
        Caption = 'Put-away';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Put-away";
    }
    value(3; Movement)
    {
        Caption = 'Movement';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Movement";
    }
    value(4; Pick)
    {
        Caption = 'Pick';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Pick";
    }
    value(5; Pack)
    {
        Caption = 'Pack';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Pack";
    }
    value(6; Ship)
    {
        Caption = 'Ship';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Ship";
    }
    value(7; "Cycle Count")
    {
        Caption = 'Cycle Count';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Cycle Count";
    }
    value(8; Adjustment)
    {
        Caption = 'Adjustment';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Adjustment";
    }
    value(9; Return)
    {
        Caption = 'Return';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Return";
    }
    value(10; "Quality Inspection")
    {
        Caption = 'Quality Inspection';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Quality";
    }
    value(11; "Create Pick")
    {
        Caption = 'Create Pick';
        Implementation = "VWMS Operation Handler" = "VWMS Handler Create Pick";
    }
}

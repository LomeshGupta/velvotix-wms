enum 50702 "VWMS Error Class"
{
    Extensible = false;
    Caption = 'WMS Error Class';

    value(0; None) { Caption = 'None'; }
    value(1; Transient) { Caption = 'Transient'; }
    value(2; Permanent) { Caption = 'Permanent'; }
}

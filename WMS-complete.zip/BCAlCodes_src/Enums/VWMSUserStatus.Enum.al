enum 50704 "VWMS User Status"
{
    Extensible = false;
    Caption = 'WMS User Status';

    value(0; Active) { Caption = 'Active'; }
    value(1; Suspended) { Caption = 'Suspended'; }
    value(2; Deactivated) { Caption = 'Deactivated'; }
}

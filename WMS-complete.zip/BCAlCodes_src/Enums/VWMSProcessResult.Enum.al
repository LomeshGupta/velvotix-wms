enum 50703 "VWMS Process Result"
{
    Extensible = false;
    Caption = 'WMS Process Result';

    value(0; Completed) { Caption = 'Completed'; }
    value(1; "Transient Failure") { Caption = 'Transient Failure'; }
    value(2; "Permanent Failure") { Caption = 'Permanent Failure'; }
    value(3; "Requires Reconciliation") { Caption = 'Requires Reconciliation'; }
}

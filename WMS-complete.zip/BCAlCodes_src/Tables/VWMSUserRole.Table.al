table 50710 "VWMS User Role"
{
    Caption = 'WMS User Role';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "User ID"; Code[50])
        {
            Caption = 'User ID';
            TableRelation = "VWMS User";
        }
        field(2; "Role Code"; Code[30])
        {
            Caption = 'Role Code';
            TableRelation = "VWMS Role";
        }
    }

    keys
    {
        key(PK; "User ID", "Role Code") { Clustered = true; }
    }
}

table 50708 "VWMS Role"
{
    Caption = 'WMS Role';
    DataClassification = CustomerContent;
    LookupPageId = "VWMS Role List";
    DrillDownPageId = "VWMS Role List";

    fields
    {
        field(1; "Role Code"; Code[30]) { Caption = 'Role Code'; }
        field(2; "Role Name"; Text[100]) { Caption = 'Role Name'; }
        field(3; Description; Text[250]) { Caption = 'Description'; }
        field(4; Enabled; Boolean) { Caption = 'Enabled'; InitValue = true; }
    }

    keys
    {
        key(PK; "Role Code") { Clustered = true; }
    }

    trigger OnDelete()
    var
        UserRole: Record "VWMS User Role";
        RolePermission: Record "VWMS Role Permission";
    begin
        UserRole.SetRange("Role Code", "Role Code");
        if not UserRole.IsEmpty() then
            Error('Role %1 is assigned to one or more WMS users. Remove the assignments before deleting it.', "Role Code");

        RolePermission.SetRange("Role Code", "Role Code");
        RolePermission.DeleteAll();
    end;
}

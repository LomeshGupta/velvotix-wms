using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Structure;

table 50700 "VWMS Setup"
{
    Caption = 'WMS Setup';
    DataClassification = CustomerContent;
    LookupPageId = "VWMS Setup Card";

    fields
    {
        field(1; "Primary Key"; Code[10]) { Caption = 'Primary Key'; }
        field(2; "WMS Enabled"; Boolean) { Caption = 'WMS Enabled'; }
        field(3; "Default Location Code"; Code[10])
        {
            Caption = 'Default Location Code';
            TableRelation = Location;

            trigger OnValidate()
            begin
                if "Default Location Code" <> xRec."Default Location Code" then
                    "Default Bin Code" := '';
            end;
        }
        field(4; "Enforce Bins"; Boolean) { Caption = 'Enforce Bins'; }
        field(5; "Auto Processing Enabled"; Boolean)
        {
            Caption = 'Auto Processing Enabled';
            InitValue = true;
        }
        field(6; "Max Attempts"; Integer)
        {
            Caption = 'Max Attempts';
            InitValue = 5;
            MinValue = 1;
            MaxValue = 20;
        }
        field(7; "Lease Seconds"; Integer)
        {
            Caption = 'Worker Lease (seconds)';
            InitValue = 120;
            MinValue = 15;
            MaxValue = 3600;
        }
        field(8; "Retention Days"; Integer)
        {
            Caption = 'Completed Transaction Retention (days)';
            InitValue = 90;
            MinValue = 7;
        }
        field(9; "Audit Enabled"; Boolean)
        {
            Caption = 'Audit Enabled';
            InitValue = true;
        }
        field(10; "Session Idle Minutes"; Integer)
        {
            Caption = 'Session Idle Timeout (minutes)';
            InitValue = 30;
            MinValue = 1;
        }
        field(12; "Default Bin Code"; Code[20])
        {
            Caption = 'Default Bin Code';
            TableRelation = Bin.Code where("Location Code" = field("Default Location Code"));
        }
        field(13; "Require Packing Before Ship"; Boolean)
        {
            Caption = 'Require Packing Before Ship';
            ToolTip = 'When on, a warehouse shipment line can only be shipped up to the quantity confirmed at the packing station.';
        }
        field(11; "Max Failed Logins"; Integer)
        {
            Caption = 'Max Failed Logins Before Lock';
            InitValue = 5;
            MinValue = 3;
        }
    }

    keys
    {
        key(PK; "Primary Key") { Clustered = true; }
    }

    procedure GetSetup(): Record "VWMS Setup"
    var
        Setup: Record "VWMS Setup";
    begin
        if not Setup.Get() then begin
            Setup.Init();
            Setup.Insert();
        end;
        exit(Setup);
    end;
}

using Microsoft.Inventory.Location;

table 50704 "VWMS User"
{
    Caption = 'WMS User';
    DataClassification = EndUserIdentifiableInformation;
    LookupPageId = "VWMS User List";
    DrillDownPageId = "VWMS User List";

    fields
    {
        field(1; "User ID"; Code[50]) { Caption = 'User ID'; }
        field(2; "Display Name"; Text[100]) { Caption = 'Display Name'; }
        field(3; Status; Enum "VWMS User Status") { Caption = 'Status'; }
        // Credentials are administered and verified in Business Central. The web tier can
        // invoke VWMSAuth.Login, but never reads or writes these fields through an API page.
        // Store a salted, iterated SHA-512 hash, never plaintext or reversible Base64.
        field(4; "Password Hash"; Text[250])
        {
            Caption = 'Password Hash';
            DataClassification = EndUserPseudonymousIdentifiers;
            ExtendedDatatype = Masked;
        }
        field(5; "Failed Login Attempts"; Integer) { Caption = 'Failed Login Attempts'; }
        field(6; "Locked Until"; DateTime) { Caption = 'Locked Until'; }
        field(7; "Default Location Code"; Code[10])
        {
            Caption = 'Default Location Code';
            TableRelation = Location;
        }
        field(8; "Supervisor User ID"; Code[50])
        {
            Caption = 'Supervisor User ID';
            TableRelation = "VWMS User";
        }
        field(9; "Last Login At"; DateTime) { Caption = 'Last Login At'; }
        field(10; "Must Change Password"; Boolean) { Caption = 'Must Change Password'; }
        field(11; "Quick Login PIN Hash"; Text[250])
        {
            Caption = 'Quick Login PIN Hash';
            DataClassification = EndUserPseudonymousIdentifiers;
            ExtendedDatatype = Masked;
        }
        field(12; "Password Salt"; Text[50])
        {
            Caption = 'Password Salt';
            DataClassification = EndUserPseudonymousIdentifiers;
            ExtendedDatatype = Masked;
        }
        field(13; "Password Iterations"; Integer)
        {
            Caption = 'Password Iterations';
            DataClassification = SystemMetadata;
            InitValue = 10000;
        }
    }

    keys
    {
        key(PK; "User ID") { Clustered = true; }
    }

    trigger OnDelete()
    var
        Warehouse: Record "VWMS User Warehouse";
        Permission: Record "VWMS User Permission";
        UserRole: Record "VWMS User Role";
        Session: Record "VWMS Session";
    begin
        // Users are deactivated, not deleted, once they have history (audit requirement).
        if Status = Status::Active then
            Error('Deactivate user %1 before deleting.', "User ID");
        Warehouse.SetRange("User ID", "User ID");
        Warehouse.DeleteAll();
        Permission.SetRange("User ID", "User ID");
        Permission.DeleteAll();
        UserRole.SetRange("User ID", "User ID");
        UserRole.DeleteAll();
        Session.SetRange("User ID", "User ID");
        Session.DeleteAll();
    end;

    trigger OnModify()
    var
        Session: Record "VWMS Session";
    begin
        // Suspending or deactivating a user revokes every live session immediately.
        if (Status <> xRec.Status) and (Status <> Status::Active) then begin
            Session.SetRange("User ID", "User ID");
            Session.SetRange(Revoked, false);
            Session.ModifyAll(Revoked, true);
        end;
    end;
}

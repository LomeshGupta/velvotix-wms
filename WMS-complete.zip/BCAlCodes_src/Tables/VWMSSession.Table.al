table 50707 "VWMS Session"
{
    Caption = 'WMS Session';
    DataClassification = EndUserPseudonymousIdentifiers;

    fields
    {
        // sha256 of the opaque session token. The raw token exists only in the user's cookie.
        field(1; "Session Hash"; Code[64]) { Caption = 'Session Hash'; }
        field(2; "User ID"; Code[50])
        {
            Caption = 'User ID';
            TableRelation = "VWMS User";
        }
        field(3; "Created At"; DateTime) { Caption = 'Created At'; }
        field(4; "Last Seen At"; DateTime) { Caption = 'Last Seen At'; }
        field(5; "IP Hash"; Code[64]) { Caption = 'IP Hash'; }
        field(6; "User Agent"; Text[200]) { Caption = 'User Agent'; }
        field(7; Revoked; Boolean) { Caption = 'Revoked'; }
        field(8; "Revoked By"; Code[50]) { Caption = 'Revoked By'; }
    }

    keys
    {
        key(PK; "Session Hash") { Clustered = true; }
        key(UserKey; "User ID", Revoked) { }
    }
}

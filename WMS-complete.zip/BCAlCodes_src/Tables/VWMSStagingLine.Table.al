using Microsoft.Inventory.Item;

table 50702 "VWMS Staging Line"
{
    Caption = 'WMS Staging Line';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Header Entry No."; Integer)
        {
            Caption = 'Header Entry No.';
            TableRelation = "VWMS Staging Header";
        }
        field(2; "Line No."; Integer) { Caption = 'Line No.'; }
        field(3; "Item No."; Code[20])
        {
            Caption = 'Item No.';
            TableRelation = Item;
        }
        field(4; "Variant Code"; Code[10]) { Caption = 'Variant Code'; }
        field(5; "Unit of Measure Code"; Code[10]) { Caption = 'Unit of Measure Code'; }
        field(6; Quantity; Decimal)
        {
            Caption = 'Quantity';
            DecimalPlaces = 0 : 5;
        }
        field(7; "From Bin Code"; Code[20]) { Caption = 'From Bin Code'; }
        field(8; "To Bin Code"; Code[20]) { Caption = 'To Bin Code'; }
        field(9; "Lot No."; Code[50]) { Caption = 'Lot No.'; }
        field(10; "Serial No."; Code[50]) { Caption = 'Serial No.'; }
        field(11; "Expiration Date"; Date) { Caption = 'Expiration Date'; }
        field(12; "Source Line No."; Integer) { Caption = 'Source Line No.'; }
        field(13; "Reason Code"; Code[20]) { Caption = 'Reason Code'; }
        field(14; "Line Completed"; Boolean) { Caption = 'Line Completed'; }
    }

    keys
    {
        // The composite key is what prevents duplicate lines for one transaction.
        key(PK; "Header Entry No.", "Line No.") { Clustered = true; }
    }

    trigger OnInsert()
    var
        Header: Record "VWMS Staging Header";
    begin
        Header.Get("Header Entry No.");
        if not (Header.Status in [Header.Status::Draft, Header.Status::Submitted]) then
            Error('Lines can only be added while the transaction is Draft or Submitted.');
    end;

    trigger OnModify()
    var
        Header: Record "VWMS Staging Header";
    begin
        Header.Get("Header Entry No.");
        if Header.Status in [Header.Status::Completed, Header.Status::Cancelled] then
            Error('Lines of a %1 transaction cannot be changed.', Header.Status);
    end;
}

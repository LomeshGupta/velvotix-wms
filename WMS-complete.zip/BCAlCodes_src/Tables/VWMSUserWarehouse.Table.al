using Microsoft.Inventory.Location;

table 50705 "VWMS User Warehouse"
{
    Caption = 'WMS User Warehouse';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "User ID"; Code[50])
        {
            Caption = 'User ID';
            TableRelation = "VWMS User";
        }
        field(2; "Location Code"; Code[10])
        {
            Caption = 'Location Code';
            TableRelation = Location;
        }
        // Optional bin restriction. Blank means all bins of the location.
        field(3; "Bin Filter"; Code[250]) { Caption = 'Bin Filter'; }
    }

    keys
    {
        key(PK; "User ID", "Location Code") { Clustered = true; }
    }
}

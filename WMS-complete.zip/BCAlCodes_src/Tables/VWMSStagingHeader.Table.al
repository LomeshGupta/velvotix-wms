using Microsoft.Inventory.Location;

table 50701 "VWMS Staging Header"
{
    Caption = 'WMS Staging Header';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Entry No."; Integer)
        {
            Caption = 'Entry No.';
            AutoIncrement = true;
        }
        field(2; "Idempotency Key"; Code[64]) { Caption = 'Idempotency Key'; }
        field(3; "Operation Type"; Enum "VWMS Operation Type") { Caption = 'Operation Type'; }
        field(4; Status; Enum "VWMS Transaction Status") { Caption = 'Status'; }
        field(5; "Location Code"; Code[10])
        {
            Caption = 'Location Code';
            TableRelation = Location;
        }
        field(6; "WMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            TableRelation = "VWMS User";
        }
        field(7; "Source Document Type"; Text[30]) { Caption = 'Source Document Type'; }
        field(8; "Source Document No."; Code[20]) { Caption = 'Source Document No.'; }
        field(9; "Source System Id"; Guid) { Caption = 'Source System Id'; }
        field(10; "Requested At"; DateTime) { Caption = 'Requested At'; }
        field(11; "Processing Started At"; DateTime) { Caption = 'Processing Started At'; }
        field(12; "Completed At"; DateTime) { Caption = 'Completed At'; }
        field(13; "Attempt Count"; Integer) { Caption = 'Attempt Count'; }
        field(14; "Error Class"; Enum "VWMS Error Class") { Caption = 'Error Class'; }
        field(15; "Error Code"; Code[50]) { Caption = 'Error Code'; }
        // Sanitised, user-safe text only. Raw AL error text is logged to the Transaction Log, not here.
        field(16; "Error Message"; Text[250]) { Caption = 'Error Message'; }
        field(17; "Correlation ID"; Code[64]) { Caption = 'Correlation ID'; }
        field(18; "Lease Owner"; Code[50]) { Caption = 'Lease Owner'; }
        field(19; "Lease Expires At"; DateTime) { Caption = 'Lease Expires At'; }
        field(20; "Result Document No."; Code[20]) { Caption = 'Result Document No.'; }
        field(21; "Payload Hash"; Code[64]) { Caption = 'Payload Hash'; }
        field(22; "Retry After"; DateTime) { Caption = 'Retry After'; }
        // True once the Processor began the handler. Distinguishes "worker died before
        // doing anything" (safe to requeue) from "died during processing" (reconcile).
        field(23; "Process Started"; Boolean) { Caption = 'Process Started'; }
        field(24; "Destination Location Code"; Code[10])
        {
            Caption = 'Destination Location Code';
            TableRelation = Location;
        }
    }

    keys
    {
        key(PK; "Entry No.") { Clustered = true; }
        key(IdempotencyKey; "Idempotency Key") { Unique = true; }
        key(Work; Status, "Requested At") { }
        key(UserKey; "WMS User ID", "Requested At") { }
    }

    trigger OnInsert()
    begin
        if "Requested At" = 0DT then
            "Requested At" := CurrentDateTime();
    end;

    trigger OnDelete()
    var
        Line: Record "VWMS Staging Line";
    begin
        // Only never-started or cancelled work may be deleted. Retention cleanup of
        // completed work goes through the Transaction Mgt codeunit.
        if not (Status in [Status::Draft, Status::Cancelled]) then
            Error('A transaction in status %1 cannot be deleted.', Status);
        Line.SetRange("Header Entry No.", "Entry No.");
        Line.DeleteAll();
    end;
}

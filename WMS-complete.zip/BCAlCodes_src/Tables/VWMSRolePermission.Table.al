table 50709 "VWMS Role Permission"
{
    Caption = 'WMS Role Permission';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Role Code"; Code[30])
        {
            Caption = 'Role Code';
            TableRelation = "VWMS Role";
        }
        // Lowercase module:action convention in the web tier; BC Code fields compare case-insensitively.
        field(2; "Permission Code"; Code[50])
        {
            Caption = 'Permission Code';
            TableRelation = "VWMS Permission Def.";
            ValidateTableRelation = true;
        }
    }

    keys
    {
        key(PK; "Role Code", "Permission Code") { Clustered = true; }
    }
}

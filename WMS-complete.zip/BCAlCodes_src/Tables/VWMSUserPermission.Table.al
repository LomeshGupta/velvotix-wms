table 50706 "VWMS User Permission"
{
    Caption = 'WMS User Permission';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "User ID"; Code[50])
        {
            Caption = 'User ID';
            TableRelation = "VWMS User";
        }
        // Format "module:action", e.g. "transactions:submit". Mirrors the Next.js permission strings.
        field(2; "Permission Code"; Code[50])
        {
            Caption = 'Permission Code';
            TableRelation = "VWMS Permission Def.";
            ValidateTableRelation = true;
        }
    }

    keys
    {
        key(PK; "User ID", "Permission Code") { Clustered = true; }
    }
}

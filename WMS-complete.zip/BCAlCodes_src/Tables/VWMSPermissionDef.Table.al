/// Catalog of the permission codes the WMS actually enforces (Next.js route layer and AL
/// Authorization codeunit). It is the lookup source for role/user permission assignment, so
/// administrators pick a code instead of typing it. Codes come from the enforcement code, not invention.
table 50711 "VWMS Permission Def."
{
    Caption = 'WMS Permission Definition';
    DataClassification = SystemMetadata;
    LookupPageId = "VWMS Permission Defs";
    DrillDownPageId = "VWMS Permission Defs";

    fields
    {
        field(1; "Permission Code"; Code[50]) { Caption = 'Permission Code'; }
        field(2; "Display Name"; Text[80]) { Caption = 'Display Name'; }
        field(3; Description; Text[250]) { Caption = 'Description'; }
        field(4; "Allowed Operations"; Text[250]) { Caption = 'Allowed Operations'; }
        field(5; "Not Allowed"; Text[250]) { Caption = 'Not Allowed'; }
        field(6; "Depends On"; Code[50]) { Caption = 'Depends On'; }
        field(7; "Can Read"; Boolean) { Caption = 'Read'; }
        field(8; "Can Create"; Boolean) { Caption = 'Create'; }
        field(9; "Can Modify"; Boolean) { Caption = 'Modify'; }
        field(10; "Can Delete"; Boolean) { Caption = 'Delete'; }
        field(11; "Can Register"; Boolean) { Caption = 'Register'; }
        field(12; "Can Post"; Boolean) { Caption = 'Post'; }
        field(13; Category; Enum "VWMS Permission Category") { Caption = 'Category'; }
        field(14; Enforced; Boolean)
        {
            Caption = 'Enforced by WMS';
            ToolTip = 'Yes = the WMS checks this exact code (or an alias) before an operation. No = catalog/reference entry; granting it changes nothing yet.';
        }
        field(15; "Also Accepted As"; Text[100])
        {
            Caption = 'Also Accepted As';
            ToolTip = 'Alternative codes that count as this permission, so older assignments keep working.';
        }
    }

    keys
    {
        key(PK; "Permission Code") { Clustered = true; }
        key(ByCategory; Category, "Permission Code") { }
    }
}

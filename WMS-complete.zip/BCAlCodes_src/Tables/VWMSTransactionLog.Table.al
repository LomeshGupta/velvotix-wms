table 50703 "VWMS Transaction Log"
{
    Caption = 'WMS Transaction Log';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Entry No."; Integer)
        {
            Caption = 'Entry No.';
            AutoIncrement = true;
        }
        field(2; "Transaction Entry No."; Integer) { Caption = 'Transaction Entry No.'; }
        field(3; "Logged At"; DateTime) { Caption = 'Logged At'; }
        field(4; "Event Name"; Text[50]) { Caption = 'Event Name'; }
        field(5; "From Status"; Enum "VWMS Transaction Status") { Caption = 'From Status'; }
        field(6; "To Status"; Enum "VWMS Transaction Status") { Caption = 'To Status'; }
        field(7; "Actor ID"; Code[50]) { Caption = 'Actor ID'; }
        field(8; "Message Text"; Text[250]) { Caption = 'Message Text'; }
        field(9; "Correlation ID"; Code[64]) { Caption = 'Correlation ID'; }
    }

    keys
    {
        key(PK; "Entry No.") { Clustered = true; }
        key(Tx; "Transaction Entry No.", "Logged At") { }
    }

    trigger OnInsert()
    begin
        if "Logged At" = 0DT then
            "Logged At" := CurrentDateTime();
    end;

    // The audit trail is append-only.
    trigger OnModify()
    begin
        Error('Transaction log entries cannot be changed.');
    end;

    trigger OnDelete()
    begin
        Error('Transaction log entries cannot be deleted.');
    end;
}

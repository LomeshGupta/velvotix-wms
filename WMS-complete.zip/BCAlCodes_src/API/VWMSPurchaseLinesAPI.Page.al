using Microsoft.Purchases.Document;
/// Read-only lookup for the WMS web app. VWMS Purchase Lines API
page 50734 "VWMS Purchase Lines API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'purchaseOrderLine';
    EntitySetName = 'purchaseOrderLines';
    SourceTable = "Purchase Line";
    SourceTableView = where("Document Type" = const(Order), Type = const(Item));
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Purchase Line" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(documentNo; Rec."Document No.") { Caption = 'Document No.'; }
                field(lineNo; Rec."Line No.") { Caption = 'Line No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(itemNo; Rec."No.") { Caption = 'Item No.'; }
                field(description; Rec.Description) { Caption = 'Description'; }
                field(unitOfMeasureCode; Rec."Unit of Measure Code") { Caption = 'Unit of Measure Code'; }
                field(quantity; Rec.Quantity) { Caption = 'Quantity'; }
                field(qtyToReceive; Rec."Qty. to Receive") { Caption = 'Qty. to Receive'; }
                field(quantityReceived; Rec."Quantity Received") { Caption = 'Quantity Received'; }
                field(outstandingQuantity; Rec."Outstanding Quantity") { Caption = 'Outstanding Quantity'; }
            }
        }
    }
}

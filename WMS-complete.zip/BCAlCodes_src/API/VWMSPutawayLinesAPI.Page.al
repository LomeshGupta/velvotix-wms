using Microsoft.Warehouse.Activity;
/// Read-only lookup for the WMS web app. VWMS Put-away Lines API
page 50731 "VWMS Put-away Lines API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'putawayLine';
    EntitySetName = 'putawayLines';
    SourceTable = "Warehouse Activity Line";
    SourceTableView = where("Activity Type" = filter("Put-away" | "Invt. Put-away"), "Action Type" = filter(" " | Place));
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Warehouse Activity Line" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(activityNo; Rec."No.") { Caption = 'No.'; }
                field(lineNo; Rec."Line No.") { Caption = 'Line No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(itemNo; Rec."Item No.") { Caption = 'Item No.'; }
                field(description; Rec.Description) { Caption = 'Description'; }
                field(unitOfMeasureCode; Rec."Unit of Measure Code") { Caption = 'Unit of Measure Code'; }
                field(binCode; Rec."Bin Code") { Caption = 'Bin Code'; }
                field(zoneCode; Rec."Zone Code") { Caption = 'Zone Code'; }
                field(quantity; Rec.Quantity) { Caption = 'Quantity'; }
                field(qtyOutstanding; Rec."Qty. Outstanding") { Caption = 'Qty. Outstanding'; }
                field(qtyToHandle; Rec."Qty. to Handle") { Caption = 'Qty. to Handle'; }
                field(sourceNo; Rec."Source No.") { Caption = 'Source No.'; }
                field(whseDocumentNo; Rec."Whse. Document No.") { Caption = 'Whse. Document No.'; }
            }
        }
    }
}

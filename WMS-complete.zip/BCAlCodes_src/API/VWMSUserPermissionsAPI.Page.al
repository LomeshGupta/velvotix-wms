page 50715 "VWMS User Permissions API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'userPermission';
    EntitySetName = 'userPermissions';
    SourceTable = "VWMS User Permission";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(userId; Rec."User ID") { Caption = 'User Id'; }
                field(permissionCode; Rec."Permission Code") { Caption = 'Permission Code'; }
            }
        }
    }
}

page 50712 "VWMS Transaction Logs API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'transactionLog';
    EntitySetName = 'transactionLogs';
    SourceTable = "VWMS Transaction Log";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(transactionEntryNo; Rec."Transaction Entry No.") { Caption = 'Transaction Entry No.'; }
                field(loggedAt; Rec."Logged At") { Caption = 'Logged At'; }
                field(eventName; Rec."Event Name") { Caption = 'Event Name'; }
                field(fromStatus; Rec."From Status") { Caption = 'From Status'; }
                field(toStatus; Rec."To Status") { Caption = 'To Status'; }
                field(actorId; Rec."Actor ID") { Caption = 'Actor Id'; }
                field(messageText; Rec."Message Text") { Caption = 'Message Text'; }
                field(correlationId; Rec."Correlation ID") { Caption = 'Correlation Id'; }
            }
        }
    }
}

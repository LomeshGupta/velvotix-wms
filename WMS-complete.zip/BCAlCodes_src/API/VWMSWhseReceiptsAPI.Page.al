using Microsoft.Warehouse.Document;
/// Read-only lookup for the WMS web app. VWMS Whse Receipts API
page 50726 "VWMS Whse Receipts API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'warehouseReceipt';
    EntitySetName = 'warehouseReceipts';
    SourceTable = "Warehouse Receipt Header";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Warehouse Receipt Header" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(number; Rec."No.") { Caption = 'No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(assignedUserId; Rec."Assigned User ID") { Caption = 'Assigned User ID'; }
                field(postingDate; Rec."Posting Date") { Caption = 'Posting Date'; }
                field(vendorShipmentNo; Rec."Vendor Shipment No.") { Caption = 'Vendor Shipment No.'; }
            }
        }
    }
}

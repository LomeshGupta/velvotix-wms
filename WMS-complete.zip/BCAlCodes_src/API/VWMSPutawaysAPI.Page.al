using Microsoft.Warehouse.Activity;
/// Read-only lookup for the WMS web app. VWMS Put-aways API
page 50729 "VWMS Put-aways API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'putaway';
    EntitySetName = 'putaways';
    SourceTable = "Warehouse Activity Header";
    SourceTableView = where(Type = filter("Put-away" | "Invt. Put-away"));
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Warehouse Activity Header" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(number; Rec."No.") { Caption = 'No.'; }
                field(type; Rec.Type) { Caption = 'Type'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(assignedUserId; Rec."Assigned User ID") { Caption = 'Assigned User ID'; }
            }
        }
    }
}

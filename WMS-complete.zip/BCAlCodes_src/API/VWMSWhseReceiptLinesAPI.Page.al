using Microsoft.Warehouse.Document;
/// Read-only lookup for the WMS web app. VWMS Whse Receipt Lines API
page 50727 "VWMS Whse Receipt Lines API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'warehouseReceiptLine';
    EntitySetName = 'warehouseReceiptLines';
    SourceTable = "Warehouse Receipt Line";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Warehouse Receipt Line" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(documentNo; Rec."No.") { Caption = 'No.'; }
                field(lineNo; Rec."Line No.") { Caption = 'Line No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(itemNo; Rec."Item No.") { Caption = 'Item No.'; }
                field(description; Rec.Description) { Caption = 'Description'; }
                field(unitOfMeasureCode; Rec."Unit of Measure Code") { Caption = 'Unit of Measure Code'; }
                field(binCode; Rec."Bin Code") { Caption = 'Bin Code'; }
                field(zoneCode; Rec."Zone Code") { Caption = 'Zone Code'; }
                field(quantity; Rec.Quantity) { Caption = 'Quantity'; }
                field(qtyToReceive; Rec."Qty. to Receive") { Caption = 'Qty. to Receive'; }
                field(qtyOutstanding; Rec."Qty. Outstanding") { Caption = 'Qty. Outstanding'; }
                field(qtyReceived; Rec."Qty. Received") { Caption = 'Qty. Received'; }
                field(sourceNo; Rec."Source No.") { Caption = 'Source No.'; }
                field(sourceLineNo; Rec."Source Line No.") { Caption = 'Source Line No.'; }
            }
        }
    }
}

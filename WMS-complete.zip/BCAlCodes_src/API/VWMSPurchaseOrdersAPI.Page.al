using Microsoft.Purchases.Document;
/// Read-only lookup for the WMS web app. VWMS Purchase Orders API
page 50733 "VWMS Purchase Orders API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'purchaseOrder';
    EntitySetName = 'purchaseOrders';
    SourceTable = "Purchase Header";
    SourceTableView = where("Document Type" = const(Order));
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Purchase Header" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(number; Rec."No.") { Caption = 'No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(vendorNo; Rec."Buy-from Vendor No.") { Caption = 'Vendor No.'; }
                field(vendorName; Rec."Buy-from Vendor Name") { Caption = 'Vendor Name'; }
                field(status; Rec.Status) { Caption = 'Status'; }
                field(expectedReceiptDate; Rec."Expected Receipt Date") { Caption = 'Expected Receipt Date'; }
            }
        }
    }
}

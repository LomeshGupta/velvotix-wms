/// Role-to-permission map consumed by the WMS server. Read-only through the API.
page 50718 "VWMS Role Permissions API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'rolePermission';
    EntitySetName = 'rolePermissions';
    SourceTable = "VWMS Role Permission";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(roleCode; Rec."Role Code") { Caption = 'Role Code'; Editable = false; }
                field(permissionCode; Rec."Permission Code") { Caption = 'Permission Code'; Editable = false; }
            }
        }
    }
}

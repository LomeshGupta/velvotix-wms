page 50716 "VWMS Sessions API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'session';
    EntitySetName = 'sessions';
    SourceTable = "VWMS Session";
    ODataKeyFields = SystemId;
    DelayedInsert = true;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(sessionHash; Rec."Session Hash") { Caption = 'Session Hash'; }
                field(userId; Rec."User ID") { Caption = 'User Id'; }
                field(createdAt; Rec."Created At") { Caption = 'Created At'; }
                field(lastSeenAt; Rec."Last Seen At") { Caption = 'Last Seen At'; }
                field(ipHash; Rec."IP Hash") { Caption = 'IP Hash'; }
                field(userAgent; Rec."User Agent") { Caption = 'User Agent'; }
                field(revoked; Rec.Revoked) { Caption = 'Revoked'; }
                field(revokedBy; Rec."Revoked By") { Caption = 'Revoked By'; }
            }
        }
    }
}

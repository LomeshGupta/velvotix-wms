page 50711 "VWMS Transaction Lines API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'line';
    EntitySetName = 'lines';
    SourceTable = "VWMS Staging Line";
    ODataKeyFields = SystemId;
    DelayedInsert = true;
    DeleteAllowed = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(headerEntryNo; Rec."Header Entry No.") { Caption = 'Header Entry No.'; }
                field(lineNo; Rec."Line No.") { Caption = 'Line No.'; }
                field(itemNo; Rec."Item No.") { Caption = 'Item No.'; }
                field(variantCode; Rec."Variant Code") { Caption = 'Variant Code'; }
                field(unitOfMeasureCode; Rec."Unit of Measure Code") { Caption = 'Unit of Measure Code'; }
                field(quantity; Rec.Quantity) { Caption = 'Quantity'; }
                field(fromBinCode; Rec."From Bin Code") { Caption = 'From Bin Code'; }
                field(toBinCode; Rec."To Bin Code") { Caption = 'To Bin Code'; }
                field(lotNo; Rec."Lot No.") { Caption = 'Lot No.'; }
                field(serialNo; Rec."Serial No.") { Caption = 'Serial No.'; }
                field(expirationDate; Rec."Expiration Date") { Caption = 'Expiration Date'; }
                field(sourceLineNo; Rec."Source Line No.") { Caption = 'Source Line No.'; }
                field(reasonCode; Rec."Reason Code") { Caption = 'Reason Code'; }
                field(lineCompleted; Rec."Line Completed") { Caption = 'Line Completed'; Editable = false; }
            }
        }
    }
}

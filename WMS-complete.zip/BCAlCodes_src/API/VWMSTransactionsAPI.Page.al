/// POST creates a durable Submitted transaction (with optional deep-inserted lines) in ONE
/// database transaction, so the worker can never see a header without its lines.
/// Status and processing fields are read-only: only the state machine changes them.
/// Enum values use OData-escaped names (for example "Requires_x0020_Reconciliation").
page 50710 "VWMS Transactions API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'transaction';
    EntitySetName = 'transactions';
    SourceTable = "VWMS Staging Header";
    ODataKeyFields = SystemId;
    DelayedInsert = true;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(idempotencyKey; Rec."Idempotency Key") { Caption = 'Idempotency Key'; }
                field(operationType; Rec."Operation Type") { Caption = 'Operation Type'; }
                field(status; Rec.Status) { Caption = 'Status'; Editable = false; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(destinationLocationCode; Rec."Destination Location Code") { Caption = 'Destination Location Code'; }
                field(wmsUserId; Rec."WMS User ID") { Caption = 'WMS User ID'; }
                field(sourceDocumentType; Rec."Source Document Type") { Caption = 'Source Document Type'; }
                field(sourceDocumentNo; Rec."Source Document No.") { Caption = 'Source Document No.'; }
                field(sourceSystemId; Rec."Source System Id") { Caption = 'Source System Id'; }
                field(correlationId; Rec."Correlation ID") { Caption = 'Correlation Id'; }
                field(payloadHash; Rec."Payload Hash") { Caption = 'Payload Hash'; }
                field(attemptCount; Rec."Attempt Count") { Caption = 'Attempt Count'; Editable = false; }
                field(errorClass; Rec."Error Class") { Caption = 'Error Class'; Editable = false; }
                field(errorCode; Rec."Error Code") { Caption = 'Error Code'; Editable = false; }
                field(errorMessage; Rec."Error Message") { Caption = 'Error Message'; Editable = false; }
                field(resultDocumentNo; Rec."Result Document No.") { Caption = 'Result Document No.'; Editable = false; }
                field(requestedAt; Rec."Requested At") { Caption = 'Requested At'; Editable = false; }
                field(processingStartedAt; Rec."Processing Started At") { Caption = 'Processing Started At'; Editable = false; }
                field(completedAt; Rec."Completed At") { Caption = 'Completed At'; Editable = false; }
                part(lines; "VWMS Transaction Lines API")
                {
                    EntityName = 'line';
                    EntitySetName = 'lines';
                    SubPageLink = "Header Entry No." = field("Entry No.");
                }
            }
        }
    }

    var
        TransactionMgt: Codeunit "VWMS Transaction Mgt";

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    begin
        TransactionMgt.PrepareSubmission(Rec);
        Rec.Insert(true);
        TransactionMgt.LogSubmitted(Rec);
        exit(false); // already inserted above; prevents a second insert
    end;
}

namespace Microsoft.Warehouse.Structure;

/// Read-only bin lookup for the WMS web app (bin validation and suggestions, filtered by location).
page 50724 "VWMS Bins API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'bin';
    EntitySetName = 'bins';
    SourceTable = Bin;
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata Bin = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(code; Rec.Code) { Caption = 'Code'; }
                field(description; Rec.Description) { Caption = 'Description'; }
                field(zoneCode; Rec."Zone Code") { Caption = 'Zone Code'; }
            }
        }
    }
}

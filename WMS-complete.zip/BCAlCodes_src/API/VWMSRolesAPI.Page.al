/// Role catalog consumed by the WMS server. Role administration remains in Business Central.
page 50717 "VWMS Roles API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'role';
    EntitySetName = 'roles';
    SourceTable = "VWMS Role";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(roleCode; Rec."Role Code") { Caption = 'Role Code'; Editable = false; }
                field(roleName; Rec."Role Name") { Caption = 'Role Name'; Editable = false; }
                field(description; Rec.Description) { Caption = 'Description'; Editable = false; }
                field(enabled; Rec.Enabled) { Caption = 'Enabled'; Editable = false; }
            }
        }
    }
}

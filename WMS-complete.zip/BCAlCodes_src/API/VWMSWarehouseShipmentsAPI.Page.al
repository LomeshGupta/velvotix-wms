namespace Microsoft.Warehouse.Document;

/// Read-only WMS work queue over base Business Central warehouse shipment headers.
/// Shipment posting remains the responsibility of the base BC warehouse posting pipeline.
page 50720 "VWMS Warehouse Shipments API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'warehouseShipment';
    EntitySetName = 'warehouseShipments';
    SourceTable = "Warehouse Shipment Header";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Warehouse Shipment Header" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(number; Rec."No.") { Caption = 'No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(shipmentDate; Rec."Shipment Date") { Caption = 'Shipment Date'; }
                field(assignedUserId; Rec."Assigned User ID") { Caption = 'Assigned User Id'; }
                field(documentStatus; Rec."Document Status") { Caption = 'Document Status'; }
                field(status; Rec.Status) { Caption = 'Status'; }
                field(externalDocumentNo; Rec."External Document No.") { Caption = 'External Document No.'; }
            }
        }
    }
}

/// Read-only user metadata for the server after VWMSAuth.Login succeeds.
/// Password hash, salt, and iteration count are never exposed through an API page.
page 50713 "VWMS Auth Users API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'authUser';
    EntitySetName = 'authUsers';
    SourceTable = "VWMS User";
    ODataKeyFields = SystemId;
    DelayedInsert = true;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(userId; Rec."User ID") { Caption = 'User Id'; Editable = false; }
                field(displayName; Rec."Display Name") { Caption = 'Display Name'; Editable = false; }
                field(status; Rec.Status) { Caption = 'Status'; Editable = false; }
                field(mustChangePassword; Rec."Must Change Password") { Caption = 'Must Change Password'; Editable = false; }
                field(failedLoginAttempts; Rec."Failed Login Attempts") { Caption = 'Failed Login Attempts'; Editable = false; }
                field(lockedUntil; Rec."Locked Until") { Caption = 'Locked Until'; Editable = false; }
                field(lastLoginAt; Rec."Last Login At") { Caption = 'Last Login At'; Editable = false; }
                field(defaultLocationCode; Rec."Default Location Code") { Caption = 'Default Location Code'; Editable = false; }
            }
        }
    }
}

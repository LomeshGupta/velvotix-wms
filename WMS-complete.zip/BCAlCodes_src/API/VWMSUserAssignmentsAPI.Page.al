page 50714 "VWMS User Warehouses API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'userWarehouse';
    EntitySetName = 'userWarehouses';
    SourceTable = "VWMS User Warehouse";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(userId; Rec."User ID") { Caption = 'User Id'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(binFilter; Rec."Bin Filter") { Caption = 'Bin Filter'; }
            }
        }
    }
}

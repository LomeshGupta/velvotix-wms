using Microsoft.Inventory.Location;
/// Read-only lookup for the WMS web app. VWMS Location Setup API
page 50732 "VWMS Location Setup API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'locationSetup';
    EntitySetName = 'locationSetups';
    SourceTable = Location;
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata Location = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(code; Rec.Code) { Caption = 'Code'; }
                field(name; Rec.Name) { Caption = 'Name'; }
                field(requireReceive; Rec."Require Receive") { Caption = 'Require Receive'; }
                field(requirePutaway; Rec."Require Put-away") { Caption = 'Require Put-away'; }
                field(requirePick; Rec."Require Pick") { Caption = 'Require Pick'; }
                field(requireShipment; Rec."Require Shipment") { Caption = 'Require Shipment'; }
                field(binMandatory; Rec."Bin Mandatory") { Caption = 'Bin Mandatory'; }
                field(directedPutawayAndPick; Rec."Directed Put-away and Pick") { Caption = 'Directed Put-away and Pick'; }
            }
        }
    }
}

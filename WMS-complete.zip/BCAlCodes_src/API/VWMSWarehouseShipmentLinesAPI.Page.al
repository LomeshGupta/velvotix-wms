namespace Microsoft.Warehouse.Document;

/// Read-only view of the lines belonging to base Business Central warehouse shipment documents.
page 50721 "VWMS WarehouseShipmentLinesAPI"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'warehouseShipmentLine';
    EntitySetName = 'warehouseShipmentLines';
    SourceTable = "Warehouse Shipment Line";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Warehouse Shipment Line" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(documentNo; Rec."No.") { Caption = 'Document No.'; }
                field(lineNo; Rec."Line No.") { Caption = 'Line No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(itemNo; Rec."Item No.") { Caption = 'Item No.'; }
                field(description; Rec.Description) { Caption = 'Description'; }
                field(quantity; Rec.Quantity) { Caption = 'Quantity'; }
                field(qtyToShip; Rec."Qty. to Ship") { Caption = 'Qty. to Ship'; }
                field(qtyOutstanding; Rec."Qty. Outstanding") { Caption = 'Qty. Outstanding'; }
                field(qtyPicked; Rec."Qty. Picked") { Caption = 'Qty. Picked'; }
                field(qtyShipped; Rec."Qty. Shipped") { Caption = 'Qty. Shipped'; }
                field(pickQty; Rec."Pick Qty.") { Caption = 'Open Pick Qty.'; }
                field(qtyPacked; Rec."VWMS Qty. Packed") { Caption = 'Qty. Packed'; }
                field(unitOfMeasureCode; Rec."Unit of Measure Code") { Caption = 'Unit of Measure Code'; }
                field(binCode; Rec."Bin Code") { Caption = 'Bin Code'; }
                field(sourceNo; Rec."Source No.") { Caption = 'Source No.'; }
                field(sourceLineNo; Rec."Source Line No.") { Caption = 'Source Line No.'; }
                field(status; Rec.Status) { Caption = 'Status'; }
            }
        }
    }

    trigger OnAfterGetRecord()
    begin
        Rec.CalcFields("Pick Qty."); // FlowField: quantity currently open on warehouse picks
    end;
}

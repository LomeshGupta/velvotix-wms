using Microsoft.Sales.Document;
/// Read-only lookup for the WMS web app. VWMS Return Lines API
page 50736 "VWMS Return Lines API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'returnOrderLine';
    EntitySetName = 'returnOrderLines';
    SourceTable = "Sales Line";
    SourceTableView = where("Document Type" = const("Return Order"), Type = const(Item));
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Sales Line" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(documentNo; Rec."Document No.") { Caption = 'Document No.'; }
                field(lineNo; Rec."Line No.") { Caption = 'Line No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(itemNo; Rec."No.") { Caption = 'Item No.'; }
                field(description; Rec.Description) { Caption = 'Description'; }
                field(unitOfMeasureCode; Rec."Unit of Measure Code") { Caption = 'Unit of Measure Code'; }
                field(quantity; Rec.Quantity) { Caption = 'Quantity'; }
                field(qtyToReceive; Rec."Return Qty. to Receive") { Caption = 'Return Qty. to Receive'; }
                field(qtyReceived; Rec."Return Qty. Received") { Caption = 'Return Qty. Received'; }
                field(outstandingQuantity; Rec."Outstanding Quantity") { Caption = 'Outstanding Quantity'; }
            }
        }
    }
}

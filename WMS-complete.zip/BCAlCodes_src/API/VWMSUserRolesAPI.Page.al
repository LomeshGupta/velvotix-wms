/// User-to-role assignments consumed by the WMS server. Assignments are maintained in BC pages.
page 50719 "VWMS User Roles API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'userRole';
    EntitySetName = 'userRoles';
    SourceTable = "VWMS User Role";
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; Editable = false; }
                field(userId; Rec."User ID") { Caption = 'User Id'; Editable = false; }
                field(roleCode; Rec."Role Code") { Caption = 'Role Code'; Editable = false; }
            }
        }
    }
}

using Microsoft.Sales.Document;
/// Read-only lookup for the WMS web app. VWMS Return Orders API
page 50735 "VWMS Return Orders API"
{
    PageType = API;
    APIPublisher = 'velvotix';
    APIGroup = 'wms';
    APIVersion = 'v1.0';
    EntityName = 'returnOrder';
    EntitySetName = 'returnOrders';
    SourceTable = "Sales Header";
    SourceTableView = where("Document Type" = const("Return Order"));
    ODataKeyFields = SystemId;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;
    Editable = false;
    Extensible = false;
    Permissions = tabledata "Sales Header" = R;

    layout
    {
        area(Content)
        {
            repeater(Records)
            {
                field(id; Rec.SystemId) { Caption = 'Id'; }
                field(number; Rec."No.") { Caption = 'No.'; }
                field(locationCode; Rec."Location Code") { Caption = 'Location Code'; }
                field(customerNo; Rec."Sell-to Customer No.") { Caption = 'Customer No.'; }
                field(customerName; Rec."Sell-to Customer Name") { Caption = 'Customer Name'; }
                field(status; Rec.Status) { Caption = 'Status'; }
            }
        }
    }
}

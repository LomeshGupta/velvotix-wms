/// Sandbox verification operation. Runs the complete pipeline (authorization, line validation,
/// state machine, audit) without posting anything to the warehouse or ledgers.
codeunit 50703 "VWMS Handler Diagnostic" implements "VWMS Operation Handler"
{
    Access = Internal;

    var
        Authorization: Codeunit "VWMS Authorization";
        BadQuantityErr: Label 'Line %1 has a non-positive quantity.', Comment = '%1 = line no';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        Line: Record "VWMS Staging Line";
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");

        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity <= 0 then
                    Error(BadQuantityErr, Line."Line No.");
            until Line.Next() = 0;

        StagingHeader."Result Document No." := CopyStr(StrSubstNo('DIAG-%1', StagingHeader."Entry No."), 1, MaxStrLen(StagingHeader."Result Document No."));
        exit("VWMS Process Result"::Completed);
    end;
}

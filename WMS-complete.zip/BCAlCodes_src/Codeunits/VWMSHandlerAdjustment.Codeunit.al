using Microsoft.Inventory.Ledger;
using Microsoft.Inventory.Location;

/// Posts a controlled stock adjustment (Positive/Negative Adjmt.) through the standard posting engine.
/// Quantity is signed: positive adds stock, negative removes it. A reason code is mandatory and is
/// stored on the ledger entry. At bin-mandatory locations name the bin (From or To bin, either works).
codeunit 50742 "VWMS Handler Adjustment" implements "VWMS Operation Handler"
{
    Access = Internal;

    var
        Authorization: Codeunit "VWMS Authorization";
        Journal: Codeunit "VWMS Item Journal Mgt";
        LocationErr: Label 'Location %1 was not found.', Comment = '%1 = location';
        ReasonErr: Label 'Item %1: an adjustment reason code is required.', Comment = '%1 = item';
        BinErr: Label 'Item %1: a bin is required at location %2.', Comment = '%1 = item, %2 = location';
        ZeroErr: Label 'Item %1: an adjustment quantity of 0 does nothing.', Comment = '%1 = item';
        NothingErr: Label 'Nothing was entered to adjust.';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        Line: Record "VWMS Staging Line";
        Location: Record Location;
        EntryType: Enum "Item Ledger Entry Type";
        DocNo: Code[20];
        BinCode: Code[20];
        Posted: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'inventory:adjust');
        if not Location.Get(StagingHeader."Location Code") then
            Error(LocationErr, StagingHeader."Location Code");
        Journal.RequireNotDirected(Location.Code);

        DocNo := Journal.DocumentNo(StagingHeader."Entry No.");
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity = 0 then
                    Error(ZeroErr, Line."Item No.");
                if Line."Reason Code" = '' then
                    Error(ReasonErr, Line."Item No.");
                BinCode := Line."From Bin Code";
                if BinCode = '' then
                    BinCode := Line."To Bin Code";
                if Location."Bin Mandatory" and (BinCode = '') then
                    Error(BinErr, Line."Item No.", Location.Code);
                if Line.Quantity > 0 then
                    EntryType := EntryType::"Positive Adjmt."
                else
                    EntryType := EntryType::"Negative Adjmt.";
                Journal.Post(EntryType, DocNo, Line."Item No.", Line."Variant Code", Line."Unit of Measure Code",
                    Location.Code, BinCode, '', '', Abs(Line.Quantity), Line."Reason Code", 'WMS adjustment');
                Posted += 1;
            until Line.Next() = 0;
        if Posted = 0 then
            Error(NothingErr);
        StagingHeader."Result Document No." := DocNo;
        exit("VWMS Process Result"::Completed);
    end;
}

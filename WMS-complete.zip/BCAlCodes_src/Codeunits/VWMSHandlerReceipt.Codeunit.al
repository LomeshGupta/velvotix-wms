using Microsoft.Inventory.Location;
using Microsoft.Purchases.Document;
using Microsoft.Purchases.History;
using Microsoft.Sales.Document;
using Microsoft.Sales.History;
using Microsoft.Sales.Posting;
using Microsoft.Warehouse.Document;
using Microsoft.Warehouse.History;

/// Receives goods the standard Business Central way, depending on how the location is set up:
///  - Require Receive (warehouse receipt): finds or creates the warehouse receipt for the purchase order
///    (Get Source Doc. Inbound), sets Qty. to Receive and posts with "Whse.-Post Receipt". Posting creates
///    the put-away automatically when the location requires put-away.
///  - No warehouse receipt (basic location): sets Qty. to Receive on the purchase order lines and posts
///    the receipt only (no invoice) with "Purch.-Post".
/// Source Document Type: "Purchase Order" (default), "Sales Return Order" (used by the Return handler) or
/// "Warehouse Receipt" (also for transfer receipts created in Business Central). Over-receipt and item tracking entry are not handled
/// here: BC's own checks (including incomplete item tracking) stop posting with a clear message.
codeunit 50738 "VWMS Handler Receipt" implements "VWMS Operation Handler"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Receipt Header" = RM,
                  tabledata "Warehouse Receipt Line" = RM,
                  tabledata "Purchase Header" = RM,
                  tabledata "Purchase Line" = RM,
                  tabledata "Sales Header" = RM,
                  tabledata "Sales Line" = RM;

    var
        Authorization: Codeunit "VWMS Authorization";
        NoSourceErr: Label 'A purchase order or warehouse receipt number is required to receive goods.';
        LocationErr: Label 'Location %1 was not found.', Comment = '%1 = location';
        PoNotFoundErr: Label 'Purchase order %1 was not found at location %2.', Comment = '%1 = PO, %2 = location';
        ReceiptNotFoundErr: Label 'Warehouse receipt %1 was not found at location %2.', Comment = '%1 = receipt, %2 = location';
        InventoryPutawayErr: Label 'Location %1 uses inventory put-away (no warehouse receipt). Create the inventory put-away in Business Central and register it on the Put-away screen.', Comment = '%1 = location';
        SrcTypeErr: Label 'Source document type %1 is not supported for receiving. Use Purchase Order, Sales Return Order or Warehouse Receipt.', Comment = '%1 = type';
        SroNotFoundErr: Label 'Sales return order %1 was not found at location %2.', Comment = '%1 = order, %2 = location';
        NothingToReceiveErr: Label 'Purchase order %1 has nothing open to receive at location %2.', Comment = '%1 = PO, %2 = location';
        NoLinesErr: Label 'No quantity was entered to receive.';
        OverReceiveErr: Label '%1: you are receiving %2 of item %3 but only %4 is still open on the document. Over-receipt is not supported here.', Comment = '%1 = document, %2 = staged qty, %3 = item, %4 = open qty';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    begin
        exit(ProcessFor(StagingHeader, 'receiving:submit', 'Purchase Order'));
    end;

    /// Shared by Receipt and Return: same standard flow, different permission and default document type.
    procedure ProcessFor(var StagingHeader: Record "VWMS Staging Header"; PermissionCode: Code[50]; DefaultSourceType: Text[30]): Enum "VWMS Process Result"
    var
        Location: Record Location;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", PermissionCode);
        if StagingHeader."Source Document Type" = '' then
            StagingHeader."Source Document Type" := DefaultSourceType;
        if not (StagingHeader."Source Document Type" in ['Purchase Order', 'Sales Return Order', 'Warehouse Receipt']) then
            Error(SrcTypeErr, StagingHeader."Source Document Type");
        if StagingHeader."Source Document No." = '' then
            Error(NoSourceErr);
        if not Location.Get(StagingHeader."Location Code") then
            Error(LocationErr, StagingHeader."Location Code");

        if Location."Require Receive" then
            ReceiveWithWarehouseReceipt(StagingHeader)
        else begin
            if Location."Require Put-away" then
                Error(InventoryPutawayErr, Location.Code);
            ReceiveDirect(StagingHeader);
        end;
        exit("VWMS Process Result"::Completed);
    end;

    // ------------------------------------------------------------------ warehouse receipt
    local procedure ReceiveWithWarehouseReceipt(var StagingHeader: Record "VWMS Staging Header")
    var
        ReceiptHeader: Record "Warehouse Receipt Header";
        ReceiptLine: Record "Warehouse Receipt Line";
        PostLines: Record "Warehouse Receipt Line";
        PostedReceipt: Record "Posted Whse. Receipt Header";
        WhsePostReceipt: Codeunit "Whse.-Post Receipt";
        ReceiptNo: Code[20];
        ByReceipt: Boolean;
    begin
        ByReceipt := StagingHeader."Source Document Type" = 'Warehouse Receipt';
        ReceiptNo := FindOrCreateReceipt(StagingHeader, ByReceipt);

        ReceiptHeader.Get(ReceiptNo);
        ReceiptHeader."VWMS User ID" := StagingHeader."WMS User ID";
        ReceiptHeader.Modify(false);

        // Only the staged quantities are received: clear everything first.
        ReceiptLine.SetRange("No.", ReceiptNo);
        if ReceiptLine.FindSet(true) then
            repeat
                if ReceiptLine."Qty. to Receive" <> 0 then begin
                    ReceiptLine.Validate("Qty. to Receive", 0);
                    ReceiptLine.Modify(true);
                end;
            until ReceiptLine.Next() = 0;

        ApplyToReceiptLines(StagingHeader, ReceiptNo, ByReceipt);

        PostLines.SetRange("No.", ReceiptNo);
        PostLines.FindFirst();
        WhsePostReceipt.SetHideValidationDialog(true);
        WhsePostReceipt.Run(PostLines);

        // Posting creates the put-away automatically when the location requires put-away.
        PostedReceipt.SetRange("Whse. Receipt No.", ReceiptNo);
        if PostedReceipt.FindLast() then
            StagingHeader."Result Document No." := PostedReceipt."No."
        else
            StagingHeader."Result Document No." := ReceiptNo;
    end;

    local procedure FindOrCreateReceipt(StagingHeader: Record "VWMS Staging Header"; ByReceipt: Boolean): Code[20]
    var
        ReceiptHeader: Record "Warehouse Receipt Header";
        ReceiptLine: Record "Warehouse Receipt Line";
        PurchHeader: Record "Purchase Header";
        SalesHeader: Record "Sales Header";
        ReleasePurch: Codeunit "Release Purchase Document";
        ReleaseSales: Codeunit "Release Sales Document";
        GetSourceDoc: Codeunit "Get Source Doc. Inbound";
    begin
        if StagingHeader."Source Document Type" = 'Sales Return Order' then begin
            ReceiptLine.SetRange("Location Code", StagingHeader."Location Code");
            ReceiptLine.SetRange("Source Document", ReceiptLine."Source Document"::"Sales Return Order");
            ReceiptLine.SetRange("Source No.", StagingHeader."Source Document No.");
            ReceiptLine.SetFilter("Qty. Outstanding", '>0');
            if ReceiptLine.FindFirst() then
                exit(ReceiptLine."No.");
            if not SalesHeader.Get(SalesHeader."Document Type"::"Return Order", StagingHeader."Source Document No.") or (SalesHeader."Location Code" <> StagingHeader."Location Code") then
                Error(SroNotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");
            if SalesHeader.Status = SalesHeader.Status::Open then
                ReleaseSales.Run(SalesHeader);
            if not GetSourceDoc.CreateFromSalesReturnOrderHideDialog(SalesHeader) then
                Error(NothingToReceiveErr, SalesHeader."No.", StagingHeader."Location Code");
            ReceiptLine.FindFirst();
            exit(ReceiptLine."No.");
        end;
        if ByReceipt then begin
            if not ReceiptHeader.Get(StagingHeader."Source Document No.") or (ReceiptHeader."Location Code" <> StagingHeader."Location Code") then
                Error(ReceiptNotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");
            exit(ReceiptHeader."No.");
        end;

        // An open warehouse receipt for this purchase order is reused (never create a second one).
        ReceiptLine.SetRange("Location Code", StagingHeader."Location Code");
        ReceiptLine.SetRange("Source Document", ReceiptLine."Source Document"::"Purchase Order");
        ReceiptLine.SetRange("Source No.", StagingHeader."Source Document No.");
        ReceiptLine.SetFilter("Qty. Outstanding", '>0');
        if ReceiptLine.FindFirst() then
            exit(ReceiptLine."No.");

        if not PurchHeader.Get(PurchHeader."Document Type"::Order, StagingHeader."Source Document No.") or (PurchHeader."Location Code" <> StagingHeader."Location Code") then
            Error(PoNotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");
        if PurchHeader.Status = PurchHeader.Status::Open then
            ReleasePurch.Run(PurchHeader);
        if not GetSourceDoc.CreateFromPurchOrderHideDialog(PurchHeader) then
            Error(NothingToReceiveErr, PurchHeader."No.", StagingHeader."Location Code");

        ReceiptLine.FindFirst();
        exit(ReceiptLine."No.");
    end;

    local procedure ApplyToReceiptLines(StagingHeader: Record "VWMS Staging Header"; ReceiptNo: Code[20]; ByReceipt: Boolean)
    var
        Line: Record "VWMS Staging Line";
        ReceiptLine: Record "Warehouse Receipt Line";
        Remaining: Decimal;
        Free: Decimal;
        Add: Decimal;
        Touched: Integer;
    begin
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    Remaining := Line.Quantity;
                    ReceiptLine.Reset();
                    ReceiptLine.SetRange("No.", ReceiptNo);
                    ReceiptLine.SetRange("Item No.", Line."Item No.");
                    // A line reference is exact; without one (scan-to-receive) quantity fills the item's lines in order.
                    if Line."Source Line No." <> 0 then
                        if ByReceipt then
                            ReceiptLine.SetRange("Line No.", Line."Source Line No.")
                        else
                            ReceiptLine.SetRange("Source Line No.", Line."Source Line No.");
                    if ReceiptLine.FindSet(true) then
                        repeat
                            Free := ReceiptLine."Qty. Outstanding" - ReceiptLine."Qty. to Receive";
                            if (Remaining > 0) and (Free > 0) then begin
                                Add := Remaining;
                                if Add > Free then
                                    Add := Free;
                                ReceiptLine.Validate("Qty. to Receive", ReceiptLine."Qty. to Receive" + Add);
                                ReceiptLine.Modify(true);
                                Remaining -= Add;
                            end;
                        until (ReceiptLine.Next() = 0) or (Remaining = 0);
                    if Remaining > 0 then
                        Error(OverReceiveErr, ReceiptNo, Line.Quantity, Line."Item No.", Line.Quantity - Remaining);
                    Touched += 1;
                end;
            until Line.Next() = 0;
        if Touched = 0 then
            Error(NoLinesErr);
    end;

    // ------------------------------------------------------------------ basic location (no warehouse receipt)
    local procedure ReceiveDirect(var StagingHeader: Record "VWMS Staging Header")
    begin
        if StagingHeader."Source Document Type" = 'Sales Return Order' then
            ReceiveDirectSalesReturn(StagingHeader)
        else
            ReceiveDirectPurchase(StagingHeader);
    end;

    local procedure ReceiveDirectSalesReturn(var StagingHeader: Record "VWMS Staging Header")
    var
        SalesHeader: Record "Sales Header";
        SalesLine: Record "Sales Line";
        Line: Record "VWMS Staging Line";
        ReturnReceipt: Record "Return Receipt Header";
        ReleaseSales: Codeunit "Release Sales Document";
        SalesPost: Codeunit "Sales-Post";
        Remaining: Decimal;
        Free: Decimal;
        Add: Decimal;
        Touched: Integer;
    begin
        if not SalesHeader.Get(SalesHeader."Document Type"::"Return Order", StagingHeader."Source Document No.") or (SalesHeader."Location Code" <> StagingHeader."Location Code") then
            Error(SroNotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");
        if SalesHeader.Status = SalesHeader.Status::Open then begin
            ReleaseSales.Run(SalesHeader);
            SalesHeader.Get(SalesHeader."Document Type", SalesHeader."No.");
        end;

        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        SalesLine.SetRange(Type, SalesLine.Type::Item);
        if SalesLine.FindSet(true) then
            repeat
                if SalesLine."Return Qty. to Receive" <> 0 then begin
                    SalesLine.Validate("Return Qty. to Receive", 0);
                    SalesLine.Modify(true);
                end;
            until SalesLine.Next() = 0;

        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    Remaining := Line.Quantity;
                    SalesLine.Reset();
                    SalesLine.SetRange("Document Type", SalesHeader."Document Type");
                    SalesLine.SetRange("Document No.", SalesHeader."No.");
                    SalesLine.SetRange(Type, SalesLine.Type::Item);
                    SalesLine.SetRange("No.", Line."Item No.");
                    if Line."Source Line No." <> 0 then
                        SalesLine.SetRange("Line No.", Line."Source Line No.");
                    if SalesLine.FindSet(true) then
                        repeat
                            Free := SalesLine."Outstanding Quantity" - SalesLine."Return Qty. to Receive";
                            if (Remaining > 0) and (Free > 0) then begin
                                Add := Remaining;
                                if Add > Free then
                                    Add := Free;
                                SalesLine.Validate("Return Qty. to Receive", SalesLine."Return Qty. to Receive" + Add);
                                SalesLine.Modify(true);
                                Remaining -= Add;
                            end;
                        until (SalesLine.Next() = 0) or (Remaining = 0);
                    if Remaining > 0 then
                        Error(OverReceiveErr, SalesHeader."No.", Line.Quantity, Line."Item No.", Line.Quantity - Remaining);
                    Touched += 1;
                end;
            until Line.Next() = 0;
        if Touched = 0 then
            Error(NoLinesErr);

        // Receive only: crediting the customer is a separate business step.
        SalesHeader.Receive := true;
        SalesHeader.Invoice := false;
        SalesHeader.Modify(false);
        SalesPost.Run(SalesHeader);

        ReturnReceipt.SetRange("Return Order No.", StagingHeader."Source Document No.");
        if ReturnReceipt.FindLast() then
            StagingHeader."Result Document No." := ReturnReceipt."No."
        else
            StagingHeader."Result Document No." := StagingHeader."Source Document No.";
    end;

    local procedure ReceiveDirectPurchase(var StagingHeader: Record "VWMS Staging Header")
    var
        PurchHeader: Record "Purchase Header";
        PurchLine: Record "Purchase Line";
        Line: Record "VWMS Staging Line";
        RcptHeader: Record "Purch. Rcpt. Header";
        ReleasePurch: Codeunit "Release Purchase Document";
        PurchPost: Codeunit "Purch.-Post";
        Remaining: Decimal;
        Free: Decimal;
        Add: Decimal;
        Touched: Integer;
    begin
        if not PurchHeader.Get(PurchHeader."Document Type"::Order, StagingHeader."Source Document No.") or (PurchHeader."Location Code" <> StagingHeader."Location Code") then
            Error(PoNotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");
        if PurchHeader.Status = PurchHeader.Status::Open then begin
            ReleasePurch.Run(PurchHeader);
            PurchHeader.Get(PurchHeader."Document Type", PurchHeader."No.");
        end;

        PurchLine.SetRange("Document Type", PurchHeader."Document Type");
        PurchLine.SetRange("Document No.", PurchHeader."No.");
        PurchLine.SetRange(Type, PurchLine.Type::Item);
        if PurchLine.FindSet(true) then
            repeat
                if PurchLine."Qty. to Receive" <> 0 then begin
                    PurchLine.Validate("Qty. to Receive", 0);
                    PurchLine.Modify(true);
                end;
            until PurchLine.Next() = 0;

        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    Remaining := Line.Quantity;
                    PurchLine.Reset();
                    PurchLine.SetRange("Document Type", PurchHeader."Document Type");
                    PurchLine.SetRange("Document No.", PurchHeader."No.");
                    PurchLine.SetRange(Type, PurchLine.Type::Item);
                    PurchLine.SetRange("No.", Line."Item No.");
                    if Line."Source Line No." <> 0 then
                        PurchLine.SetRange("Line No.", Line."Source Line No.");
                    if PurchLine.FindSet(true) then
                        repeat
                            Free := PurchLine."Outstanding Quantity" - PurchLine."Qty. to Receive";
                            if (Remaining > 0) and (Free > 0) then begin
                                Add := Remaining;
                                if Add > Free then
                                    Add := Free;
                                PurchLine.Validate("Qty. to Receive", PurchLine."Qty. to Receive" + Add);
                                PurchLine.Modify(true);
                                Remaining -= Add;
                            end;
                        until (PurchLine.Next() = 0) or (Remaining = 0);
                    if Remaining > 0 then
                        Error(OverReceiveErr, PurchHeader."No.", Line.Quantity, Line."Item No.", Line.Quantity - Remaining);
                    Touched += 1;
                end;
            until Line.Next() = 0;
        if Touched = 0 then
            Error(NoLinesErr);

        // Receive only: invoicing the purchase order is a separate business step.
        PurchHeader.Receive := true;
        PurchHeader.Invoice := false;
        PurchHeader.Modify(false);
        PurchPost.Run(PurchHeader);

        RcptHeader.SetRange("Order No.", StagingHeader."Source Document No.");
        if RcptHeader.FindLast() then
            StagingHeader."Result Document No." := RcptHeader."No."
        else
            StagingHeader."Result Document No." := StagingHeader."Source Document No.";
    end;
}

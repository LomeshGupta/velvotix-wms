/// The transaction state machine. Every status change goes through SetStatus so that
/// (a) only legal transitions occur and (b) every change is written to the append-only log.
codeunit 50700 "VWMS Transaction Mgt"
{
    Access = Public;

    var
        Authorization: Codeunit "VWMS Authorization";
        WmsDisabledErr: Label 'WMS is not enabled. Enable it in WMS Setup first.';
        KeyInvalidErr: Label 'The idempotency key must be 16 to 64 characters.';
        DuplicateKeyErr: Label 'VWMS_DUPLICATE: a transaction with this idempotency key already exists.';
        IllegalTransitionErr: Label 'Transaction %1 cannot change from %2 to %3.', Comment = '%1 = entry no, %2 = from, %3 = to';
        NotCancellableErr: Label 'A transaction in status %1 cannot be cancelled.', Comment = '%1 = status';
        NotFoundErr: Label 'Transaction %1 was not found.', Comment = '%1 = id';

    /* ---------------------------------------------------------------- submission */

    /// Called by the API page before insert. Validates and stamps the header as Submitted.
    /// Nothing here posts anything; it only makes the request durable and auditable.
    procedure PrepareSubmission(var Header: Record "VWMS Staging Header")
    var
        Setup: Record "VWMS Setup";
        Existing: Record "VWMS Staging Header";
    begin
        Setup := Setup.GetSetup();
        if not Setup."WMS Enabled" then
            Error(WmsDisabledErr);

        if (StrLen(Header."Idempotency Key") < 16) then
            Error(KeyInvalidErr);

        Existing.SetRange("Idempotency Key", Header."Idempotency Key");
        if not Existing.IsEmpty() then
            Error(DuplicateKeyErr);

        // Independent AL-side authorization (the web tier already checked, but is not trusted alone).
        Authorization.RequireActiveUser(Header."WMS User ID");
        Authorization.RequireWarehouse(Header."WMS User ID", Header."Location Code");
        if Header."Destination Location Code" <> '' then
            Authorization.RequireWarehouse(Header."WMS User ID", Header."Destination Location Code");
        // Generic queue permission is required by the staging API, then a module-specific
        // permission is evaluated by operation type so BC-assigned roles get separate views.
        Authorization.RequirePermission(Header."WMS User ID", 'transactions:submit');
        if GetOperationPermission(Header."Operation Type") <> '' then
            Authorization.RequirePermission(Header."WMS User ID", GetOperationPermission(Header."Operation Type"));

        Header.Status := Header.Status::Submitted;
        Header."Requested At" := CurrentDateTime();
        Header."Attempt Count" := 0;
        Header."Error Class" := Header."Error Class"::None;
        Header."Error Code" := '';
        Header."Error Message" := '';
        Header."Lease Owner" := '';
        Header."Lease Expires At" := 0DT;
        Header."Process Started" := false;
    end;


    local procedure GetOperationPermission(OperationType: Enum "VWMS Operation Type"): Code[50]
    begin
        case OperationType of
            "VWMS Operation Type"::Receipt:
                exit('receiving:submit');
            "VWMS Operation Type"::"Put-away":
                exit('putaway:submit');
            "VWMS Operation Type"::Movement:
                exit('movements:submit');
            "VWMS Operation Type"::Pick:
                exit('picking:submit');
            "VWMS Operation Type"::Pack:
                exit('packing:submit');
            "VWMS Operation Type"::Ship:
                exit('shipping:submit');
            "VWMS Operation Type"::"Cycle Count":
                exit('cyclecounts:submit');
            "VWMS Operation Type"::Adjustment:
                exit('inventory:adjust');
            "VWMS Operation Type"::Return:
                exit('returns:submit');
            "VWMS Operation Type"::"Quality Inspection":
                exit('quality:submit');
            "VWMS Operation Type"::"Create Pick":
                exit('picking:submit');
            else
                exit('');
        end;
    end;

    procedure LogSubmitted(var Header: Record "VWMS Staging Header")
    begin
        WriteLog(Header, 'Submitted', Header.Status::Draft, Header.Status::Submitted, Header."WMS User ID", '');
    end;

    /* ------------------------------------------------------------------- claiming */

    /// Claims up to MaxCount claimable rows for WorkerId with a time-limited lease.
    /// LockTable serialises concurrent workers, so a row is never claimed twice.
    procedure ClaimBatch(WorkerId: Code[50]; LeaseSeconds: Integer; MaxCount: Integer; var EntryNos: List of [Integer])
    var
        Setup: Record "VWMS Setup";
        Header: Record "VWMS Staging Header";
        Candidates: List of [Integer];
        Candidate: Integer;
        Now: DateTime;
    begin
        Setup := Setup.GetSetup();
        if (not Setup."WMS Enabled") or (not Setup."Auto Processing Enabled") then
            exit;

        if LeaseSeconds <= 0 then
            LeaseSeconds := Setup."Lease Seconds";
        if (MaxCount <= 0) or (MaxCount > 20) then
            MaxCount := 1;

        Now := CurrentDateTime();
        RecoverExpiredLeases(Now);

        Header.LockTable();
        Header.SetCurrentKey(Status, "Requested At");
        Header.SetFilter(Status, '%1|%2', Header.Status::Submitted, Header.Status::Queued);
        if Header.FindSet() then
            repeat
                if (Header."Retry After" = 0DT) or (Header."Retry After" <= Now) then
                    Candidates.Add(Header."Entry No.");
            until (Header.Next() = 0) or (Candidates.Count() >= MaxCount);

        // Modify after the scan: changing Status (part of the scan key) mid-iteration can skip rows.
        foreach Candidate in Candidates do begin
            Header.Get(Candidate);
            Header."Lease Owner" := WorkerId;
            Header."Lease Expires At" := Now + (LeaseSeconds * 1000);
            Header."Attempt Count" += 1;
            Header."Processing Started At" := Now;
            Header."Process Started" := false;
            Header."Retry After" := 0DT;
            SetStatus(Header, Header.Status::Processing, WorkerId, 'Claimed', StrSubstNo('Attempt %1', Header."Attempt Count"));
            EntryNos.Add(Candidate);
        end;
    end;

    /// Explains why work is (not) being claimed: setup switches, counts per state, delayed retries and
    /// leases that are still active. Read-only; used by the worker to log the reason for an idle queue.
    procedure QueueState(): Text
    var
        Setup: Record "VWMS Setup";
        Header: Record "VWMS Staging Header";
        State: JsonObject;
        Output: Text;
        Now: DateTime;
        Waiting: Integer;
        Claimable: Integer;
        Delayed: Integer;
        Processing: Integer;
        Reason: Text;
    begin
        Setup := Setup.GetSetup();
        Now := CurrentDateTime();
        Header.SetFilter(Status, '%1|%2', Header.Status::Submitted, Header.Status::Queued);
        if Header.FindSet() then
            repeat
                Waiting += 1;
                if (Header."Retry After" = 0DT) or (Header."Retry After" <= Now) then
                    Claimable += 1
                else
                    Delayed += 1;
            until Header.Next() = 0;
        Header.Reset();
        Header.SetRange(Status, Header.Status::Processing);
        Processing := Header.Count();

        if not Setup."WMS Enabled" then
            Reason := 'WMS Enabled is OFF in WMS Setup: nothing can be submitted or claimed.'
        else
            if not Setup."Auto Processing Enabled" then
                Reason := 'Auto Processing Enabled is OFF in WMS Setup: queued transactions are never claimed by the worker.'
            else
                if (Waiting > 0) and (Claimable = 0) then
                    Reason := 'All waiting transactions have a Retry After time in the future (retry backoff).'
                else
                    if Waiting = 0 then
                        Reason := 'No transaction is waiting.'
                    else
                        Reason := 'Work is claimable; the worker should pick it up on its next poll.';

        State.Add('wmsEnabled', Setup."WMS Enabled");
        State.Add('autoProcessingEnabled', Setup."Auto Processing Enabled");
        State.Add('waiting', Waiting);
        State.Add('claimable', Claimable);
        State.Add('delayed', Delayed);
        State.Add('processing', Processing);
        State.Add('reason', Reason);
        State.WriteTo(Output);
        exit(Output);
    end;

    procedure Heartbeat(var Header: Record "VWMS Staging Header"; WorkerId: Code[50]; LeaseSeconds: Integer): Boolean
    begin
        Header.LockTable();
        Header.Get(Header."Entry No.");
        if (Header.Status <> Header.Status::Processing) or (Header."Lease Owner" <> WorkerId) then
            exit(false);
        Header."Lease Expires At" := CurrentDateTime() + (LeaseSeconds * 1000);
        Header.Modify();
        exit(true);
    end;

    /// Leases that expired while Processing. If the handler never started, the work is untouched
    /// and can be requeued. If it had started, the outcome is not trusted: flag for reconciliation.
    procedure RecoverExpiredLeases(Now: DateTime)
    var
        Header: Record "VWMS Staging Header";
        Expired: List of [Integer];
        EntryNo: Integer;
    begin
        Header.SetRange(Status, Header.Status::Processing);
        Header.SetFilter("Lease Expires At", '<%1', Now);
        if Header.FindSet() then
            repeat
                Expired.Add(Header."Entry No.");
            until Header.Next() = 0;

        foreach EntryNo in Expired do begin
            Header.Get(EntryNo);
            if Header."Process Started" then begin
                Header."Error Class" := Header."Error Class"::Transient;
                Header."Error Code" := 'LEASE_EXPIRED_IN_PROCESS';
                Header."Error Message" := 'Processing did not report a result. Verify the outcome before retrying.';
                ClearLease(Header);
                SetStatus(Header, Header.Status::"Requires Reconciliation", 'SYSTEM', 'Lease expired', 'Handler had started');
            end else begin
                ClearLease(Header);
                SetStatus(Header, Header.Status::Queued, 'SYSTEM', 'Lease expired', 'Handler had not started; requeued');
            end;
        end;
    end;

    /* ------------------------------------------------------------------- outcomes */

    procedure CompleteSuccess(var Header: Record "VWMS Staging Header"; ResultDocumentNo: Code[20]; ActorId: Code[50])
    begin
        Header."Result Document No." := ResultDocumentNo;
        Header."Completed At" := CurrentDateTime();
        Header."Error Class" := Header."Error Class"::None;
        Header."Error Code" := '';
        Header."Error Message" := '';
        ClearLease(Header);
        SetStatus(Header, Header.Status::Completed, ActorId, 'Completed', ResultDocumentNo);
    end;

    /// Records a handler result other than Completed. Raw error text goes only to the log;
    /// the header keeps a short sanitised message safe to show to warehouse users.
    procedure RecordFailure(var Header: Record "VWMS Staging Header"; Result: Enum "VWMS Process Result"; ErrorCode: Code[50]; SafeMessage: Text; RawDetail: Text; ActorId: Code[50])
    var
        Setup: Record "VWMS Setup";
        NextStatus: Enum "VWMS Transaction Status";
    begin
        Setup := Setup.GetSetup();
        Header."Error Code" := ErrorCode;
        Header."Error Message" := CopyStr(SafeMessage, 1, MaxStrLen(Header."Error Message"));
        ClearLease(Header);

        case Result of
            Result::"Transient Failure":
                if Header."Attempt Count" >= Setup."Max Attempts" then begin
                    // Poison message: stop retrying and surface to administrators.
                    Header."Error Class" := Header."Error Class"::Permanent;
                    Header."Error Code" := 'MAX_ATTEMPTS';
                    NextStatus := NextStatus::Failed;
                end else begin
                    Header."Error Class" := Header."Error Class"::Transient;
                    Header."Retry After" := CurrentDateTime() + BackoffMs(Header."Attempt Count");
                    NextStatus := NextStatus::Queued;
                end;
            Result::"Permanent Failure":
                begin
                    Header."Error Class" := Header."Error Class"::Permanent;
                    NextStatus := NextStatus::Failed;
                end;
            Result::"Requires Reconciliation":
                begin
                    Header."Error Class" := Header."Error Class"::Transient;
                    NextStatus := NextStatus::"Requires Reconciliation";
                end;
            else
                Error('Result %1 is not a failure.', Result);
        end;
        SetStatus(Header, NextStatus, ActorId, 'Failure: ' + Format(Result), CopyStr(RawDetail, 1, 250));
    end;

    /// Exponential backoff, 5s doubling to a 5 minute cap (jitter is applied by the web-tier worker).
    local procedure BackoffMs(Attempt: Integer): Integer
    var
        Ms: Integer;
    begin
        Ms := 5000;
        while (Attempt > 1) and (Ms < 300000) do begin
            Ms := Ms * 2;
            Attempt -= 1;
        end;
        if Ms > 300000 then
            Ms := 300000;
        exit(Ms);
    end;

    /* ------------------------------------------------------- cancel / admin actions */

    procedure Cancel(var Header: Record "VWMS Staging Header"; UserId: Code[50])
    begin
        Header.LockTable();
        Header.Get(Header."Entry No.");
        Authorization.RequireActiveUser(UserId);
        // Owners may cancel their own work; anyone else needs the cancel permission.
        if Header."WMS User ID" <> UserId then
            Authorization.RequirePermission(UserId, 'transactions:cancel');
        if not (Header.Status in [Header.Status::Draft, Header.Status::Submitted, Header.Status::Queued, Header.Status::"Awaiting Approval"]) then
            Error(NotCancellableErr, Header.Status);
        ClearLease(Header);
        SetStatus(Header, Header.Status::Cancelled, UserId, 'Cancelled', '');
    end;

    /// Administrator recovery. Action: 'retry' | 'complete' | 'fail'.
    procedure AdminResolve(var Header: Record "VWMS Staging Header"; Action: Text; UserId: Code[50]; ResultDocumentNo: Code[20]; Note: Text)
    begin
        Header.LockTable();
        Header.Get(Header."Entry No.");
        Authorization.RequireActiveUser(UserId);
        Authorization.RequirePermission(UserId, 'administration:administer');
        ClearLease(Header);
        case LowerCase(Action) of
            'retry':
                begin
                    Header."Attempt Count" := 0;
                    Header."Retry After" := 0DT;
                    Header."Error Class" := Header."Error Class"::None;
                    Header."Error Code" := '';
                    Header."Error Message" := '';
                    SetStatus(Header, Header.Status::Queued, UserId, 'Admin retry', Note);
                end;
            'complete':
                begin
                    // Only after the administrator has verified the standard BC document exists.
                    if ResultDocumentNo = '' then
                        Error('A result document number is required to mark a transaction completed.');
                    CompleteSuccess(Header, ResultDocumentNo, UserId);
                end;
            'fail':
                begin
                    Header."Error Class" := Header."Error Class"::Permanent;
                    Header."Error Code" := 'ADMIN_FAILED';
                    SetStatus(Header, Header.Status::Failed, UserId, 'Admin failed', Note);
                end;
            else
                Error('Unknown resolution action %1.', Action);
        end;
    end;

    procedure FindBySystemId(TransactionId: Text; var Header: Record "VWMS Staging Header")
    var
        Id: Guid;
    begin
        if not Evaluate(Id, TransactionId) then
            Error(NotFoundErr, TransactionId);
        if not Header.GetBySystemId(Id) then
            Error(NotFoundErr, TransactionId);
    end;

    /* ---------------------------------------------------------------- retention */

    /// Removes completed/cancelled transactions past the retention window. The log is kept.
    procedure PurgeOldTransactions(): Integer
    var
        Setup: Record "VWMS Setup";
        Header: Record "VWMS Staging Header";
        Line: Record "VWMS Staging Line";
        Cutoff: DateTime;
        Removed: Integer;
    begin
        Setup := Setup.GetSetup();
        Cutoff := CurrentDateTime() - (Setup."Retention Days" * 86400000L);
        Header.SetFilter(Status, '%1|%2', Header.Status::Completed, Header.Status::Cancelled);
        Header.SetFilter("Requested At", '<%1', Cutoff);
        if Header.FindSet() then
            repeat
                Line.SetRange("Header Entry No.", Header."Entry No.");
                Line.DeleteAll(false);
                Removed += 1;
            until Header.Next() = 0;
        Header.DeleteAll(false);
        exit(Removed);
    end;

    /* ------------------------------------------------------------ state machine */

    procedure CanTransition(FromStatus: Enum "VWMS Transaction Status"; ToStatus: Enum "VWMS Transaction Status"): Boolean
    begin
        case FromStatus of
            FromStatus::Draft:
                exit(ToStatus in [ToStatus::Submitted, ToStatus::Cancelled]);
            FromStatus::Submitted:
                exit(ToStatus in [ToStatus::Queued, ToStatus::Processing, ToStatus::Cancelled]);
            FromStatus::Queued:
                exit(ToStatus in [ToStatus::Processing, ToStatus::Cancelled]);
            FromStatus::Processing:
                exit(ToStatus in [ToStatus::Completed, ToStatus::"Partially Completed", ToStatus::Failed,
                                  ToStatus::Queued, ToStatus::"Awaiting Approval", ToStatus::"Requires Reconciliation"]);
            FromStatus::"Awaiting Approval":
                exit(ToStatus in [ToStatus::Queued, ToStatus::Cancelled, ToStatus::Failed]);
            FromStatus::"Partially Completed":
                exit(ToStatus in [ToStatus::Queued, ToStatus::Failed, ToStatus::"Requires Reconciliation"]);
            FromStatus::Failed:
                exit(ToStatus = ToStatus::Queued);
            FromStatus::"Requires Reconciliation":
                exit(ToStatus in [ToStatus::Queued, ToStatus::Completed, ToStatus::Failed]);
            else
                exit(false); // Completed and Cancelled are terminal.
        end;
    end;

    /// Applies a status change (the caller has already set any other fields), persists the
    /// header and appends the audit entry. Illegal transitions raise an error.
    procedure SetStatus(var Header: Record "VWMS Staging Header"; NewStatus: Enum "VWMS Transaction Status"; ActorId: Code[50]; EventName: Text[50]; Detail: Text)
    var
        OldStatus: Enum "VWMS Transaction Status";
    begin
        OldStatus := Header.Status;
        if not CanTransition(OldStatus, NewStatus) then
            Error(IllegalTransitionErr, Header."Entry No.", OldStatus, NewStatus);
        Header.Status := NewStatus;
        Header.Modify();
        WriteLog(Header, EventName, OldStatus, NewStatus, ActorId, Detail);
    end;

    local procedure ClearLease(var Header: Record "VWMS Staging Header")
    begin
        Header."Lease Owner" := '';
        Header."Lease Expires At" := 0DT;
    end;

    local procedure WriteLog(Header: Record "VWMS Staging Header"; EventName: Text[50]; FromStatus: Enum "VWMS Transaction Status"; ToStatus: Enum "VWMS Transaction Status"; ActorId: Code[50]; Detail: Text)
    var
        LogEntry: Record "VWMS Transaction Log";
    begin
        LogEntry.Init();
        LogEntry."Transaction Entry No." := Header."Entry No.";
        LogEntry."Event Name" := EventName;
        LogEntry."From Status" := FromStatus;
        LogEntry."To Status" := ToStatus;
        LogEntry."Actor ID" := ActorId;
        LogEntry."Message Text" := CopyStr(Detail, 1, MaxStrLen(LogEntry."Message Text"));
        LogEntry."Correlation ID" := Header."Correlation ID";
        LogEntry.Insert(true);
    end;
}

/// Seeds the permission catalog and the standard roles. Additive only: existing definitions, roles
/// and assignments are never overwritten or removed. Catalog = every code in use, grouped by category.
codeunit 50732 "VWMS Seed Defaults"
{
    Access = Public;

    procedure SeedPermissionDefs()
    var
        C: Enum "VWMS Permission Category";
    begin
        // ---- General
        Def('dashboard:view', 'View dashboard', C::General, true, 'See queue counts and recent transactions.', 'Read dashboard data', 'Submit or change anything', '', '', 'R');
        Def('transactions:view', 'View transactions', C::General, true, 'See the WMS transaction queue and status.', 'Read transactions and shipment work lists', 'Submit, cancel or retry', '', '', 'R');
        Def('transactions:submit', 'Submit operations', C::General, true, 'Base right to queue any WMS operation (also needs the operation''s own permission).', 'Queue operations the user also holds a module permission for', 'Run an operation without its module permission', '', 'operations:submit', 'RC');
        Def('operations:submit', 'Submit operations (legacy name)', C::General, false, 'Older name for transactions:submit. Counts as transactions:submit.', 'Same as transactions:submit', '', '', '', 'RC');
        Def('transactions:cancel', 'Cancel transactions', C::General, true, 'Cancel not-yet-processed transactions of other users.', 'Cancel Draft, Submitted, Queued', 'Cancel transactions already processing or completed', 'transactions:view', '', 'RM');
        Def('scanning:use', 'Use scanner', C::General, false, 'Scan items and bins.', 'Scanning', '', '', '', 'R');
        Def('labels:print', 'Print labels', C::General, false, 'Print labels.', 'Label printing', '', '', '', 'R');
        // ---- Master data
        Def('items:view', 'View items', C::"Master Data", true, 'Look up items and barcodes.', 'Item search and scan lookup', 'Change items', '', '', 'R');
        Def('items:manage', 'Manage items', C::"Master Data", false, 'Maintain item master data.', 'Item maintenance', '', 'items:view', '', 'RCMD');
        Def('locations:view', 'View locations', C::"Master Data", true, 'Read warehouse locations.', 'Location lookup', 'Change locations', '', '', 'R');
        Def('bins:view', 'View bins', C::"Master Data", true, 'Read bins of assigned warehouses.', 'Bin lookup and validation', 'Create or change bins', '', '', 'R');
        // ---- Inbound
        Def('receiving:submit', 'Receiving', C::Inbound, true, 'Queue goods receipts.', 'Submit receipts', 'Pick, ship or adjust', 'transactions:submit', 'receiving:register', 'RCG');
        Def('receiving:register', 'Receiving (legacy name)', C::Inbound, false, 'Older name for receiving:submit. Counts as receiving:submit.', 'Same as receiving:submit', '', '', '', 'RCG');
        Def('putaway:submit', 'Put-away', C::Inbound, true, 'Queue put-away.', 'Submit put-away', 'Pick or ship', 'transactions:submit', 'putaway:register', 'RCG');
        Def('putaway:register', 'Put-away (legacy name)', C::Inbound, false, 'Older name for putaway:submit. Counts as putaway:submit.', 'Same as putaway:submit', '', '', '', 'RCG');
        // ---- Outbound
        Def('picking:view', 'View picks', C::Outbound, false, 'See picks and pick lines.', 'Read picks', '', '', '', 'R');
        Def('picking:submit', 'Warehouse pick', C::Outbound, true, 'Update pick quantities (full or partial) and register the pick.', 'Register a pick for assigned warehouses', 'Post shipments, adjust stock', 'transactions:submit', 'picking:register', 'RMG');
        Def('picking:register', 'Warehouse pick (legacy name)', C::Outbound, false, 'Older name for picking:submit. Counts as picking:submit.', 'Same as picking:submit', '', '', '', 'RMG');
        Def('packing:submit', 'Packing', C::Outbound, true, 'Queue packing confirmations.', 'Submit packing', 'Pick or post shipments', 'transactions:submit', '', 'RC');
        Def('shipping:submit', 'Warehouse shipment posting', C::Outbound, true, 'Post a warehouse shipment with the picked (or chosen lower) quantity.', 'Post a released warehouse shipment for assigned warehouses', 'Register picks, invoice orders', 'transactions:submit', '', 'RMP');
        // ---- Inventory
        Def('inventory:view', 'View inventory', C::Inventory, true, 'Read inventory and bin availability.', 'Inventory inquiry', 'Adjust stock', '', '', 'R');
        Def('movements:submit', 'Movements', C::Inventory, true, 'Queue bin-to-bin movements.', 'Submit movements', 'Adjust stock', 'transactions:submit', 'inventory:transfer', 'RCG');
        Def('inventory:transfer', 'Transfer stock (legacy name)', C::Inventory, false, 'Counts as movements:submit.', 'Same as movements:submit', '', '', '', 'RCG');
        Def('inventory:adjust', 'Inventory adjustments', C::Inventory, true, 'Queue stock adjustments.', 'Submit adjustments with a reason code', 'Pick or ship', 'transactions:submit', '', 'RCMP');
        // ---- Counting
        Def('cyclecounts:view', 'View cycle counts', C::Counting, false, 'See cycle counts.', 'Read counts', '', '', '', 'R');
        Def('cyclecounts:submit', 'Cycle counts', C::Counting, true, 'Queue cycle counts.', 'Submit counts', 'Post adjustments', 'transactions:submit', '', 'RC');
        Def('cyclecounts:approve', 'Approve cycle counts', C::Counting, false, 'Approve count differences.', 'Approve counts', '', 'cyclecounts:view', '', 'RMP');
        // ---- Quality and returns
        Def('quality:submit', 'Quality inspection', C::"Quality and Returns", true, 'Queue quality inspection results.', 'Submit inspections', 'Pick or ship', 'transactions:submit', '', 'RC');
        Def('returns:view', 'View returns', C::"Quality and Returns", false, 'See returns.', 'Read returns', '', '', '', 'R');
        Def('returns:submit', 'Returns', C::"Quality and Returns", true, 'Queue returns.', 'Submit returns', 'Pick or ship', 'transactions:submit', 'returns:process', 'RC');
        Def('returns:process', 'Returns (legacy name)', C::"Quality and Returns", false, 'Counts as returns:submit.', 'Same as returns:submit', '', '', '', 'RC');
        // ---- Integration and reporting
        Def('integration:view', 'View integration', C::Integration, false, 'See integration status.', 'Read integration state', '', '', '', 'R');
        Def('integration:manage', 'Manage integration', C::Integration, false, 'Change integration settings.', 'Integration maintenance', '', 'integration:view', '', 'RMD');
        Def('reports:view', 'View reports', C::Reporting, false, 'Run and view reports.', 'Reports', '', '', '', 'R');
        // ---- Administration
        Def('administration:administer', 'WMS administration', C::Administration, true, 'Administrators can do everything: this implies every other permission.', 'Everything, including retrying/resolving stuck transactions', 'Bypass warehouse assignment', 'transactions:view', '', 'RCMD');
        Def('audit:view', 'View audit', C::Administration, false, 'See audit information.', 'Read audit data', '', '', '', 'R');
        Def('exceptions:manage', 'Manage exceptions', C::Administration, false, 'Resolve exceptions.', 'Exception handling', '', '', '', 'RM');
        Def('roles:view', 'View roles', C::Administration, false, 'See roles and assignments.', 'Read roles', '', '', '', 'R');
        Def('roles:manage', 'Manage roles', C::Administration, false, 'Maintain roles and assignments.', 'Role maintenance', '', 'roles:view', '', 'RCMD');
    end;

    /// Creates the standard least-privilege roles if they do not exist. Does not touch existing roles.
    procedure SeedDefaultRoles()
    begin
        SeedPermissionDefs();
        Role('WH-READONLY', 'Read-only warehouse user', 'Can view queues, items and dashboard. Cannot submit anything.',
            'dashboard:view,items:view,locations:view,bins:view,inventory:view,transactions:view');
        Role('WH-RECEIVER', 'Warehouse receiver', 'Can submit goods receipts in assigned warehouses.',
            'dashboard:view,items:view,bins:view,transactions:view,transactions:submit,receiving:submit');
        Role('WH-PICKER', 'Warehouse operator / picker', 'Can pick (full or partial) and register picks in assigned warehouses.',
            'dashboard:view,items:view,bins:view,transactions:view,transactions:submit,picking:submit');
        Role('WH-SHIPPER', 'Warehouse shipment operator', 'Can post warehouse shipments in assigned warehouses.',
            'dashboard:view,items:view,bins:view,transactions:view,transactions:submit,shipping:submit');
        Role('WH-SUPERVISOR', 'Warehouse supervisor', 'Picks, ships and cancels transactions. No administration.',
            'dashboard:view,items:view,locations:view,bins:view,inventory:view,transactions:view,transactions:submit,transactions:cancel,picking:submit,shipping:submit,packing:submit');
        Role('WMS-ADMIN', 'WMS administrator', 'Full access to every WMS function.', 'administration:administer');
        SyncAdminRole();
    end;

    /// Gives WMS-ADMIN every permission in the catalog (additive). Safe to run repeatedly, so new
    /// catalog entries reach administrators automatically.
    procedure SyncAdminRole()
    var
        PermDef: Record "VWMS Permission Def.";
        RolePerm: Record "VWMS Role Permission";
        WmsRole: Record "VWMS Role";
    begin
        if not WmsRole.Get('WMS-ADMIN') then
            exit;
        if PermDef.FindSet() then
            repeat
                if not RolePerm.Get('WMS-ADMIN', PermDef."Permission Code") then begin
                    RolePerm.Init();
                    RolePerm."Role Code" := 'WMS-ADMIN';
                    RolePerm."Permission Code" := PermDef."Permission Code";
                    RolePerm.Insert();
                end;
            until PermDef.Next() = 0;
    end;

    /// Flags: R read, C create, M modify, D delete, G register, P post.
    local procedure Def(PermCode: Code[50]; DisplayName: Text[80]; Cat: Enum "VWMS Permission Category"; IsEnforced: Boolean; Descr: Text[250]; Allowed: Text[250]; NotAllowed: Text[250]; DependsOn: Code[50]; AlsoAs: Text[100]; Flags: Text)
    var
        PermDef: Record "VWMS Permission Def.";
        IsNew: Boolean;
    begin
        IsNew := not PermDef.Get(PermCode);
        if IsNew then begin
            PermDef.Init();
            PermDef."Permission Code" := PermCode;
        end;
        PermDef."Display Name" := DisplayName;
        PermDef.Category := Cat;
        PermDef.Enforced := IsEnforced;
        PermDef.Description := Descr;
        PermDef."Allowed Operations" := Allowed;
        PermDef."Not Allowed" := NotAllowed;
        PermDef."Depends On" := DependsOn;
        PermDef."Also Accepted As" := AlsoAs;
        PermDef."Can Read" := Flags.Contains('R');
        PermDef."Can Create" := Flags.Contains('C');
        PermDef."Can Modify" := Flags.Contains('M');
        PermDef."Can Delete" := Flags.Contains('D');
        PermDef."Can Register" := Flags.Contains('G');
        PermDef."Can Post" := Flags.Contains('P');
        if IsNew then
            PermDef.Insert()
        else
            PermDef.Modify();
    end;

    local procedure Role(RoleCode: Code[30]; RoleName: Text[100]; Descr: Text[250]; Perms: Text)
    var
        WmsRole: Record "VWMS Role";
        RolePerm: Record "VWMS Role Permission";
        PermCode: Text;
    begin
        if WmsRole.Get(RoleCode) then
            exit; // never alter an existing role
        WmsRole.Init();
        WmsRole."Role Code" := RoleCode;
        WmsRole."Role Name" := CopyStr(RoleName, 1, MaxStrLen(WmsRole."Role Name"));
        WmsRole.Description := CopyStr(Descr, 1, MaxStrLen(WmsRole.Description));
        WmsRole.Enabled := true;
        WmsRole.Insert();
        foreach PermCode in Perms.Split(',') do begin
            RolePerm.Init();
            RolePerm."Role Code" := RoleCode;
            RolePerm."Permission Code" := CopyStr(PermCode, 1, MaxStrLen(RolePerm."Permission Code"));
            RolePerm.Insert();
        end;
    end;
}

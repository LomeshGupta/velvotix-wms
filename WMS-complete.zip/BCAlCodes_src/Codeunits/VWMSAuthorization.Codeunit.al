/// AL-side authorization. The Next.js server enforces permissions first; this is the independent
/// second check that the brief requires for critical operations. The acting WMS user ID is
/// supplied by the (trusted) service principal and validated here against BC data.
codeunit 50701 "VWMS Authorization"
{
    Access = Public;

    var
        UserUnknownErr: Label 'WMS user %1 does not exist.', Comment = '%1 = user id';
        UserInactiveErr: Label 'WMS user %1 is not active.', Comment = '%1 = user id';
        NoWarehouseErr: Label 'WMS user %1 is not assigned to location %2.', Comment = '%1 = user id, %2 = location';
        NoPermissionErr: Label 'WMS user %1 does not have permission %2.', Comment = '%1 = user id, %2 = permission';

    procedure RequireActiveUser(UserId: Code[50])
    var
        WmsUser: Record "VWMS User";
    begin
        if not WmsUser.Get(UserId) then
            Error(UserUnknownErr, UserId);
        if WmsUser.Status <> WmsUser.Status::Active then
            Error(UserInactiveErr, UserId);
    end;

    procedure RequireWarehouse(UserId: Code[50]; LocationCode: Code[10])
    var
        Assignment: Record "VWMS User Warehouse";
    begin
        // An empty assignment list means no access, never "all locations".
        if not Assignment.Get(UserId, LocationCode) then
            Error(NoWarehouseErr, UserId, LocationCode);
    end;

    /// Administrators (holders of administration:administer) can do everything; everyone else
    /// needs the specific permission, directly or through an enabled role.
    procedure HasPermission(UserId: Code[50]; PermissionCode: Code[50]): Boolean
    begin
        if HasExplicitPermission(UserId, PermissionCode) then
            exit(true);
        exit(HasExplicitPermission(UserId, 'administration:administer'));
    end;

    /// A permission counts if the user holds the code itself or any code catalogued as "Also Accepted As"
    /// for it (for example operations:submit for transactions:submit).
    local procedure HasExplicitPermission(UserId: Code[50]; PermissionCode: Code[50]): Boolean
    var
        PermDef: Record "VWMS Permission Def.";
        AliasCode: Text;
    begin
        if HasExactPermission(UserId, PermissionCode) then
            exit(true);
        if PermDef.Get(PermissionCode) and (PermDef."Also Accepted As" <> '') then
            foreach AliasCode in PermDef."Also Accepted As".Split(',') do
                if HasExactPermission(UserId, CopyStr(AliasCode.Trim(), 1, 50)) then
                    exit(true);
        exit(false);
    end;

    local procedure HasExactPermission(UserId: Code[50]; PermissionCode: Code[50]): Boolean
    var
        UserPermission: Record "VWMS User Permission";
        UserRole: Record "VWMS User Role";
        WmsRole: Record "VWMS Role";
        RolePermission: Record "VWMS Role Permission";
    begin
        // Existing direct user grants remain supported. Roles are the preferred admin path.
        if UserPermission.Get(UserId, PermissionCode) then
            exit(true);

        UserRole.SetRange("User ID", UserId);
        if UserRole.FindSet() then
            repeat
                if WmsRole.Get(UserRole."Role Code") and WmsRole.Enabled then begin
                    RolePermission.SetRange("Role Code", UserRole."Role Code");
                    RolePermission.SetRange("Permission Code", PermissionCode);
                    if not RolePermission.IsEmpty() then
                        exit(true);
                end;
            until UserRole.Next() = 0;

        exit(false);
    end;

    procedure RequirePermission(UserId: Code[50]; PermissionCode: Code[50])
    begin
        if not HasPermission(UserId, PermissionCode) then
            Error(NoPermissionErr, UserId, PermissionCode);
    end;
}

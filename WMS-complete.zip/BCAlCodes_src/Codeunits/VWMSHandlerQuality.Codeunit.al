using Microsoft.Inventory.Ledger;
using Microsoft.Inventory.Location;

/// Quality disposition. The Business Central base application has no inspection document, so the result
/// decides what happens to the stock, traceably:
///   PASS            - released: no stock change, the inspection is only recorded on the transaction.
///   HOLD / REJECT   - the quantity is moved to the quarantine bin entered on the line (an item
///                     reclassification through the standard posting engine). Business Central can then
///                     scrap, return to vendor or release it with its own documents.
codeunit 50744 "VWMS Handler Quality" implements "VWMS Operation Handler"
{
    Access = Internal;

    var
        Authorization: Codeunit "VWMS Authorization";
        Journal: Codeunit "VWMS Item Journal Mgt";
        LocationErr: Label 'Location %1 was not found.', Comment = '%1 = location';
        ResultErr: Label 'Item %1: the inspection result must be PASS, HOLD or REJECT.', Comment = '%1 = item';
        QuarantineErr: Label 'Item %1: enter the quarantine bin (To bin) for a %2 result.', Comment = '%1 = item, %2 = result';
        FromBinErr: Label 'Item %1: enter the bin the stock is in (From bin) at location %2.', Comment = '%1 = item, %2 = location';
        SameErr: Label 'Item %1: the quarantine bin is the same as the current bin.', Comment = '%1 = item';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        Line: Record "VWMS Staging Line";
        Location: Record Location;
        DocNo: Code[20];
        Moved: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'quality:submit');
        if not Location.Get(StagingHeader."Location Code") then
            Error(LocationErr, StagingHeader."Location Code");

        // Validate every line before posting anything.
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if not (Line."Reason Code" in ['PASS', 'HOLD', 'REJECT']) then
                    Error(ResultErr, Line."Item No.");
                if Line."Reason Code" <> 'PASS' then begin
                    Journal.RequireNotDirected(Location.Code);
                    if Line."To Bin Code" = '' then
                        Error(QuarantineErr, Line."Item No.", Line."Reason Code");
                    if Location."Bin Mandatory" and (Line."From Bin Code" = '') then
                        Error(FromBinErr, Line."Item No.", Location.Code);
                    if Line."From Bin Code" = Line."To Bin Code" then
                        Error(SameErr, Line."Item No.");
                end;
            until Line.Next() = 0;

        DocNo := Journal.DocumentNo(StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if (Line."Reason Code" <> 'PASS') and (Line.Quantity > 0) then begin
                    Journal.Post("Item Ledger Entry Type"::Transfer, DocNo, Line."Item No.", Line."Variant Code", Line."Unit of Measure Code",
                        Location.Code, Line."From Bin Code", Location.Code, Line."To Bin Code", Line.Quantity, '', 'WMS quality ' + Line."Reason Code");
                    Moved += 1;
                end;
            until Line.Next() = 0;
        if Moved > 0 then
            StagingHeader."Result Document No." := DocNo;
        exit("VWMS Process Result"::Completed);
    end;
}

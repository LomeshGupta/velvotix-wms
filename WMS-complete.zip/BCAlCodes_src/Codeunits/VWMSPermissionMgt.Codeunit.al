/// Bulk helpers so administrators choose permissions by category or from a list instead of typing codes.
/// All additive: nothing is removed or overwritten.
codeunit 50735 "VWMS Permission Mgt"
{
    Access = Public;

    procedure AddToRole(RoleCode: Code[30]; var PermDef: Record "VWMS Permission Def."): Integer
    var
        RolePerm: Record "VWMS Role Permission";
        Added: Integer;
    begin
        if PermDef.FindSet() then
            repeat
                if not RolePerm.Get(RoleCode, PermDef."Permission Code") then begin
                    RolePerm.Init();
                    RolePerm."Role Code" := RoleCode;
                    RolePerm."Permission Code" := PermDef."Permission Code";
                    RolePerm.Insert(true);
                    Added += 1;
                end;
            until PermDef.Next() = 0;
        exit(Added);
    end;

    procedure AddToUser(UserId: Code[50]; var PermDef: Record "VWMS Permission Def."): Integer
    var
        UserPerm: Record "VWMS User Permission";
        Added: Integer;
    begin
        if PermDef.FindSet() then
            repeat
                if not UserPerm.Get(UserId, PermDef."Permission Code") then begin
                    UserPerm.Init();
                    UserPerm."User ID" := UserId;
                    UserPerm."Permission Code" := PermDef."Permission Code";
                    UserPerm.Insert(true);
                    Added += 1;
                end;
            until PermDef.Next() = 0;
        exit(Added);
    end;

    /// Permissions of a whole category (for example every Outbound permission).
    procedure FilterCategory(var PermDef: Record "VWMS Permission Def."; Cat: Enum "VWMS Permission Category"; EnforcedOnly: Boolean)
    begin
        PermDef.Reset();
        PermDef.SetRange(Category, Cat);
        if EnforcedOnly then
            PermDef.SetRange(Enforced, true);
    end;

    procedure CopyRoleToRole(FromRole: Code[30]; ToRole: Code[30]): Integer
    var
        Source: Record "VWMS Role Permission";
        Target: Record "VWMS Role Permission";
        Added: Integer;
    begin
        Source.SetRange("Role Code", FromRole);
        if Source.FindSet() then
            repeat
                if not Target.Get(ToRole, Source."Permission Code") then begin
                    Target.Init();
                    Target."Role Code" := ToRole;
                    Target."Permission Code" := Source."Permission Code";
                    Target.Insert(true);
                    Added += 1;
                end;
            until Source.Next() = 0;
        exit(Added);
    end;
}

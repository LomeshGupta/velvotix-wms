/// Holds the WMS user on whose behalf the current transaction is being processed. The integration
/// runs as one service principal, so this is what lets documents and ledgers show the real person.
codeunit 50733 "VWMS Context"
{
    SingleInstance = true;
    Access = Public;

    var
        CurrentWmsUser: Code[50];

    procedure SetUser(WmsUserId: Code[50])
    begin
        CurrentWmsUser := WmsUserId;
    end;

    procedure GetUser(): Code[50]
    begin
        exit(CurrentWmsUser);
    end;

    procedure Clear()
    begin
        CurrentWmsUser := '';
    end;
}

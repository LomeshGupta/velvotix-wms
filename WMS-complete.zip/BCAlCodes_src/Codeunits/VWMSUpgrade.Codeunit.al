using System.Integration;

codeunit 50723 "VWMS Upgrade"
{
    Subtype = Upgrade;
    Access = Internal;

    trigger OnUpgradePerCompany()
    var
        Setup: Record "VWMS Setup";
        SeedDefaults: Codeunit "VWMS Seed Defaults";
    begin
        Setup := Setup.GetSetup();
        SeedDefaults.SeedPermissionDefs();
        SeedDefaults.SeedDefaultRoles(); // additive: never alters an existing role
        RegisterWebService('VWMSWorker', Codeunit::"VWMS Worker API");
        RegisterWebService('VWMSAuth', Codeunit::"VWMS Authentication API");
    end;

    local procedure RegisterWebService(ServiceName: Text[240]; ObjectId: Integer)
    var
        webservice: Codeunit "Web Service Management";
        object: Option ,,,,,"Codeunit",,,"Page","Query";
    begin
        webservice.CreateTenantWebService(object::Codeunit, ObjectId, ServiceName, true);
    end;
}

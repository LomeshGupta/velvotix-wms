using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Activity;
using Microsoft.Warehouse.Document;

/// Registers a warehouse pick for the staged quantities using the STANDARD registration codeunit.
/// Staged lines reference the warehouse shipment line ("Source Line No."); the matching pick lines are
/// found through "Whse. Document No." / "Whse. Document Line No.". No status field or ledger table
/// is written directly. Runs inside the Processor's transaction: any Error rolls everything back.
/// STATUS: written against BC standard objects, NOT yet compiled or run in a BC sandbox.
codeunit 50730 "VWMS Handler Pick" implements "VWMS Operation Handler"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Activity Line" = RM,
                  tabledata "Warehouse Activity Header" = RM,
                  tabledata "Warehouse Shipment Line" = R;

    var
        Authorization: Codeunit "VWMS Authorization";
        NoPickErr: Label 'No open warehouse pick exists for shipment %1 line %2. Create the pick in Business Central first.', Comment = '%1 = shipment no, %2 = line no';
        OverPickErr: Label 'Shipment %1 line %2: you are picking %3 but only %4 is open on the warehouse pick. Lower the quantity, or create/refresh the pick in Business Central for the rest.', Comment = '%1 = shipment no, %2 = line no, %3 = staged qty, %4 = open qty';
        NoSourceErr: Label 'A warehouse shipment number and line reference are required to register a pick.';
        NothingToRegisterErr: Label 'Nothing was selected to register.';
        LocationNoPickErr: Label 'Location %1 does not require warehouse picks, so there is no pick to register.', Comment = '%1 = location';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        Line: Record "VWMS Staging Line";
        RegisterTarget: Record "Warehouse Activity Line";
        Location: Record Location;
        Register: Codeunit "Whse.-Activity-Register";
        ActivityNos: List of [Code[20]];
        ActivityNo: Code[20];
        Registered: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'picking:submit');
        if StagingHeader."Source Document No." = '' then
            Error(NoSourceErr);
        if not Location.Get(StagingHeader."Location Code") or not Location."Require Pick" then
            Error(LocationNoPickErr, StagingHeader."Location Code");

        // 1. Reset every quantity-to-handle on the affected picks, then 2. apply only staged quantities.
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if not Line.FindSet() then
            Error(NothingToRegisterErr);
        repeat
            if Line.Quantity > 0 then begin
                if Line."Source Line No." = 0 then
                    Error(NoSourceErr);
                CollectPicks(StagingHeader, Line, ActivityNos);
            end;
        until Line.Next() = 0;
        if ActivityNos.Count() = 0 then
            Error(NothingToRegisterErr);

        foreach ActivityNo in ActivityNos do
            ZeroQtyToHandle(ActivityNo);

        Line.FindSet();
        repeat
            if Line.Quantity > 0 then
                ApplyLine(StagingHeader, Line);
        until Line.Next() = 0;

        // 3. Register through standard code. The record filter limits it to the intended pick(s).
        foreach ActivityNo in ActivityNos do begin
            RegisterTarget.SetRange("Activity Type", RegisterTarget."Activity Type"::Pick);
            RegisterTarget.SetRange("No.", ActivityNo);
            RegisterTarget.FindFirst();
            StampActivity(ActivityNo, StagingHeader."WMS User ID");
            Clear(Register);
            Register.Run(RegisterTarget);
            Registered += 1;
        end;

        StagingHeader."Result Document No." := CopyStr(ActivityNos.Get(1), 1, MaxStrLen(StagingHeader."Result Document No."));
        exit("VWMS Process Result"::Completed);
    end;

    local procedure StampActivity(ActivityNo: Code[20]; WmsUserId: Code[50])
    var
        ActivityHeader: Record "Warehouse Activity Header";
    begin
        if ActivityHeader.Get(ActivityHeader.Type::Pick, ActivityNo) then begin
            ActivityHeader."VWMS User ID" := WmsUserId;
            ActivityHeader.Modify(false);
        end;
    end;

    local procedure PickLines(StagingHeader: Record "VWMS Staging Header"; SourceLineNo: Integer; var ActivityLine: Record "Warehouse Activity Line")
    begin
        ActivityLine.Reset();
        ActivityLine.SetRange("Activity Type", ActivityLine."Activity Type"::Pick);
        ActivityLine.SetRange("Location Code", StagingHeader."Location Code");
        ActivityLine.SetRange("Whse. Document Type", ActivityLine."Whse. Document Type"::Shipment);
        ActivityLine.SetRange("Whse. Document No.", StagingHeader."Source Document No.");
        ActivityLine.SetRange("Whse. Document Line No.", SourceLineNo);
    end;

    local procedure CollectPicks(StagingHeader: Record "VWMS Staging Header"; Line: Record "VWMS Staging Line"; var ActivityNos: List of [Code[20]])
    var
        ActivityLine: Record "Warehouse Activity Line";
    begin
        PickLines(StagingHeader, Line."Source Line No.", ActivityLine);
        if not ActivityLine.FindSet() then
            Error(NoPickErr, StagingHeader."Source Document No.", Line."Source Line No.");
        repeat
            if not ActivityNos.Contains(ActivityLine."No.") then
                ActivityNos.Add(ActivityLine."No.");
        until ActivityLine.Next() = 0;
    end;

    local procedure ZeroQtyToHandle(ActivityNo: Code[20])
    var
        ActivityLine: Record "Warehouse Activity Line";
    begin
        ActivityLine.SetRange("Activity Type", ActivityLine."Activity Type"::Pick);
        ActivityLine.SetRange("No.", ActivityNo);
        if ActivityLine.FindSet(true) then
            repeat
                if ActivityLine."Qty. to Handle" <> 0 then begin
                    ActivityLine.Validate("Qty. to Handle", 0);
                    ActivityLine.Modify(true);
                end;
            until ActivityLine.Next() = 0;
    end;

    /// Applies the staged quantity to the pick lines of this shipment line. Works for every pick layout:
    ///  - bin-based picks: Take lines first, then the matching Place lines;
    ///  - picks without Take/Place (Action Type blank): the single set of lines.
    local procedure ApplyLine(StagingHeader: Record "VWMS Staging Header"; Line: Record "VWMS Staging Line")
    var
        ActivityLine: Record "Warehouse Activity Line";
        ActionType: Enum "Warehouse Action Type";
    begin
        PickLines(StagingHeader, Line."Source Line No.", ActivityLine);
        ActivityLine.SetRange("Action Type", ActionType::" ");
        if not ActivityLine.IsEmpty() then begin
            Allocate(StagingHeader, Line, ActionType::" ");
            exit;
        end;
        Allocate(StagingHeader, Line, ActionType::Take);
        Allocate(StagingHeader, Line, ActionType::Place);
    end;

    /// The bin typed/scanned on screen is a preference for Take lines (it is often the shipment bin, not a
    /// pick bin), so lines in that bin are filled first and the rest of the quantity comes from the other
    /// lines of the same pick. Only a genuine shortage of open quantity is an error.
    local procedure Allocate(StagingHeader: Record "VWMS Staging Header"; Line: Record "VWMS Staging Line"; ActionType: Enum "Warehouse Action Type")
    var
        ActivityLine: Record "Warehouse Activity Line";
        Remaining: Decimal;
    begin
        Remaining := Line.Quantity;

        if (Line."From Bin Code" <> '') and (ActionType <> ActionType::Place) then begin
            SetFilters(StagingHeader, Line, ActionType, ActivityLine);
            ActivityLine.SetRange("Bin Code", Line."From Bin Code");
            Fill(ActivityLine, Remaining);
        end;

        if Remaining > 0 then begin
            SetFilters(StagingHeader, Line, ActionType, ActivityLine);
            Fill(ActivityLine, Remaining);
        end;

        if Remaining > 0 then
            Error(OverPickErr, StagingHeader."Source Document No.", Line."Source Line No.", Line.Quantity, Line.Quantity - Remaining);
    end;

    local procedure SetFilters(StagingHeader: Record "VWMS Staging Header"; Line: Record "VWMS Staging Line"; ActionType: Enum "Warehouse Action Type"; var ActivityLine: Record "Warehouse Activity Line")
    begin
        PickLines(StagingHeader, Line."Source Line No.", ActivityLine);
        ActivityLine.SetRange("Action Type", ActionType);
        ActivityLine.SetRange("Item No.", Line."Item No.");
        if Line."Lot No." <> '' then
            ActivityLine.SetRange("Lot No.", Line."Lot No.");
        if Line."Serial No." <> '' then
            ActivityLine.SetRange("Serial No.", Line."Serial No.");
    end;

    /// Adds quantity to Qty. to Handle on the filtered lines, never above what is still outstanding.
    local procedure Fill(var ActivityLine: Record "Warehouse Activity Line"; var Remaining: Decimal)
    var
        Free: Decimal;
        Add: Decimal;
    begin
        if not ActivityLine.FindSet(true) then
            exit;
        repeat
            Free := ActivityLine."Qty. Outstanding" - ActivityLine."Qty. to Handle";
            if (Remaining > 0) and (Free > 0) then begin
                Add := Remaining;
                if Add > Free then
                    Add := Free;
                ActivityLine.Validate("Qty. to Handle", ActivityLine."Qty. to Handle" + Add);
                ActivityLine.Modify(true);
                Remaining -= Add;
            end;
        until (ActivityLine.Next() = 0) or (Remaining = 0);
    end;
}

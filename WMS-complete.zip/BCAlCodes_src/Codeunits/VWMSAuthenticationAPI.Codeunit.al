using System.Security.Encryption;

/// WMS credential authority. User passwords are set from Business Central and checked here.
/// The published ODataV4 surface exposes Login only; SetPassword is called internally by the BC page.
codeunit 50718 "VWMS Authentication API"
{
    Access = Public;

    [ServiceEnabled]
    procedure Login(userId: Text; password: Text) Result: Text
    var
        Setup: Record "VWMS Setup";
        UserRec: Record "VWMS User";
        UserKey: Code[50];
        PasswordMatches: Boolean;
        IsLocked: Boolean;
    begin
        Setup := Setup.GetSetup();
        if not Setup."WMS Enabled" then
            exit(LoginResponse(false, '', '', false));

        UserKey := CopyStr(UpperCase(DelChr(UserId, '<>', ' ')), 1, MaxStrLen(UserKey));
        if UserRec.Get(UserKey) then begin
            IsLocked := (UserRec."Locked Until" <> 0DT) and (UserRec."Locked Until" > CurrentDateTime);
            // Do the expensive hash operation even for locked/inactive accounts.
            PasswordMatches := VerifyPassword(UserRec, Password);
            if (not IsLocked) and (UserRec.Status = UserRec.Status::Active) and PasswordMatches then begin
                UserRec."Failed Login Attempts" := 0;
                UserRec."Locked Until" := 0DT;
                UserRec."Last Login At" := CurrentDateTime;
                UserRec.Modify(true);
                exit(LoginResponse(true, UserRec."User ID", UserRec."Display Name", UserRec."Must Change Password"));
            end;

            if (not IsLocked) and (UserRec.Status = UserRec.Status::Active) then begin
                UserRec."Failed Login Attempts" += 1;
                if UserRec."Failed Login Attempts" >= Setup."Max Failed Logins" then
                    UserRec."Locked Until" := CurrentDateTime + (15 * 60 * 1000);
                UserRec.Modify(true);
            end;
        end else
            // Make unknown users pay a comparable hashing cost to reduce account enumeration.
            HashPassword(Password, 'VWMS-DUMMY-SALT', 10000);

        exit(LoginResponse(false, '', '', false));
    end;

    /// Called only inside Business Central by the WMS User administration page.
    procedure SetPassword(UserId: Code[50]; NewPassword: Text)
    var
        UserRec: Record "VWMS User";
        Salt: Text[50];
        Iterations: Integer;
    begin
        if StrLen(NewPassword) < 12 then
            Error('The WMS password must contain at least 12 characters.');
        if StrLen(NewPassword) > 128 then
            Error('The WMS password cannot exceed 128 characters.');
        if not UserRec.Get(UserId) then
            Error('WMS user %1 does not exist.', UserId);

        Salt := CopyStr(LowerCase(Format(CreateGuid(), 0, 4)), 1, MaxStrLen(Salt));
        Iterations := 10000;
        UserRec."Password Salt" := Salt;
        UserRec."Password Iterations" := Iterations;
        UserRec."Password Hash" := HashPassword(NewPassword, Salt, Iterations);
        UserRec."Failed Login Attempts" := 0;
        UserRec."Locked Until" := 0DT;
        UserRec.Modify(true);
    end;

    local procedure VerifyPassword(UserRec: Record "VWMS User"; Password: Text): Boolean
    var
        Candidate: Text;
        Iterations: Integer;
    begin
        Iterations := UserRec."Password Iterations";
        if (Iterations <> 10000) or (UserRec."Password Salt" = '') or (UserRec."Password Hash" = '') then begin
            HashPassword(Password, 'VWMS-DUMMY-SALT', 10000);
            exit(false);
        end;
        Candidate := HashPassword(Password, UserRec."Password Salt", Iterations);
        exit(Candidate = UserRec."Password Hash");
    end;

    local procedure HashPassword(Password: Text; Salt: Text; Iterations: Integer): Text
    var
        Crypto: Codeunit "Cryptography Management";
        HashAlgorithm: Option MD5,SHA1,SHA256,SHA384,SHA512;
        HashValue: Text;
        Iteration: Integer;
    begin
        HashAlgorithm := HashAlgorithm::SHA512;
        HashValue := Crypto.GenerateHash(Password + '|' + Salt, HashAlgorithm);
        for Iteration := 2 to Iterations do
            HashValue := Crypto.GenerateHash(Salt + '|' + HashValue, HashAlgorithm);
        exit(HashValue);
    end;

    local procedure LoginResponse(Success: Boolean; UserId: Text; DisplayName: Text; MustChangePassword: Boolean): Text
    var
        Response: JsonObject;
        Output: Text;
    begin
        Response.Add('success', Success);
        if Success then begin
            Response.Add('userId', UserId);
            Response.Add('displayName', DisplayName);
            Response.Add('status', 'Active');
            Response.Add('mustChangePassword', MustChangePassword);
            Response.Add('message', 'Login successful');
        end else
            Response.Add('message', 'Invalid user ID or password');
        Response.WriteTo(Output);
        exit(Output);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"UI Helper Triggers", AutoFormatTranslate, '', false, false)]
    local procedure "UI Helper Triggers_AutoFormatTranslate"(AutoFormatType: Integer; AutoFormatExpr: Text[80]; var Translation: Text[80])
    begin
    end;
    
}

/// Default for operations whose real handler arrives in Phase 4. It fails permanently and
/// visibly rather than pretending to succeed, so nothing is ever marked Completed untruthfully.
codeunit 50704 "VWMS Handler Not Implemented" implements "VWMS Operation Handler"
{
    Access = Internal;

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    begin
        StagingHeader."Error Code" := 'OPERATION_NOT_IMPLEMENTED';
        StagingHeader."Error Message" := CopyStr(StrSubstNo('Operation %1 is not implemented in this version.', StagingHeader."Operation Type"), 1, MaxStrLen(StagingHeader."Error Message"));
        exit("VWMS Process Result"::"Permanent Failure");
    end;
}

using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Document;

/// Posts a warehouse shipment with the STANDARD "Whse.-Post Shipment" codeunit (posting the shipment
/// document, which in turn posts the source documents' shipment). It never posts invoices: invoicing
/// the sales order is a separate business step.
/// STATUS: written against BC standard objects, NOT yet compiled or run in a BC sandbox.
codeunit 50731 "VWMS Handler Ship" implements "VWMS Operation Handler"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Shipment Line" = RM,
                  tabledata "Warehouse Shipment Header" = RM;

    var
        Authorization: Codeunit "VWMS Authorization";
        NoSourceErr: Label 'A warehouse shipment number and line reference are required to post a shipment.';
        NotFoundErr: Label 'Warehouse shipment %1 was not found.', Comment = '%1 = shipment no';
        LocationNoShptErr: Label 'Location %1 does not use warehouse shipments.', Comment = '%1 = location';
        NotReleasedErr: Label 'Warehouse shipment %1 is not released.', Comment = '%1 = shipment no';
        LineMissingErr: Label 'Warehouse shipment %1 has no line %2.', Comment = '%1 = shipment no, %2 = line no';
        ItemMismatchErr: Label 'Shipment %1 line %2 is for item %3, not %4.', Comment = '%1 = shipment, %2 = line, %3 = BC item, %4 = staged item';
        OverShipErr: Label 'Shipment %1 line %2: quantity %3 exceeds the %4 that can be shipped.', Comment = '%1 = shipment, %2 = line, %3 = staged qty, %4 = allowed qty';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        ShptHeader: Record "Warehouse Shipment Header";
        Location: Record Location;
        ShptLine: Record "Warehouse Shipment Line";
        PostLines: Record "Warehouse Shipment Line";
        Line: Record "VWMS Staging Line";
        WhsePostShipment: Codeunit "Whse.-Post Shipment";
        Touched: Integer;
        Allowed: Decimal;
        Setup: Record "VWMS Setup";
    begin
        Setup := Setup.GetSetup();
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'shipping:submit');
        if StagingHeader."Source Document No." = '' then
            Error(NoSourceErr);
        if not Location.Get(StagingHeader."Location Code") or not Location."Require Shipment" then
            Error(LocationNoShptErr, StagingHeader."Location Code");
        if not ShptHeader.Get(StagingHeader."Source Document No.") then
            Error(NotFoundErr, StagingHeader."Source Document No.");
        if ShptHeader."Location Code" <> StagingHeader."Location Code" then
            Error(NotFoundErr, StagingHeader."Source Document No.");
        if ShptHeader.Status <> ShptHeader.Status::Released then
            Error(NotReleasedErr, ShptHeader."No.");

        // Zero every line first so only the staged quantities ship.
        ShptLine.SetRange("No.", ShptHeader."No.");
        if ShptLine.FindSet(true) then
            repeat
                if ShptLine."Qty. to Ship" <> 0 then begin
                    ShptLine.Validate("Qty. to Ship", 0);
                    ShptLine.Modify(true);
                end;
            until ShptLine.Next() = 0;

        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    if Line."Source Line No." = 0 then
                        Error(NoSourceErr);
                    if not ShptLine.Get(ShptHeader."No.", Line."Source Line No.") then
                        Error(LineMissingErr, ShptHeader."No.", Line."Source Line No.");
                    if ShptLine."Item No." <> Line."Item No." then
                        Error(ItemMismatchErr, ShptHeader."No.", Line."Source Line No.", ShptLine."Item No.", Line."Item No.");
                    // Standard validation also enforces the picked-quantity rule for pick locations.
                    Allowed := ShptLine."Qty. Outstanding";
                    if Location."Require Pick" then
                        Allowed := ShptLine."Qty. Picked" - ShptLine."Qty. Shipped";
                    // Packing limit: when packing is required (or this line has been packed), ship at most what is packed.
                    if Setup."Require Packing Before Ship" or (ShptLine."VWMS Qty. Packed" > 0) then
                        if ShptLine."VWMS Qty. Packed" - ShptLine."Qty. Shipped" < Allowed then
                            Allowed := ShptLine."VWMS Qty. Packed" - ShptLine."Qty. Shipped";
                    if Line.Quantity > Allowed then
                        Error(OverShipErr, ShptHeader."No.", Line."Source Line No.", Line.Quantity, Allowed);
                    ShptLine.Validate("Qty. to Ship", Line.Quantity);
                    ShptLine.Modify(true);
                    Touched += 1;
                end;
            until Line.Next() = 0;

        if Touched = 0 then
            Error(NoSourceErr);

        ShptHeader."VWMS User ID" := StagingHeader."WMS User ID";
        ShptHeader.Modify(false);

        PostLines.SetRange("No.", ShptHeader."No.");
        PostLines.FindFirst();
        WhsePostShipment.SetPostingSettings(false); // ship only; do not invoice
        WhsePostShipment.SetPrint(false);
        WhsePostShipment.Run(PostLines);

        StagingHeader."Result Document No." := CopyStr(ShptHeader."No.", 1, MaxStrLen(StagingHeader."Result Document No."));
        exit("VWMS Process Result"::Completed);
    end;
}

using Microsoft.Inventory.Journal;
using Microsoft.Inventory.Ledger;
using Microsoft.Inventory.Location;
using Microsoft.Inventory.Posting;

/// Posts one item journal line with the STANDARD "Item Jnl.-Post Line" (RunWithCheck), the same engine the
/// Item Journal pages use: entry types Transfer (movement/reclassification), Positive/Negative Adjmt.
/// The journal line is not stored; every standard check (availability, bins, tracking, blocked items,
/// posting groups) still runs. Directed put-away and pick locations must use warehouse journals instead.
codeunit 50740 "VWMS Item Journal Mgt"
{
    Access = Internal;

    var
        DirectedErr: Label 'Location %1 uses directed put-away and pick. Use the Warehouse Reclassification / Physical Inventory journals in Business Central for stock changes there.', Comment = '%1 = location';

    procedure DocumentNo(EntryNo: Integer): Code[20]
    begin
        exit(CopyStr('WMS' + Format(EntryNo), 1, 20));
    end;

    procedure RequireNotDirected(LocationCode: Code[10])
    var
        Location: Record Location;
    begin
        if (LocationCode <> '') and Location.Get(LocationCode) then
            if Location."Directed Put-away and Pick" then
                Error(DirectedErr, LocationCode);
    end;

    procedure Post(EntryType: Enum "Item Ledger Entry Type"; DocNo: Code[20]; ItemNo: Code[20]; VariantCode: Code[10]; UnitOfMeasureCode: Code[10]; LocationCode: Code[10]; BinCode: Code[20]; NewLocationCode: Code[10]; NewBinCode: Code[20]; Qty: Decimal; ReasonCode: Code[20]; Descr: Text[100])
    var
        ItemJnlLine: Record "Item Journal Line";
        ItemJnlPostLine: Codeunit "Item Jnl.-Post Line";
    begin
        ItemJnlLine.Init();
        ItemJnlLine.Validate("Posting Date", WorkDate());
        ItemJnlLine.Validate("Entry Type", EntryType);
        ItemJnlLine."Document No." := DocNo;
        ItemJnlLine.Validate("Item No.", ItemNo);
        if VariantCode <> '' then
            ItemJnlLine.Validate("Variant Code", VariantCode);
        ItemJnlLine.Validate("Location Code", LocationCode);
        if BinCode <> '' then
            ItemJnlLine.Validate("Bin Code", BinCode);
        if EntryType = EntryType::Transfer then begin
            ItemJnlLine.Validate("New Location Code", NewLocationCode);
            if NewBinCode <> '' then
                ItemJnlLine.Validate("New Bin Code", NewBinCode);
        end;
        if UnitOfMeasureCode <> '' then
            ItemJnlLine.Validate("Unit of Measure Code", UnitOfMeasureCode);
        ItemJnlLine.Validate(Quantity, Qty);
        ItemJnlLine.Description := Descr;
        if ReasonCode <> '' then
            ItemJnlLine.Validate("Reason Code", CopyStr(ReasonCode, 1, MaxStrLen(ItemJnlLine."Reason Code")));
        ItemJnlPostLine.RunWithCheck(ItemJnlLine);
    end;
}

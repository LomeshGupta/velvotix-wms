/// Receives returned goods against a sales return order, the standard way:
///  - location requires receive: warehouse receipt created from the return order, then posted
///    (put-away follows automatically when the location requires it);
///  - basic location: the return order is received directly (receive only, no credit memo).
/// It is the Receipt handler with the returns permission and "Sales Return Order" as the default
/// document. A return receipt can also be received as a "Warehouse Receipt". Where the goods then go
/// (put-away, or quarantine through Quality Inspection) is the next step, as in Business Central.
codeunit 50745 "VWMS Handler Return" implements "VWMS Operation Handler"
{
    Access = Internal;

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        ReceiptHandler: Codeunit "VWMS Handler Receipt";
    begin
        exit(ReceiptHandler.ProcessFor(StagingHeader, 'returns:submit', 'Sales Return Order'));
    end;
}

/// Runs one handler. Exists as its own codeunit so the Processor can call it with
/// "if Runner.Run(Header) then", which rolls back everything the handler wrote if it
/// raises an error, leaving the Processor free to record the failure cleanly.
codeunit 50708 "VWMS Process Runner"
{
    TableNo = "VWMS Staging Header";
    Access = Internal;

    var
        ProcessResult: Enum "VWMS Process Result";
        ResultDocNo: Code[20];
        HandlerErrorCode: Code[50];
        HandlerErrorMessage: Text[250];

    trigger OnRun()
    var
        Handler: Interface "VWMS Operation Handler";
    begin
        Clear(ResultDocNo);
        Clear(HandlerErrorCode);
        Clear(HandlerErrorMessage);
        Handler := Rec."Operation Type";
        ProcessResult := Handler.Process(Rec);
        ResultDocNo := Rec."Result Document No.";
        HandlerErrorCode := Rec."Error Code";
        HandlerErrorMessage := Rec."Error Message";
    end;

    procedure GetResult(): Enum "VWMS Process Result"
    begin
        exit(ProcessResult);
    end;

    procedure GetResultDocumentNo(): Code[20]
    begin
        exit(ResultDocNo);
    end;

    procedure GetHandlerErrorCode(): Code[50]
    begin
        exit(HandlerErrorCode);
    end;

    procedure GetHandlerErrorMessage(): Text[250]
    begin
        exit(HandlerErrorMessage);
    end;
}

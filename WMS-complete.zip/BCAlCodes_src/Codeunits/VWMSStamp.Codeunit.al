using Microsoft.Inventory.Ledger;
using Microsoft.Warehouse.Activity;
using Microsoft.Warehouse.Activity.History;
using Microsoft.Warehouse.Document;
using Microsoft.Warehouse.Ledger;
using Microsoft.Purchases.History;
using Microsoft.Warehouse.History;

/// Stamps the acting WMS user on warehouse documents, posted/registered documents and ledgers created
/// while a WMS transaction is processed. Does nothing outside WMS processing, so normal Business
/// Central use is unaffected. Standard posting code is not modified: this only reacts to inserts.
codeunit 50734 "VWMS Stamp"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Shipment Header" = m,
                  tabledata "Posted Whse. Shipment Header" = m,
                  tabledata "Warehouse Activity Header" = m,
                  tabledata "Registered Whse. Activity Hdr." = m,
                  tabledata "Warehouse Entry" = m,
                  tabledata "Warehouse Receipt Header" = m,
                  tabledata "Posted Whse. Receipt Header" = m,
                  tabledata "Purch. Rcpt. Header" = m,
                  tabledata "Item Ledger Entry" = m;

    var
        Context: Codeunit "VWMS Context";

    [EventSubscriber(ObjectType::Table, Database::"Warehouse Shipment Header", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertShipment(var Rec: Record "Warehouse Shipment Header"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Posted Whse. Shipment Header", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertPostedShipment(var Rec: Record "Posted Whse. Shipment Header"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Warehouse Activity Header", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertActivity(var Rec: Record "Warehouse Activity Header"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Registered Whse. Activity Hdr.", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertRegistered(var Rec: Record "Registered Whse. Activity Hdr."; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Warehouse Entry", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertWarehouseEntry(var Rec: Record "Warehouse Entry"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Item Ledger Entry", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertItemLedgerEntry(var Rec: Record "Item Ledger Entry"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Warehouse Receipt Header", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertReceipt(var Rec: Record "Warehouse Receipt Header"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Posted Whse. Receipt Header", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertPostedReceipt(var Rec: Record "Posted Whse. Receipt Header"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Purch. Rcpt. Header", 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertPurchReceipt(var Rec: Record "Purch. Rcpt. Header"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary() or (Context.GetUser() = '') then
            exit;
        Rec."VWMS User ID" := Context.GetUser();
        Rec.Modify(false);
    end;
}

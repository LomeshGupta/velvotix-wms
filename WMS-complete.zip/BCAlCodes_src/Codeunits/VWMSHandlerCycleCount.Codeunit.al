using Microsoft.Inventory.Item;
using Microsoft.Inventory.Ledger;
using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Structure;

/// Reconciles a physical count: the staged quantity is the COUNTED quantity (0 is a valid count). The
/// system quantity is read from Business Central (bin contents at bin-mandatory locations, otherwise
/// item inventory at the location) and only the difference is posted as a Positive/Negative Adjmt.
/// through the standard posting engine. A count that matches posts nothing.
/// Counting is in the item's base unit of measure.
codeunit 50743 "VWMS Handler Cycle Count" implements "VWMS Operation Handler"
{
    Access = Internal;

    var
        Authorization: Codeunit "VWMS Authorization";
        Journal: Codeunit "VWMS Item Journal Mgt";
        LocationErr: Label 'Location %1 was not found.', Comment = '%1 = location';
        BinErr: Label 'Item %1: a bin is required to count at location %2.', Comment = '%1 = item, %2 = location';
        UomErr: Label 'Item %1: counts are entered in the base unit of measure (%2), not %3.', Comment = '%1 = item, %2 = base UoM, %3 = entered UoM';
        DuplicateErr: Label 'Item %1 (bin %2) was counted on more than one line. Enter one total per item and bin.', Comment = '%1 = item, %2 = bin';
        ReasonDefaultTxt: Label 'WMS cycle count', Locked = true;

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        Line: Record "VWMS Staging Line";
        Location: Record Location;
        Item: Record Item;
        EntryType: Enum "Item Ledger Entry Type";
        Seen: List of [Text];
        CountKey: Text;
        DocNo: Code[20];
        BinCode: Code[20];
        Calculated: Decimal;
        Difference: Decimal;
        Posted: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'cyclecounts:submit');
        if not Location.Get(StagingHeader."Location Code") then
            Error(LocationErr, StagingHeader."Location Code");
        Journal.RequireNotDirected(Location.Code);

        DocNo := Journal.DocumentNo(StagingHeader."Entry No.");
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                Item.Get(Line."Item No.");
                if (Line."Unit of Measure Code" <> '') and (Line."Unit of Measure Code" <> Item."Base Unit of Measure") then
                    Error(UomErr, Item."No.", Item."Base Unit of Measure", Line."Unit of Measure Code");
                BinCode := Line."From Bin Code";
                if BinCode = '' then
                    BinCode := Line."To Bin Code";
                if Location."Bin Mandatory" and (BinCode = '') then
                    Error(BinErr, Item."No.", Location.Code);
                CountKey := Line."Item No." + '|' + Line."Variant Code" + '|' + BinCode;
                if Seen.Contains(CountKey) then
                    Error(DuplicateErr, Line."Item No.", BinCode);
                Seen.Add(CountKey);

                Calculated := SystemQuantity(Location, Item, Line."Variant Code", BinCode);
                Difference := Line.Quantity - Calculated;
                if Difference <> 0 then begin
                    if Difference > 0 then
                        EntryType := EntryType::"Positive Adjmt."
                    else
                        EntryType := EntryType::"Negative Adjmt.";
                    Journal.Post(EntryType, DocNo, Line."Item No.", Line."Variant Code", '', Location.Code, BinCode, '', '',
                        Abs(Difference), Line."Reason Code", CopyStr(ReasonDefaultTxt, 1, 100));
                    Posted += 1;
                end;
            until Line.Next() = 0;

        // Nothing differs: the count is confirmed and nothing needs posting.
        if Posted > 0 then
            StagingHeader."Result Document No." := DocNo;
        exit("VWMS Process Result"::Completed);
    end;

    /// What Business Central believes is there, in base unit of measure.
    local procedure SystemQuantity(Location: Record Location; var Item: Record Item; VariantCode: Code[10]; BinCode: Code[20]): Decimal
    var
        BinContent: Record "Bin Content";
        Total: Decimal;
    begin
        if Location."Bin Mandatory" then begin
            BinContent.SetRange("Location Code", Location.Code);
            BinContent.SetRange("Bin Code", BinCode);
            BinContent.SetRange("Item No.", Item."No.");
            BinContent.SetRange("Variant Code", VariantCode);
            if BinContent.FindSet() then
                repeat
                    BinContent.CalcFields("Quantity (Base)");
                    Total += BinContent."Quantity (Base)";
                until BinContent.Next() = 0;
            exit(Total);
        end;
        Item.SetRange("Location Filter", Location.Code);
        Item.SetRange("Variant Filter", VariantCode);
        Item.CalcFields(Inventory);
        exit(Item.Inventory);
    end;
}

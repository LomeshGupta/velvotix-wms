using Microsoft.Inventory.Ledger;
using Microsoft.Inventory.Location;

/// Moves stock bin-to-bin, or to another location, with an item reclassification (entry type Transfer)
/// through the standard posting engine. Bin-mandatory locations need the bin on each side.
codeunit 50741 "VWMS Handler Movement" implements "VWMS Operation Handler"
{
    Access = Internal;

    var
        Authorization: Codeunit "VWMS Authorization";
        Journal: Codeunit "VWMS Item Journal Mgt";
        LocationErr: Label 'Location %1 was not found.', Comment = '%1 = location';
        FromBinErr: Label 'Item %1: a source bin is required at location %2.', Comment = '%1 = item, %2 = location';
        ToBinErr: Label 'Item %1: a destination bin is required at location %2.', Comment = '%1 = item, %2 = location';
        SameErr: Label 'Item %1: source and destination are the same.', Comment = '%1 = item';
        NothingErr: Label 'Nothing was entered to move.';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        Line: Record "VWMS Staging Line";
        FromLocation: Record Location;
        ToLocation: Record Location;
        DestinationCode: Code[10];
        DocNo: Code[20];
        Moved: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'movements:submit');

        DestinationCode := StagingHeader."Destination Location Code";
        if DestinationCode = '' then
            DestinationCode := StagingHeader."Location Code"
        else
            Authorization.RequireWarehouse(StagingHeader."WMS User ID", DestinationCode);
        if not FromLocation.Get(StagingHeader."Location Code") then
            Error(LocationErr, StagingHeader."Location Code");
        if not ToLocation.Get(DestinationCode) then
            Error(LocationErr, DestinationCode);
        Journal.RequireNotDirected(FromLocation.Code);
        Journal.RequireNotDirected(ToLocation.Code);

        DocNo := Journal.DocumentNo(StagingHeader."Entry No.");
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    if FromLocation."Bin Mandatory" and (Line."From Bin Code" = '') then
                        Error(FromBinErr, Line."Item No.", FromLocation.Code);
                    if ToLocation."Bin Mandatory" and (Line."To Bin Code" = '') then
                        Error(ToBinErr, Line."Item No.", ToLocation.Code);
                    if (FromLocation.Code = ToLocation.Code) and (Line."From Bin Code" = Line."To Bin Code") then
                        Error(SameErr, Line."Item No.");
                    Journal.Post("Item Ledger Entry Type"::Transfer, DocNo, Line."Item No.", Line."Variant Code", Line."Unit of Measure Code",
                        FromLocation.Code, Line."From Bin Code", ToLocation.Code, Line."To Bin Code", Line.Quantity, Line."Reason Code", 'WMS movement');
                    Moved += 1;
                end;
            until Line.Next() = 0;
        if Moved = 0 then
            Error(NothingErr);
        StagingHeader."Result Document No." := DocNo;
        exit("VWMS Process Result"::Completed);
    end;
}

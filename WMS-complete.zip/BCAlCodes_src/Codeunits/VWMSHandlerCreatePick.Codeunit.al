using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Activity;
using Microsoft.Warehouse.Document;

/// Creates the warehouse pick for selected lines of a released warehouse shipment, using the STANDARD
/// report "Whse.-Shipment - Create Pick" (7318) exactly as the Business Central action does.
/// Business Central picks the whole open quantity of a line (quantity minus picked minus already on a
/// pick); it cannot create a partial pick, so a staged quantity must equal that open quantity.
codeunit 50736 "VWMS Handler Create Pick" implements "VWMS Operation Handler"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Shipment Header" = RM,
                  tabledata "Warehouse Shipment Line" = R,
                  tabledata "Warehouse Activity Header" = R;

    var
        Authorization: Codeunit "VWMS Authorization";
        NoSourceErr: Label 'A warehouse shipment number and line reference are required to create a pick.';
        NotFoundErr: Label 'Warehouse shipment %1 was not found at location %2.', Comment = '%1 = shipment no, %2 = location';
        LocationErr: Label 'Location %1 does not use warehouse picks and shipments, so no pick can be created.', Comment = '%1 = location';
        LineMissingErr: Label 'Warehouse shipment %1 has no line %2.', Comment = '%1 = shipment, %2 = line';
        ItemMismatchErr: Label 'Shipment %1 line %2 is for item %3, not %4.', Comment = '%1 = shipment, %2 = line, %3 = BC item, %4 = staged item';
        NothingToPickErr: Label 'Shipment %1 line %2 has nothing left to pick (everything is already picked or on an open pick).', Comment = '%1 = shipment, %2 = line';
        WholeLineErr: Label 'Shipment %1 line %2: a pick can only be created for the whole open quantity (%3), not %4.', Comment = '%1 = shipment, %2 = line, %3 = open qty, %4 = staged qty';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        ShptHeader: Record "Warehouse Shipment Header";
        ShptLine: Record "Warehouse Shipment Line";
        SelectedLines: Record "Warehouse Shipment Line";
        Line: Record "VWMS Staging Line";
        Location: Record Location;
        ReleaseShipment: Codeunit "Whse.-Shipment Release";
        CreatePick: Report "Whse.-Shipment - Create Pick";
        OpenQty: Decimal;
        LineFilter: Text;
        FirstNewPick: Code[20];
        Selected: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'picking:submit');
        if StagingHeader."Source Document No." = '' then
            Error(NoSourceErr);
        if not Location.Get(StagingHeader."Location Code") or not (Location."Require Pick" and Location."Require Shipment") then
            Error(LocationErr, StagingHeader."Location Code");
        if not ShptHeader.Get(StagingHeader."Source Document No.") or (ShptHeader."Location Code" <> StagingHeader."Location Code") then
            Error(NotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");

        // Validate every selected line before touching anything.
        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    if Line."Source Line No." = 0 then
                        Error(NoSourceErr);
                    if not ShptLine.Get(ShptHeader."No.", Line."Source Line No.") then
                        Error(LineMissingErr, ShptHeader."No.", Line."Source Line No.");
                    if ShptLine."Item No." <> Line."Item No." then
                        Error(ItemMismatchErr, ShptHeader."No.", Line."Source Line No.", ShptLine."Item No.", Line."Item No.");
                    ShptLine.CalcFields("Pick Qty.");
                    OpenQty := ShptLine.Quantity - (ShptLine."Qty. Picked" + ShptLine."Pick Qty.");
                    if OpenQty <= 0 then
                        Error(NothingToPickErr, ShptHeader."No.", Line."Source Line No.");
                    if Line.Quantity <> OpenQty then
                        Error(WholeLineErr, ShptHeader."No.", Line."Source Line No.", OpenQty, Line.Quantity);
                    if LineFilter <> '' then
                        LineFilter += '|';
                    LineFilter += Format(Line."Source Line No.");
                    Selected += 1;
                end;
            until Line.Next() = 0;
        if Selected = 0 then
            Error(NoSourceErr);

        // Picks can only be created from a released shipment: release it with the standard codeunit.
        ReleaseShipment.Release(ShptHeader);

        FirstNewPick := LastPickNo(ShptHeader."No.");
        SelectedLines.SetRange("No.", ShptHeader."No.");
        SelectedLines.SetFilter("Line No.", LineFilter);
        CreatePick.SetHideValidationDialog(true);
        CreatePick.SetWhseShipmentLine(SelectedLines, ShptHeader);
        CreatePick.UseRequestPage(false);
        CreatePick.RunModal(); // errors with "There is nothing to handle." if no pick lines result

        StagingHeader."Result Document No." := CopyStr(LastPickNo(ShptHeader."No."), 1, MaxStrLen(StagingHeader."Result Document No."));
        if (StagingHeader."Result Document No." = '') or (StagingHeader."Result Document No." = FirstNewPick) then
            Error(NothingToPickErr, ShptHeader."No.", Format(LineFilter));
        exit("VWMS Process Result"::Completed);
    end;

    /// Highest pick number that references this shipment (picks are numbered ascending), '' if none.
    local procedure LastPickNo(ShipmentNo: Code[20]): Code[20]
    var
        ActivityLine: Record "Warehouse Activity Line";
        Highest: Code[20];
    begin
        ActivityLine.SetRange("Activity Type", ActivityLine."Activity Type"::Pick);
        ActivityLine.SetRange("Whse. Document Type", ActivityLine."Whse. Document Type"::Shipment);
        ActivityLine.SetRange("Whse. Document No.", ShipmentNo);
        if ActivityLine.FindSet() then
            repeat
                if ActivityLine."No." > Highest then
                    Highest := ActivityLine."No.";
            until ActivityLine.Next() = 0;
        exit(Highest);
    end;
}

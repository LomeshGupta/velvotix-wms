using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Document;

/// Records quantities confirmed at the packing station on the warehouse shipment line
/// ("VWMS Qty. Packed", cumulative). Business Central has no standard packing step, so nothing standard
/// is posted; shipping can be limited to the packed quantity (Setup > Require Packing Before Ship).
codeunit 50737 "VWMS Handler Pack" implements "VWMS Operation Handler"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Shipment Line" = RM,
                  tabledata "Warehouse Shipment Header" = R;

    var
        Authorization: Codeunit "VWMS Authorization";
        NoSourceErr: Label 'A warehouse shipment number and line reference are required to confirm packing.';
        NotFoundErr: Label 'Warehouse shipment %1 was not found at location %2.', Comment = '%1 = shipment no, %2 = location';
        LineMissingErr: Label 'Warehouse shipment %1 has no line %2.', Comment = '%1 = shipment, %2 = line';
        ItemMismatchErr: Label 'Shipment %1 line %2 is for item %3, not %4.', Comment = '%1 = shipment, %2 = line, %3 = BC item, %4 = staged item';
        OverPackErr: Label 'Shipment %1 line %2: you are packing %3 but only %4 can still be packed.', Comment = '%1 = shipment, %2 = line, %3 = staged qty, %4 = packable qty';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        ShptHeader: Record "Warehouse Shipment Header";
        ShptLine: Record "Warehouse Shipment Line";
        Line: Record "VWMS Staging Line";
        Location: Record Location;
        Packable: Decimal;
        Touched: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'packing:submit');
        if StagingHeader."Source Document No." = '' then
            Error(NoSourceErr);
        if not ShptHeader.Get(StagingHeader."Source Document No.") or (ShptHeader."Location Code" <> StagingHeader."Location Code") then
            Error(NotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");
        Location.Get(StagingHeader."Location Code");

        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    if Line."Source Line No." = 0 then
                        Error(NoSourceErr);
                    if not ShptLine.Get(ShptHeader."No.", Line."Source Line No.") then
                        Error(LineMissingErr, ShptHeader."No.", Line."Source Line No.");
                    if ShptLine."Item No." <> Line."Item No." then
                        Error(ItemMismatchErr, ShptHeader."No.", Line."Source Line No.", ShptLine."Item No.", Line."Item No.");
                    // What can be packed: picked goods at pick locations, otherwise the shipment quantity.
                    if Location."Require Pick" then
                        Packable := ShptLine."Qty. Picked"
                    else
                        Packable := ShptLine.Quantity;
                    Packable -= ShptLine."VWMS Qty. Packed";
                    if Line.Quantity > Packable then
                        Error(OverPackErr, ShptHeader."No.", Line."Source Line No.", Line.Quantity, Packable);
                    ShptLine."VWMS Qty. Packed" += Line.Quantity;
                    ShptLine.Modify(false);
                    Touched += 1;
                end;
            until Line.Next() = 0;
        if Touched = 0 then
            Error(NoSourceErr);

        StagingHeader."Result Document No." := CopyStr(ShptHeader."No.", 1, MaxStrLen(StagingHeader."Result Document No."));
        exit("VWMS Process Result"::Completed);
    end;
}

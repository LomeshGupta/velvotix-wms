/// Unbound OData actions for the worker and the Next.js server (published as web service
/// "VWMSWorker"). Parameters are plain values and results are JSON text. Every method that acts
/// for a user re-validates that user in AL. This codeunit only orchestrates; business logic
/// lives in the Transaction Mgt, Processor and handlers.
codeunit 50706 "VWMS Worker API"
{
    Access = Public;

    var
        TransactionMgt: Codeunit "VWMS Transaction Mgt";
        Processor: Codeunit "VWMS Processor";

    /// Returns a JSON array of claimed transactions: [{id, operationType, attemptCount}].
    [ServiceEnabled]
    procedure ClaimBatch(WorkerId: Text; LeaseSeconds: Integer; MaxCount: Integer): Text
    var
        Header: Record "VWMS Staging Header";
        EntryNos: List of [Integer];
        EntryNo: Integer;
        Items: JsonArray;
        Item: JsonObject;
        Output: Text;
    begin
        TransactionMgt.ClaimBatch(CopyStr(WorkerId, 1, 50), LeaseSeconds, MaxCount, EntryNos);
        foreach EntryNo in EntryNos do begin
            Header.Get(EntryNo);
            Clear(Item);
            Item.Add('id', Lowercase(Format(Header.SystemId, 0, 4)));
            Item.Add('operationType', Format(Header."Operation Type"));
            Item.Add('attemptCount', Header."Attempt Count");
            Items.Add(Item);
        end;
        Items.WriteTo(Output);
        exit(Output);
    end;

    /// Read-only explanation of why the queue is (not) moving. Returns JSON.
    [ServiceEnabled]
    procedure QueueState(): Text
    begin
        exit(TransactionMgt.QueueState());
    end;

    [ServiceEnabled]
    procedure ProcessTransaction(TransactionId: Text; WorkerId: Text): Text
    var
        Header: Record "VWMS Staging Header";
    begin
        TransactionMgt.FindBySystemId(TransactionId, Header);
        exit(Processor.ProcessClaimed(Header, CopyStr(WorkerId, 1, 50)));
    end;

    [ServiceEnabled]
    procedure Heartbeat(TransactionId: Text; WorkerId: Text; LeaseSeconds: Integer): Boolean
    var
        Header: Record "VWMS Staging Header";
    begin
        TransactionMgt.FindBySystemId(TransactionId, Header);
        exit(TransactionMgt.Heartbeat(Header, CopyStr(WorkerId, 1, 50), LeaseSeconds));
    end;

    [ServiceEnabled]
    procedure CancelTransaction(TransactionId: Text; UserId: Text): Text
    var
        Header: Record "VWMS Staging Header";
    begin
        TransactionMgt.FindBySystemId(TransactionId, Header);
        TransactionMgt.Cancel(Header, CopyStr(UserId, 1, 50));
        exit(Format(Header.Status));
    end;

    /// Administrator recovery: Action is 'retry', 'complete' or 'fail'.
    [ServiceEnabled]
    procedure ResolveTransaction(TransactionId: Text; Action: Text; UserId: Text; ResultDocumentNo: Text; Note: Text): Text
    var
        Header: Record "VWMS Staging Header";
    begin
        TransactionMgt.FindBySystemId(TransactionId, Header);
        TransactionMgt.AdminResolve(Header, Action, CopyStr(UserId, 1, 50), CopyStr(ResultDocumentNo, 1, 20), Note);
        exit(Format(Header.Status));
    end;
}

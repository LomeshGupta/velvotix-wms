/// Executes one claimed transaction.
///
/// Atomicity: the handler's database work AND the final status write happen in the same
/// transaction (the calling web-service request). Either both commit or neither does, so a
/// crash cannot leave "work done, status not recorded". The only earlier commit is the
/// "Process Started" marker, written before the handler runs.
codeunit 50702 "VWMS Processor"
{
    Access = Public;

    var
        TransactionMgt: Codeunit "VWMS Transaction Mgt";
        Context: Codeunit "VWMS Context";

    procedure ProcessClaimed(var Header: Record "VWMS Staging Header"; WorkerId: Code[50]): Text
    var
        Runner: Codeunit "VWMS Process Runner";
        HandlerResult: Enum "VWMS Process Result";
        Ok: Boolean;
        RawError: Text;
        ErrorCode: Code[50];
    begin
        Header.Get(Header."Entry No.");
        if (Header.Status <> Header.Status::Processing) or (Header."Lease Owner" <> WorkerId) or (Header."Lease Expires At" < CurrentDateTime()) then
            exit(ResultJson(Header, 'not_owner'));

        // Mark that the handler is about to run, and commit so the marker survives a later rollback.
        Header."Process Started" := true;
        Header.Modify();
        Commit();

        Context.SetUser(Header."WMS User ID");
        Ok := Runner.Run(Header);
        Context.Clear();
        if Ok then begin
            Header.Get(Header."Entry No.");
            HandlerResult := Runner.GetResult();
            if HandlerResult = HandlerResult::Completed then
                TransactionMgt.CompleteSuccess(Header, Runner.GetResultDocumentNo(), WorkerId)
            else
                TransactionMgt.RecordFailure(Header, HandlerResult, Runner.GetHandlerErrorCode(),
                    Runner.GetHandlerErrorMessage(), Runner.GetHandlerErrorMessage(), WorkerId);
        end else begin
            // The handler raised an error: its writes were rolled back by Run.
            RawError := GetLastErrorText();
            ErrorCode := CopyStr(GetLastErrorCode(), 1, MaxStrLen(ErrorCode));
            Header.Get(Header."Entry No.");
            if IsTransient(ErrorCode, RawError) then
                TransactionMgt.RecordFailure(Header, "VWMS Process Result"::"Transient Failure", 'TRANSIENT_ERROR',
                    'A temporary problem occurred. The system will retry.', RawError, WorkerId)
            else
                TransactionMgt.RecordFailure(Header, "VWMS Process Result"::"Permanent Failure", 'VALIDATION_ERROR',
                    'The transaction could not be processed. See the transaction log.', RawError, WorkerId);
        end;
        exit(ResultJson(Header, 'processed'));
    end;

    /// Conservative classification. Only recognised lock/timeout conditions are retried;
    /// everything else (validation, setup, data errors) is permanent so we do not loop on it.
    /// VERIFY against the error codes/texts produced by the target BC version.
    local procedure IsTransient(ErrorCode: Text; ErrorText: Text): Boolean
    begin
        if ErrorText.Contains('VWMS_TRANSIENT') then
            exit(true);
        if ErrorCode.StartsWith('DB:') and (ErrorCode.Contains('Lock') or ErrorCode.Contains('Timeout')) then
            exit(true);
        exit(ErrorText.Contains('another user') and ErrorText.Contains('changed'));
    end;

    local procedure ResultJson(Header: Record "VWMS Staging Header"; Outcome: Text): Text
    var
        Result: JsonObject;
        Output: Text;
    begin
        Result.Add('outcome', Outcome);
        Result.Add('id', Lowercase(Format(Header.SystemId, 0, 4)));
        Result.Add('status', Format(Header.Status));
        Result.Add('errorClass', Format(Header."Error Class"));
        Result.Add('errorCode', Header."Error Code");
        Result.Add('resultDocumentNo', Header."Result Document No.");
        Result.Add('attemptCount', Header."Attempt Count");
        Result.WriteTo(Output);
        exit(Output);
    end;
}

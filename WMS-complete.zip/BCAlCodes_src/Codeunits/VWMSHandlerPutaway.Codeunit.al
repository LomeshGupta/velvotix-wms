using Microsoft.Inventory.Location;
using Microsoft.Warehouse.Activity;

/// Registers a warehouse put-away (or inventory put-away) with the STANDARD "Whse.-Activity-Register".
/// Staged lines reference the Place line ("Source Line No." = activity line no.). Quantity can be partial,
/// and the destination bin can be changed (standard bin validation applies). The matching Take lines
/// (receive bin side) receive the same total so the pair registers together.
/// Splitting one line over several bins is not done here: enter the lines as separate put-away lines
/// in Business Central first.
codeunit 50739 "VWMS Handler Put-away" implements "VWMS Operation Handler"
{
    Access = Internal;
    Permissions = tabledata "Warehouse Activity Line" = RM,
                  tabledata "Warehouse Activity Header" = RM;

    var
        Authorization: Codeunit "VWMS Authorization";
        NoSourceErr: Label 'A put-away number and line reference are required to register a put-away.';
        NotFoundErr: Label 'Put-away %1 was not found at location %2.', Comment = '%1 = put-away no, %2 = location';
        LineMissingErr: Label 'Put-away %1 has no line %2.', Comment = '%1 = put-away, %2 = line';
        NotPlaceErr: Label 'Put-away %1 line %2 is not a destination (Place) line.', Comment = '%1 = put-away, %2 = line';
        ItemMismatchErr: Label 'Put-away %1 line %2 is for item %3, not %4.', Comment = '%1 = put-away, %2 = line, %3 = BC item, %4 = staged item';
        OverPutawayErr: Label 'Put-away %1 line %2: you are putting away %3 but only %4 is open.', Comment = '%1 = put-away, %2 = line, %3 = staged qty, %4 = open qty';
        NoTakeErr: Label 'Put-away %1 line %2: the matching Take line does not have %3 open.', Comment = '%1 = put-away, %2 = line, %3 = qty';
        NothingErr: Label 'Nothing was selected to put away.';

    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result"
    var
        ActivityHeader: Record "Warehouse Activity Header";
        ActivityLine: Record "Warehouse Activity Line";
        RegisterTarget: Record "Warehouse Activity Line";
        Line: Record "VWMS Staging Line";
        Register: Codeunit "Whse.-Activity-Register";
        Touched: Integer;
    begin
        Authorization.RequireActiveUser(StagingHeader."WMS User ID");
        Authorization.RequireWarehouse(StagingHeader."WMS User ID", StagingHeader."Location Code");
        Authorization.RequirePermission(StagingHeader."WMS User ID", 'putaway:submit');
        if StagingHeader."Source Document No." = '' then
            Error(NoSourceErr);

        ActivityHeader.SetFilter(Type, '%1|%2', ActivityHeader.Type::"Put-away", ActivityHeader.Type::"Invt. Put-away");
        ActivityHeader.SetRange("No.", StagingHeader."Source Document No.");
        ActivityHeader.SetRange("Location Code", StagingHeader."Location Code");
        if not ActivityHeader.FindFirst() then
            Error(NotFoundErr, StagingHeader."Source Document No.", StagingHeader."Location Code");

        // Only the staged quantities are registered: clear everything first.
        ActivityLine.SetRange("Activity Type", ActivityHeader.Type);
        ActivityLine.SetRange("No.", ActivityHeader."No.");
        if ActivityLine.FindSet(true) then
            repeat
                if ActivityLine."Qty. to Handle" <> 0 then begin
                    ActivityLine.Validate("Qty. to Handle", 0);
                    ActivityLine.Modify(true);
                end;
            until ActivityLine.Next() = 0;

        Line.SetRange("Header Entry No.", StagingHeader."Entry No.");
        if Line.FindSet() then
            repeat
                if Line.Quantity > 0 then begin
                    ApplyLine(ActivityHeader, Line);
                    Touched += 1;
                end;
            until Line.Next() = 0;
        if Touched = 0 then
            Error(NothingErr);

        ActivityHeader."VWMS User ID" := StagingHeader."WMS User ID";
        ActivityHeader.Modify(false);

        RegisterTarget.SetRange("Activity Type", ActivityHeader.Type);
        RegisterTarget.SetRange("No.", ActivityHeader."No.");
        RegisterTarget.FindFirst();
        Register.Run(RegisterTarget);

        StagingHeader."Result Document No." := ActivityHeader."No.";
        exit("VWMS Process Result"::Completed);
    end;

    local procedure ApplyLine(ActivityHeader: Record "Warehouse Activity Header"; Line: Record "VWMS Staging Line")
    var
        PlaceLine: Record "Warehouse Activity Line";
        TakeLines: Record "Warehouse Activity Line";
        ActionType: Enum "Warehouse Action Type";
        Remaining: Decimal;
        Free: Decimal;
        Add: Decimal;
    begin
        if Line."Source Line No." = 0 then
            Error(NoSourceErr);
        if not PlaceLine.Get(ActivityHeader.Type, ActivityHeader."No.", Line."Source Line No.") then
            Error(LineMissingErr, ActivityHeader."No.", Line."Source Line No.");
        if PlaceLine."Action Type" = ActionType::Take then
            Error(NotPlaceErr, ActivityHeader."No.", Line."Source Line No.");
        if PlaceLine."Item No." <> Line."Item No." then
            Error(ItemMismatchErr, ActivityHeader."No.", Line."Source Line No.", PlaceLine."Item No.", Line."Item No.");
        if Line.Quantity > PlaceLine."Qty. Outstanding" then
            Error(OverPutawayErr, ActivityHeader."No.", Line."Source Line No.", Line.Quantity, PlaceLine."Qty. Outstanding");

        // Destination bin: the operator may confirm another bin; standard validation decides if it is allowed.
        if (Line."To Bin Code" <> '') and (Line."To Bin Code" <> PlaceLine."Bin Code") then
            PlaceLine.Validate("Bin Code", Line."To Bin Code");
        PlaceLine.Validate("Qty. to Handle", Line.Quantity);
        PlaceLine.Modify(true);

        // Take side (where the goods are now): same item and document line, same total quantity.
        if PlaceLine."Action Type" = ActionType::Place then begin
            Remaining := Line.Quantity;
            TakeLines.SetRange("Activity Type", PlaceLine."Activity Type");
            TakeLines.SetRange("No.", PlaceLine."No.");
            TakeLines.SetRange("Action Type", ActionType::Take);
            TakeLines.SetRange("Item No.", PlaceLine."Item No.");
            TakeLines.SetRange("Whse. Document Type", PlaceLine."Whse. Document Type");
            TakeLines.SetRange("Whse. Document No.", PlaceLine."Whse. Document No.");
            TakeLines.SetRange("Whse. Document Line No.", PlaceLine."Whse. Document Line No.");
            if PlaceLine."Lot No." <> '' then
                TakeLines.SetRange("Lot No.", PlaceLine."Lot No.");
            if PlaceLine."Serial No." <> '' then
                TakeLines.SetRange("Serial No.", PlaceLine."Serial No.");
            if TakeLines.FindSet(true) then
                repeat
                    Free := TakeLines."Qty. Outstanding" - TakeLines."Qty. to Handle";
                    if (Remaining > 0) and (Free > 0) then begin
                        Add := Remaining;
                        if Add > Free then
                            Add := Free;
                        TakeLines.Validate("Qty. to Handle", TakeLines."Qty. to Handle" + Add);
                        TakeLines.Modify(true);
                        Remaining -= Add;
                    end;
                until (TakeLines.Next() = 0) or (Remaining = 0);
            if Remaining > 0 then
                Error(NoTakeErr, ActivityHeader."No.", Line."Source Line No.", Line.Quantity);
        end;
    end;
}

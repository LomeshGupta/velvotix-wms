page 50705 "VWMS Transaction Log"
{
    Caption = 'WMS Transaction Log';
    PageType = List;
    ApplicationArea = All;
    SourceTable = "VWMS Transaction Log";
    Editable = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            repeater(Entries)
            {
                field("Logged At"; Rec."Logged At") { ApplicationArea = All; }
                field("Transaction Entry No."; Rec."Transaction Entry No.") { ApplicationArea = All; }
                field("Event Name"; Rec."Event Name") { ApplicationArea = All; }
                field("From Status"; Rec."From Status") { ApplicationArea = All; }
                field("To Status"; Rec."To Status") { ApplicationArea = All; }
                field("Actor ID"; Rec."Actor ID") { ApplicationArea = All; }
                field("Message Text"; Rec."Message Text") { ApplicationArea = All; }
            }
        }
    }
}

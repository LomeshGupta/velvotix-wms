page 50722 "VWMS Set Password Dialog"
{
    Caption = 'Set WMS Password';
    PageType = StandardDialog;
    ApplicationArea = All;

    layout
    {
        area(Content)
        {
            group(Password)
            {
                Caption = 'Password';
                field(NewPassword; NewPassword)
                {
                    ApplicationArea = All;
                    Caption = 'New Password';
                    ExtendedDatatype = Masked;
                    ToolTip = 'Enter at least 12 characters. The password will be hashed in Business Central.';
                }
                field(ConfirmPassword; ConfirmPassword)
                {
                    ApplicationArea = All;
                    Caption = 'Confirm Password';
                    ExtendedDatatype = Masked;
                }
            }
        }
    }

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    begin
        if CloseAction <> Action::OK then
            exit(true);
        if StrLen(NewPassword) < 12 then
            Error('The WMS password must contain at least 12 characters.');
        if StrLen(NewPassword) > 128 then
            Error('The WMS password cannot exceed 128 characters.');
        if NewPassword <> ConfirmPassword then
            Error('The password and confirmation do not match.');
        exit(true);
    end;

    procedure GetPassword(): Text
    begin
        exit(NewPassword);
    end;

    procedure ClearPassword()
    begin
        Clear(NewPassword);
        Clear(ConfirmPassword);
    end;

    var
        NewPassword: Text[128];
        ConfirmPassword: Text[128];
}

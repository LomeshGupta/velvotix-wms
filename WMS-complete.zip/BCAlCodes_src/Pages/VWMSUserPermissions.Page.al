page 50703 "VWMS User Permissions"
{
    Caption = 'WMS User Permissions';
    PageType = List;
    ApplicationArea = All;
    SourceTable = "VWMS User Permission";

    layout
    {
        area(Content)
        {
            repeater(Lines)
            {
                field("User ID"; Rec."User ID") { ApplicationArea = All; }
                field("Permission Code"; Rec."Permission Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Pick from the catalog. The exact identifier is stored.';
                }
                field(CategoryCtl; PermCategory) { ApplicationArea = All; Caption = 'Category'; Editable = false; }
                field(DisplayNameCtl; DisplayName) { ApplicationArea = All; Caption = 'Display Name'; Editable = false; }
                field(DescriptionCtl; PermDescription) { ApplicationArea = All; Caption = 'Description'; Editable = false; }
                field(AllowedCtl; Allowed) { ApplicationArea = All; Caption = 'Allowed Operations'; Editable = false; }
                field(NotAllowedCtl; NotAllowed) { ApplicationArea = All; Caption = 'Not Allowed'; Editable = false; }
                field(DependsCtl; DependsOn) { ApplicationArea = All; Caption = 'Requires'; Editable = false; }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(AddPermissions)
            {
                Caption = 'Add Permissions...';
                ApplicationArea = All;
                Image = Add;
                ToolTip = 'Pick one or more permissions from the catalog (hold Ctrl to select several).';
                trigger OnAction()
                var
                    Defs: Page "VWMS Permission Defs";
                    Selected: Record "VWMS Permission Def.";
                    Mgt: Codeunit "VWMS Permission Mgt";
                begin
                    Defs.LookupMode(true);
                    if Defs.RunModal() <> Action::LookupOK then
                        exit;
                    Defs.GetSelection(Selected);
                    Message('%1 permission(s) added.', AddUser(Mgt, Selected));
                    CurrPage.Update(false);
                end;
            }
            action(AddCategory)
            {
                Caption = 'Add Whole Category...';
                ApplicationArea = All;
                Image = AddAction;
                ToolTip = 'Adds every permission the WMS enforces in a category, for example all Outbound permissions.';
                trigger OnAction()
                var
                    Selected: Record "VWMS Permission Def.";
                    Mgt: Codeunit "VWMS Permission Mgt";
                    Cat: Enum "VWMS Permission Category";
                    Choice: Integer;
                begin
                    Choice := StrMenu('General,Master Data,Inbound,Outbound,Inventory,Counting,Quality and Returns,Integration,Reporting,Administration', 4, 'Add all enforced permissions of which category?');
                    if Choice = 0 then
                        exit;
                    Cat := Enum::"VWMS Permission Category".FromInteger(Choice);
                    Mgt.FilterCategory(Selected, Cat, true);
                    Message('%1 permission(s) added.', AddUser(Mgt, Selected));
                    CurrPage.Update(false);
                end;
            }
        }
    }

    var
        PermCategory: Enum "VWMS Permission Category";
        DisplayName: Text[80];
        PermDescription: Text[250];
        Allowed: Text[250];
        NotAllowed: Text[250];
        DependsOn: Code[50];

    local procedure Owner(): Code[50]
    begin
        if Rec.GetFilter("User ID") <> '' then
            exit(CopyStr(Rec.GetRangeMin("User ID"), 1, MaxStrLen(Rec."User ID")));
        exit(Rec."User ID");
    end;

    local procedure AddUser(var Mgt: Codeunit "VWMS Permission Mgt"; var Selected: Record "VWMS Permission Def."): Integer
    begin
        exit(Mgt.AddToUser(Owner(), Selected));
    end;

    trigger OnAfterGetRecord()
    var
        PermDef: Record "VWMS Permission Def.";
    begin
        Clear(PermCategory);
        Clear(DisplayName);
        Clear(PermDescription);
        Clear(Allowed);
        Clear(NotAllowed);
        Clear(DependsOn);
        if PermDef.Get(Rec."Permission Code") then begin
            PermCategory := PermDef.Category;
            DisplayName := PermDef."Display Name";
            PermDescription := PermDef.Description;
            Allowed := PermDef."Allowed Operations";
            NotAllowed := PermDef."Not Allowed";
            DependsOn := PermDef."Depends On";
        end;
    end;
}

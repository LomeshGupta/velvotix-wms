page 50723 "VWMS Permission Defs"
{
    Caption = 'WMS Permission Catalog';
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Administration;
    SourceTable = "VWMS Permission Def.";
    Editable = false;
    SourceTableView = sorting(Category, "Permission Code");

    layout
    {
        area(Content)
        {
            group(Filters)
            {
                ShowCaption = false;
                field(CategoryFilterCtl; CategoryFilter)
                {
                    ApplicationArea = All;
                    Caption = 'Category';
                    ToolTip = 'Show only one category, for example Outbound.';
                    trigger OnValidate()
                    begin
                        ApplyFilters();
                    end;
                }
                field(EnforcedOnlyCtl; EnforcedOnly)
                {
                    ApplicationArea = All;
                    Caption = 'Only permissions the WMS enforces';
                    trigger OnValidate()
                    begin
                        ApplyFilters();
                    end;
                }
            }
            repeater(Permissions)
            {
                field(Category; Rec.Category) { ApplicationArea = All; }
                field("Permission Code"; Rec."Permission Code") { ApplicationArea = All; ToolTip = 'Exact identifier stored on roles and users.'; }
                field("Display Name"; Rec."Display Name") { ApplicationArea = All; }
                field(Enforced; Rec.Enforced) { ApplicationArea = All; }
                field(Description; Rec.Description) { ApplicationArea = All; }
                field("Allowed Operations"; Rec."Allowed Operations") { ApplicationArea = All; }
                field("Not Allowed"; Rec."Not Allowed") { ApplicationArea = All; }
                field("Depends On"; Rec."Depends On") { ApplicationArea = All; }
                field("Also Accepted As"; Rec."Also Accepted As") { ApplicationArea = All; }
                field("Can Read"; Rec."Can Read") { ApplicationArea = All; }
                field("Can Create"; Rec."Can Create") { ApplicationArea = All; }
                field("Can Modify"; Rec."Can Modify") { ApplicationArea = All; }
                field("Can Delete"; Rec."Can Delete") { ApplicationArea = All; }
                field("Can Register"; Rec."Can Register") { ApplicationArea = All; }
                field("Can Post"; Rec."Can Post") { ApplicationArea = All; }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(RefreshCatalog)
            {
                Caption = 'Refresh Catalog';
                ApplicationArea = All;
                Image = Refresh;
                ToolTip = 'Re-creates missing catalog entries and updates descriptions and categories. Existing assignments are not changed.';
                trigger OnAction()
                var
                    Seed: Codeunit "VWMS Seed Defaults";
                begin
                    Seed.SeedPermissionDefs();
                    Seed.SyncAdminRole();
                    CurrPage.Update(false);
                end;
            }
        }
    }

    var
        CategoryFilter: Enum "VWMS Permission Category";
        EnforcedOnly: Boolean;

    /// Used by role/user pages in lookup mode: returns the rows the person ticked.
    procedure GetSelection(var Selected: Record "VWMS Permission Def.")
    begin
        CurrPage.SetSelectionFilter(Selected);
    end;

    local procedure ApplyFilters()
    begin
        Rec.Reset();
        if CategoryFilter <> CategoryFilter::" " then
            Rec.SetRange(Category, CategoryFilter);
        if EnforcedOnly then
            Rec.SetRange(Enforced, true);
        CurrPage.Update(false);
    end;
}

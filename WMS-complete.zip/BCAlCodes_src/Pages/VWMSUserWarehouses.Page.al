page 50702 "VWMS User Warehouses"
{
    Caption = 'Assigned Warehouses';
    PageType = ListPart;
    ApplicationArea = All;
    SourceTable = "VWMS User Warehouse";
    editable = true;

    layout
    {
        area(Content)
        {
            repeater(Lines)
            {
                field("Location Code"; Rec."Location Code") { ApplicationArea = All; }
                field("Bin Filter"; Rec."Bin Filter") { ApplicationArea = All; }
            }
        }
    }
}

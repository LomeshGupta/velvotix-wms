page 50704 "VWMS Transaction List"
{
    Caption = 'WMS Transactions';
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "VWMS Staging Header";
    Editable = false;
    SourceTableView = sorting("Entry No.") order(descending);

    layout
    {
        area(Content)
        {
            repeater(Transactions)
            {
                field("Entry No."; Rec."Entry No.") { ApplicationArea = All; }
                field("Operation Type"; Rec."Operation Type") { ApplicationArea = All; }
                field(Status; Rec.Status) { ApplicationArea = All; StyleExpr = StatusStyle; }
                field("Location Code"; Rec."Location Code") { ApplicationArea = All; }
                field("WMS User ID"; Rec."WMS User ID") { ApplicationArea = All; }
                field("Attempt Count"; Rec."Attempt Count") { ApplicationArea = All; }
                field("Error Code"; Rec."Error Code") { ApplicationArea = All; }
                field("Error Message"; Rec."Error Message") { ApplicationArea = All; }
                field("Result Document No."; Rec."Result Document No.") { ApplicationArea = All; }
                field("Requested At"; Rec."Requested At") { ApplicationArea = All; }
                field("Completed At"; Rec."Completed At") { ApplicationArea = All; }
                field("Idempotency Key"; Rec."Idempotency Key") { ApplicationArea = All; Visible = false; }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(Log)
            {
                Caption = 'Audit Log';
                ApplicationArea = All;
                Image = Log;
                RunObject = page "VWMS Transaction Log";
                RunPageLink = "Transaction Entry No." = field("Entry No.");
            }
            action(Retry)
            {
                Caption = 'Retry';
                ApplicationArea = All;
                Image = ReOpen;
                trigger OnAction()
                var
                    Mgt: Codeunit "VWMS Transaction Mgt";
                begin
                    Mgt.AdminResolve(Rec, 'retry', CopyStr(UserId(), 1, 50), '', 'Retried from the transaction list');
                    CurrPage.Update(false);
                end;
            }
        }
    }

    var
        StatusStyle: Text;

    trigger OnAfterGetRecord()
    begin
        case Rec.Status of
            Rec.Status::Failed, Rec.Status::"Requires Reconciliation":
                StatusStyle := 'Unfavorable';
            Rec.Status::Completed:
                StatusStyle := 'Favorable';
            else
                StatusStyle := 'Standard';
        end;
    end;
}

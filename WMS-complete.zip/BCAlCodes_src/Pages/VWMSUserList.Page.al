/// Administration page. Password and PIN hashes are deliberately not shown here.
page 50701 "VWMS User List"
{
    Caption = 'WMS Users';
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Administration;
    SourceTable = "VWMS User";

    layout
    {
        area(Content)
        {
            repeater(Users)
            {
                field("User ID"; Rec."User ID") { ApplicationArea = All; }
                field("Display Name"; Rec."Display Name") { ApplicationArea = All; }
                field(Status; Rec.Status) { ApplicationArea = All; }
                field("Default Location Code"; Rec."Default Location Code") { ApplicationArea = All; }
                field("Supervisor User ID"; Rec."Supervisor User ID") { ApplicationArea = All; }
                field("Failed Login Attempts"; Rec."Failed Login Attempts") { ApplicationArea = All; Editable = false; }
                field("Locked Until"; Rec."Locked Until") { ApplicationArea = All; }
                field("Last Login At"; Rec."Last Login At") { ApplicationArea = All; Editable = false; }
            }
            part(Warehouses; "VWMS User Warehouses")
            {
                ApplicationArea = All;
                SubPageLink = "User ID" = field("User ID");
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(Permissions)
            {
                Caption = 'Permissions';
                ApplicationArea = All;
                Image = Permission;
                RunObject = page "VWMS User Permissions";
                RunPageLink = "User ID" = field("User ID");
            }
            action(EffectivePermissions)
            {
                Caption = 'Effective Permissions';
                ApplicationArea = All;
                Image = ViewDetails;
                ToolTip = 'Shows everything this user can do, from direct grants, roles and administrator rights.';
                trigger OnAction()
                var
                    EffectivePage: Page "VWMS Effective Permissions";
                begin
                    EffectivePage.SetUser(Rec."User ID");
                    EffectivePage.Run();
                end;
            }
            action(Roles)
            {
                Caption = 'Roles';
                ApplicationArea = All;
                Image = Users;
                RunObject = page "VWMS User Roles";
                RunPageLink = "User ID" = field("User ID");
            }
            action(SetPassword)
            {
                Caption = 'Set Password';
                ApplicationArea = All;
                Image = Password;
                ToolTip = 'Set the password used to sign in to the Velvotix WMS app. The password is hashed in Business Central.';
                trigger OnAction()
                var
                    PasswordDialog: Page "VWMS Set Password Dialog";
                    Authentication: Codeunit "VWMS Authentication API";
                    NewPassword: Text;
                begin
                    if PasswordDialog.RunModal() <> Action::OK then
                        exit;
                    NewPassword := PasswordDialog.GetPassword();
                    Authentication.SetPassword(Rec."User ID", NewPassword);
                    Clear(NewPassword);
                    PasswordDialog.ClearPassword();
                    Message('The WMS password has been set for user %1.', Rec."User ID");
                end;
            }
            action(Unlock)
            {
                Caption = 'Unlock';
                ApplicationArea = All;
                Image = Approve;
                trigger OnAction()
                begin
                    Rec."Failed Login Attempts" := 0;
                    Rec."Locked Until" := 0DT;
                    Rec.Modify();
                end;
            }
        }
    }
}

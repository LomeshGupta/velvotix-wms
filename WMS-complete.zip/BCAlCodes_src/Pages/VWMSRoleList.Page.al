page 50706 "VWMS Role List"
{
    Caption = 'WMS Roles';
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Administration;
    SourceTable = "VWMS Role";

    layout
    {
        area(Content)
        {
            repeater(Roles)
            {
                field("Role Code"; Rec."Role Code") { ApplicationArea = All; }
                field("Role Name"; Rec."Role Name") { ApplicationArea = All; }
                field(Description; Rec.Description) { ApplicationArea = All; }
                field(Enabled; Rec.Enabled) { ApplicationArea = All; }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(SeedRoles)
            {
                Caption = 'Create Standard Roles';
                ApplicationArea = All;
                Image = Setup;
                ToolTip = 'Adds the standard least-privilege roles (read-only, picker, shipment operator, supervisor, administrator) if they do not exist. Existing roles are not changed.';
                trigger OnAction()
                var
                    Seed: Codeunit "VWMS Seed Defaults";
                begin
                    Seed.SeedDefaultRoles();
                    CurrPage.Update(false);
                end;
            }
            action(Catalog)
            {
                Caption = 'Permission Catalog';
                ApplicationArea = All;
                Image = List;
                RunObject = page "VWMS Permission Defs";
            }
            action(Permissions)
            {
                Caption = 'Permissions';
                ApplicationArea = All;
                Image = Permission;
                RunObject = page "VWMS Role Permissions";
                RunPageLink = "Role Code" = field("Role Code");
            }
        }
    }
}

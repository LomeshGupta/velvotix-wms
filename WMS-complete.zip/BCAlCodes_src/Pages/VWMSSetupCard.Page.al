page 50700 "VWMS Setup Card"
{
    Caption = 'WMS Setup';
    PageType = Card;
    ApplicationArea = All;
    UsageCategory = Administration;
    SourceTable = "VWMS Setup";
    InsertAllowed = false;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';
                field("WMS Enabled"; Rec."WMS Enabled")
                {
                    ApplicationArea = All;
                    ToolTip = 'Enables WMS submissions and worker processing. Disabling never removes unrelated integration registrations.';
                }
                field("Default Location Code"; Rec."Default Location Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Location used when a user has no default.';
                }
                field("Default Bin Code"; Rec."Default Bin Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Optional. Only bins of the default location are offered.';
                }
                field("Require Packing Before Ship"; Rec."Require Packing Before Ship") { ApplicationArea = All; }
                field("Enforce Bins"; Rec."Enforce Bins")
                {
                    ApplicationArea = All;
                    ToolTip = 'Require bin codes on warehouse operations.';
                }
            }
            group(Processing)
            {
                Caption = 'Processing';
                field("Auto Processing Enabled"; Rec."Auto Processing Enabled")
                {
                    ApplicationArea = All;
                    ToolTip = 'When off, workers claim nothing and submissions wait in the queue.';
                }
                field("Max Attempts"; Rec."Max Attempts")
                {
                    ApplicationArea = All;
                    ToolTip = 'Transient failures are retried up to this many attempts, then marked Failed for administrator review.';
                }
                field("Lease Seconds"; Rec."Lease Seconds")
                {
                    ApplicationArea = All;
                    ToolTip = 'How long a worker may hold a transaction before it is considered abandoned.';
                }
                field("Retention Days"; Rec."Retention Days")
                {
                    ApplicationArea = All;
                    ToolTip = 'Completed and cancelled transactions older than this are purged. The audit log is kept.';
                }
            }
            group(Security)
            {
                Caption = 'Security and Audit';
                field("Audit Enabled"; Rec."Audit Enabled")
                {
                    ApplicationArea = All;
                }
                field("Session Idle Minutes"; Rec."Session Idle Minutes")
                {
                    ApplicationArea = All;
                }
                field("Max Failed Logins"; Rec."Max Failed Logins")
                {
                    ApplicationArea = All;
                }
            }
        }
    }

    actions
    {
        area(Navigation)
        {
            action(Users)
            {
                Caption = 'WMS Users';
                ApplicationArea = All;
                Image = Users;
                RunObject = page "VWMS User List";
            }
            action(Transactions)
            {
                Caption = 'Transactions';
                ApplicationArea = All;
                Image = List;
                RunObject = page "VWMS Transaction List";
            }
        }
    }

    trigger OnOpenPage()
    begin
        Rec.Reset();
        if not Rec.Get() then begin
            Rec.Init();
            Rec.Insert();
        end;
    end;
}

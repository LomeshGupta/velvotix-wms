page 50708 "VWMS User Roles"
{
    Caption = 'WMS User Roles';
    PageType = List;
    ApplicationArea = All;
    SourceTable = "VWMS User Role";
    SourceTableView = sorting("User ID", "Role Code");

    layout
    {
        area(Content)
        {
            repeater(Roles)
            {
                field("User ID"; Rec."User ID") { ApplicationArea = All; Editable = false; }
                field("Role Code"; Rec."Role Code") { ApplicationArea = All; }
            }
        }
    }
}

page 50725 "VWMS Effective Permissions"
{
    Caption = 'WMS Effective Permissions';
    PageType = List;
    ApplicationArea = All;
    SourceTable = "VWMS User Permission";
    SourceTableTemporary = true;
    Editable = false;

    layout
    {
        area(Content)
        {
            repeater(Permissions)
            {
                field("Permission Code"; Rec."Permission Code") { ApplicationArea = All; }
                field(Source; SourceText) { ApplicationArea = All; Caption = 'Granted By'; }
            }
        }
    }

    var
        TargetUser: Code[50];
        SourceText: Text[100];

    procedure SetUser(UserId: Code[50])
    begin
        TargetUser := UserId;
    end;

    trigger OnOpenPage()
    var
        PermDef: Record "VWMS Permission Def.";
        Authorization: Codeunit "VWMS Authorization";
    begin
        if PermDef.FindSet() then
            repeat
                if Authorization.HasPermission(TargetUser, PermDef."Permission Code") then begin
                    Rec.Init();
                    Rec."User ID" := TargetUser;
                    Rec."Permission Code" := PermDef."Permission Code";
                    Rec.Insert();
                end;
            until PermDef.Next() = 0;
        if Rec.FindFirst() then;
    end;

    trigger OnAfterGetRecord()
    var
        Direct: Record "VWMS User Permission";
    begin
        if Direct.Get(TargetUser, Rec."Permission Code") then
            SourceText := 'Direct assignment'
        else
            SourceText := 'Role (or administrator)';
    end;
}

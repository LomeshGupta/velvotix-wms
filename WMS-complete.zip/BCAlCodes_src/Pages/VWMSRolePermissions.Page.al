page 50707 "VWMS Role Permissions"
{
    Caption = 'WMS Role Permissions';
    PageType = List;
    ApplicationArea = All;
    SourceTable = "VWMS Role Permission";
    SourceTableView = sorting("Role Code", "Permission Code");

    layout
    {
        area(Content)
        {
            repeater(Permissions)
            {
                field("Role Code"; Rec."Role Code") { ApplicationArea = All; Editable = false; }
                field("Permission Code"; Rec."Permission Code")
                {
                    ApplicationArea = All;
                    ToolTip = 'Pick from the catalog. The exact identifier is stored; see the columns to the right for what it allows.';
                }
                field(CategoryCtl; PermCategory) { ApplicationArea = All; Caption = 'Category'; Editable = false; }
                field(DisplayNameCtl; DisplayName) { ApplicationArea = All; Caption = 'Display Name'; Editable = false; }
                field(DescriptionCtl; PermDescription) { ApplicationArea = All; Caption = 'Description'; Editable = false; }
                field(AllowedCtl; Allowed) { ApplicationArea = All; Caption = 'Allowed Operations'; Editable = false; }
                field(NotAllowedCtl; NotAllowed) { ApplicationArea = All; Caption = 'Not Allowed'; Editable = false; }
                field(DependsCtl; DependsOn) { ApplicationArea = All; Caption = 'Requires'; Editable = false; }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(AddPermissions)
            {
                Caption = 'Add Permissions...';
                ApplicationArea = All;
                Image = Add;
                ToolTip = 'Pick one or more permissions from the catalog (hold Ctrl to select several).';
                trigger OnAction()
                var
                    Defs: Page "VWMS Permission Defs";
                    Selected: Record "VWMS Permission Def.";
                    Mgt: Codeunit "VWMS Permission Mgt";
                begin
                    Defs.LookupMode(true);
                    if Defs.RunModal() <> Action::LookupOK then
                        exit;
                    Defs.GetSelection(Selected);
                    Message('%1 permission(s) added.', AddRole(Mgt, Selected));
                    CurrPage.Update(false);
                end;
            }
            action(AddCategory)
            {
                Caption = 'Add Whole Category...';
                ApplicationArea = All;
                Image = AddAction;
                ToolTip = 'Adds every permission the WMS enforces in a category, for example all Outbound permissions.';
                trigger OnAction()
                var
                    Selected: Record "VWMS Permission Def.";
                    Mgt: Codeunit "VWMS Permission Mgt";
                    Cat: Enum "VWMS Permission Category";
                    Choice: Integer;
                begin
                    Choice := StrMenu('General,Master Data,Inbound,Outbound,Inventory,Counting,Quality and Returns,Integration,Reporting,Administration', 4, 'Add all enforced permissions of which category?');
                    if Choice = 0 then
                        exit;
                    Cat := Enum::"VWMS Permission Category".FromInteger(Choice);
                    Mgt.FilterCategory(Selected, Cat, true);
                    Message('%1 permission(s) added.', AddRole(Mgt, Selected));
                    CurrPage.Update(false);
                end;
            }
        }
    }

    var
        PermCategory: Enum "VWMS Permission Category";
        DisplayName: Text[80];
        PermDescription: Text[250];
        Allowed: Text[250];
        NotAllowed: Text[250];
        DependsOn: Code[50];

    local procedure Owner(): Code[30]
    begin
        if Rec.GetFilter("Role Code") <> '' then
            exit(CopyStr(Rec.GetRangeMin("Role Code"), 1, MaxStrLen(Rec."Role Code")));
        exit(Rec."Role Code");
    end;

    local procedure AddRole(var Mgt: Codeunit "VWMS Permission Mgt"; var Selected: Record "VWMS Permission Def."): Integer
    begin
        exit(Mgt.AddToRole(Owner(), Selected));
    end;

    trigger OnAfterGetRecord()
    var
        PermDef: Record "VWMS Permission Def.";
    begin
        Clear(PermCategory);
        Clear(DisplayName);
        Clear(PermDescription);
        Clear(Allowed);
        Clear(NotAllowed);
        Clear(DependsOn);
        if PermDef.Get(Rec."Permission Code") then begin
            PermCategory := PermDef.Category;
            DisplayName := PermDef."Display Name";
            PermDescription := PermDef.Description;
            Allowed := PermDef."Allowed Operations";
            NotAllowed := PermDef."Not Allowed";
            DependsOn := PermDef."Depends On";
        end;
    end;
}

/// Cumulative quantity confirmed at the packing station. Business Central has no standard "packed" step,
/// so this WMS-owned field records it; shipping can be limited to it (see "Require Packing Before Ship").
tableextension 50746 "VWMS Whse Shpt Line Ext" extends "Warehouse Shipment Line"
{
    fields
    {
        field(50701; "VWMS Qty. Packed"; Decimal)
        {
            Caption = 'WMS Qty. Packed';
            DecimalPlaces = 0 : 5;
            Editable = false;
        }
    }
}

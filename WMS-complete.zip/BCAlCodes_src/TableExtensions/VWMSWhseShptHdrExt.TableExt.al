/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50740 "VWMS Whse Shpt Hdr Ext" extends "Warehouse Shipment Header"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50742 "VWMS Whse Act Hdr Ext" extends "Warehouse Activity Header"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

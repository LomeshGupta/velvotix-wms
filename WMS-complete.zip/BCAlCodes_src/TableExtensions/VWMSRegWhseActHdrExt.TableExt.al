/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50743 "VWMS Reg Whse Act Hdr Ext" extends "Registered Whse. Activity Hdr."
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

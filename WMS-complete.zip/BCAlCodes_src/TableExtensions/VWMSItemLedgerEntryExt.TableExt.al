/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50745 "VWMS Item Ledger Entry Ext" extends "Item Ledger Entry"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50741 "VWMS Posted Whse Shpt Hdr Ext" extends "Posted Whse. Shipment Header"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50744 "VWMS Warehouse Entry Ext" extends "Warehouse Entry"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

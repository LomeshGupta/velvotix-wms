/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50749 "VWMS Purch Rcpt Hdr Ext" extends "Purch. Rcpt. Header"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

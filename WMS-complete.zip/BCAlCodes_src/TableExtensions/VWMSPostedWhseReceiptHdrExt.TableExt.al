/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50748 "VWMS Posted Whse Rcpt Hdr Ext" extends "Posted Whse. Receipt Header"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

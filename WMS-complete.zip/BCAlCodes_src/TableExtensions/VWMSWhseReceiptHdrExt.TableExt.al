/// Records which WMS user (not the shared integration account) performed the work.
tableextension 50747 "VWMS Whse Receipt Hdr Ext" extends "Warehouse Receipt Header"
{
    fields
    {
        field(50700; "VWMS User ID"; Code[50])
        {
            Caption = 'WMS User ID';
            DataClassification = EndUserIdentifiableInformation;
            Editable = false;
        }
    }
}

permissionset 50702 "VWMS READ"
{
    Assignable = true;
    Caption = 'WMS Read-only Auditor';

    Permissions =
        tabledata "VWMS Setup" = R,
        tabledata "VWMS Staging Header" = R,
        tabledata "VWMS Staging Line" = R,
        tabledata "VWMS Transaction Log" = R,
        tabledata "VWMS Permission Def." = R,
        page "VWMS Permission Defs" = X,
        page "VWMS Setup Card" = X,
        page "VWMS Transaction List" = X,
        page "VWMS Transaction Log" = X;
}

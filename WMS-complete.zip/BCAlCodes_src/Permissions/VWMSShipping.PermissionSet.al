permissionset 50704 "VWMS SHIPPING"
{
    Assignable = true;
    Caption = 'WMS Shipment Operator (view shipments and queue)';

    Permissions =
        tabledata "VWMS Setup" = R,
        tabledata "VWMS Staging Header" = R,
        tabledata "VWMS Staging Line" = R,
        tabledata "VWMS Transaction Log" = R,
        tabledata "VWMS Permission Def." = R,
        tabledata "Warehouse Shipment Header" = R,
        tabledata "Warehouse Shipment Line" = R,
        page "VWMS Transaction List" = X,
        page "VWMS Transaction Log" = X;
}

/// Business Central-side access for staff who inspect WMS work in the BC client. The warehouse
/// operator's picking/shipping rights in the web app come from WMS roles (see VWMS Role List); this
/// set deliberately grants no BC posting rights. The web app's service principal performs the BC work.
permissionset 50703 "VWMS OPERATOR"
{
    Assignable = true;
    Caption = 'WMS Operator (view own queue)';

    Permissions =
        tabledata "VWMS Setup" = R,
        tabledata "VWMS Staging Header" = R,
        tabledata "VWMS Staging Line" = R,
        tabledata "VWMS Transaction Log" = R,
        tabledata "VWMS Permission Def." = R,
        page "VWMS Transaction List" = X,
        page "VWMS Transaction Log" = X;
}

/// Supervisors can cancel and retry through the transaction codeunit but cannot delete records
/// or edit setup, users and roles.
permissionset 50705 "VWMS SUPERVISOR"
{
    Assignable = true;
    Caption = 'WMS Supervisor';

    Permissions =
        tabledata "VWMS Setup" = R,
        tabledata "VWMS Staging Header" = RM,
        tabledata "VWMS Staging Line" = R,
        tabledata "VWMS Transaction Log" = RI,
        tabledata "VWMS User" = R,
        tabledata "VWMS User Warehouse" = R,
        tabledata "VWMS Role" = R,
        tabledata "VWMS Role Permission" = R,
        tabledata "VWMS User Role" = R,
        tabledata "VWMS Permission Def." = R,
        tabledata "Warehouse Shipment Header" = R,
        tabledata "Warehouse Shipment Line" = R,
        page "VWMS Transaction List" = X,
        page "VWMS Transaction Log" = X,
        page "VWMS Permission Defs" = X,
        codeunit "VWMS Transaction Mgt" = X,
        codeunit "VWMS Authorization" = X;
}

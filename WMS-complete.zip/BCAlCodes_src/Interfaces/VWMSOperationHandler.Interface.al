/// One handler per operation type. Handlers run inside the Processor's transaction
/// and must call STANDARD Business Central posting/registration routines only.
/// They never write to ledger tables directly.
interface "VWMS Operation Handler"
{
    /// Validates and executes the staged operation. Sets Header."Result Document No."
    /// on success. Must not Commit; the Processor owns the transaction boundary.
    procedure Process(var StagingHeader: Record "VWMS Staging Header"): Enum "VWMS Process Result";
}

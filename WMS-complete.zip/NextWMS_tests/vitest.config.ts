// Run from the project root:  npx vitest run --config tests/vitest.config.ts
// Needs vitest, zod, next, @node-rs/argon2 (already project dependencies except vitest).
import { defineConfig } from "vitest/config";
import path from "node:path";
export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "../src"), "server-only": path.resolve(__dirname, "server-only-stub.ts") } },
  test: { environment: "node", include: ["tests/api/**/*.test.ts"], testTimeout: 30000 },
});

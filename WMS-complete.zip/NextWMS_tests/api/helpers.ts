import { NextRequest } from "next/server";
process.env.WMS_BC_MODE = "mock";
process.env.NODE_ENV = "test";
process.env.WMS_SESSION_SECRET = "x".repeat(40);

const sessions = new Map<string, Awaited<ReturnType<typeof loginOnce>>>();

/** One login per user per test run: the login endpoint is rate limited, exactly as it should be. */
export async function login(userId: string, password: string) {
  const cached = sessions.get(userId);
  if (cached) return cached;
  const s = await loginOnce(userId, password);
  sessions.set(userId, s);
  return s;
}

async function loginOnce(userId: string, password: string) {
  const { POST } = await import("@/app/api/auth/login/route");
  const res = await POST(new NextRequest("http://localhost/api/auth/login", {
    method: "POST", headers: { "content-type": "application/json", origin: "http://localhost", host: "localhost" },
    body: JSON.stringify({ userId, password }),
  }));
  const body = await res.json();
  const cookie = res.headers.get("set-cookie")?.split(";")[0] ?? "";
  return { status: res.status, body, cookie };
}
export function call(path: string, method: string, s: { cookie: string; body: any }, payload?: unknown) {
  return new NextRequest(`http://localhost${path}`, {
    method,
    headers: { "content-type": "application/json", origin: "http://localhost", host: "localhost", cookie: s.cookie, "x-csrf-token": s.body.csrfToken ?? s.body.csrf ?? "" },
    body: payload ? JSON.stringify(payload) : undefined,
  });
}

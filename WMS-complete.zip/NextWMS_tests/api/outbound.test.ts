import { describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { call, login } from "./helpers";
import { expandPermissions } from "@/lib/security/permission-catalog";
import { extractBcMessage } from "@/lib/business-central/client";
import { createPickQuantity, packableQuantity, pickableQuantity, shippableQuantity } from "@/features/transactions/quantities";

const key = () => crypto.randomUUID();
const ops = () => import("@/app/api/wms/operations/route");
const recv = () => import("@/app/api/wms/receiving/route");
const json = async (r: Response) => ({ status: r.status, body: await r.json() });

describe("permissions", () => {
  it("legacy codes count as canonical ones", () => {
    const p = expandPermissions(["OPERATIONS:SUBMIT", "PICKING:REGISTER", "RECEIVING:REGISTER"]);
    expect(p).toEqual(expect.arrayContaining(["transactions:submit", "picking:submit", "receiving:submit"]));
  });
  it("administrator gets everything", () => {
    const p = expandPermissions(["administration:administer"]);
    for (const c of ["picking:submit", "shipping:submit", "receiving:submit", "inventory:adjust", "transactions:cancel", "cyclecounts:approve"]) expect(p).toContain(c);
  });
  it("a picker does not gain shipping", () => {
    expect(expandPermissions(["PICKING:SUBMIT", "TRANSACTIONS:SUBMIT"])).not.toContain("shipping:submit");
  });
});

describe("outbound quantities", () => {
  const line = (o: Record<string, number> = {}) => ({ quantity: 10, qtyToShip: 0, qtyOutstanding: 10, qtyPicked: 0, qtyShipped: 0, pickQty: 0, qtyPacked: 0, ...o });
  it("create pick = outstanding - picked - already on a pick", () => {
    expect(createPickQuantity(line())).toBe(10);
    expect(createPickQuantity(line({ qtyPicked: 3, pickQty: 4 }))).toBe(3);
    expect(createPickQuantity(line({ pickQty: 10 }))).toBe(0);
  });
  it("pick = what is on open picks, never more than outstanding - picked", () => {
    expect(pickableQuantity(line({ pickQty: 6 }))).toBe(6);
    expect(pickableQuantity(line({ pickQty: 0 }))).toBe(0);
    expect(pickableQuantity(line({ qtyPicked: 8, pickQty: 6 }))).toBe(2);
    expect(pickableQuantity({ qtyToShip: 0, qtyOutstanding: 4, qtyPicked: 1 })).toBe(3); // older server without pickQty
  });
  it("partly picked (6 of 10) and partly shipped (4): 4 still to pick, 2 ready to ship", () => {
    const l = line({ quantity: 10, qtyOutstanding: 6, qtyPicked: 6, qtyShipped: 4, pickQty: 4, qtyToShip: 2 });
    expect(pickableQuantity(l)).toBe(4); // old formula (outstanding - picked) gave 0
    expect(shippableQuantity(l)).toBe(2);
    expect(createPickQuantity(l)).toBe(0); // the 4 left are already on the open pick
  });
  it("pack = picked not yet packed", () => {
    expect(packableQuantity(line({ qtyPicked: 6 }))).toBe(6);
    expect(packableQuantity(line({ qtyPicked: 6, qtyPacked: 4 }))).toBe(2);
    expect(packableQuantity(line({ qtyPicked: 0, qtyPacked: 0 }))).toBe(10);
  });
  it("ship = picked minus shipped, limited to packed once packing started, never above outstanding", () => {
    expect(shippableQuantity(line({ qtyPicked: 3, qtyShipped: 1, qtyOutstanding: 4 }))).toBe(2);
    expect(shippableQuantity(line({ qtyPicked: 6, qtyPacked: 4 }))).toBe(4);
    expect(shippableQuantity(line({ qtyPicked: 6, qtyPacked: 4, qtyShipped: 1 }))).toBe(3);
    expect(shippableQuantity(line({ qtyToShip: 5, qtyOutstanding: 4 }))).toBe(4);
    expect(shippableQuantity(line({ qtyPicked: 9, qtyOutstanding: 4 }))).toBe(4);
  });
});

describe("BC error text", () => {
  it("passes short validation messages, hides server faults", () => {
    const body = JSON.stringify({ error: { code: "x", message: "WMS user BOB does not have permission picking:submit.\n CorrelationId: 123" } });
    expect(extractBcMessage(body, 400)).toBe("Business Central: WMS user BOB does not have permission picking:submit.");
    expect(extractBcMessage(body, 500)).toBeUndefined();
    expect(extractBcMessage(body, 403)).toBeUndefined();
  });
});

describe("API routes (mock Business Central)", () => {
  it("rejects unauthenticated calls", async () => {
    const { POST } = await ops();
    const r = await POST(new NextRequest("http://localhost/api/wms/operations", { method: "POST", body: "{}", headers: { "content-type": "application/json", origin: "http://localhost", host: "localhost" } }) as any);
    expect([401, 403]).toContain(r.status);
  });

  it("picker: partial pick is accepted", async () => {
    const s = await login("PICKER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Pick", locationCode: "MAIN", sourceDocumentType: "Warehouse Shipment", sourceDocumentNo: "WS-1001",
      lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000, fromBinCode: "A-01" }],
    }) as any));
    expect(r.status).toBe(202);
  });

  it("pick without a shipment line reference is rejected", async () => {
    const s = await login("PICKER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Pick", locationCode: "MAIN", sourceDocumentNo: "WS-1001", lines: [{ itemNo: "1000", quantity: 1 }],
    }) as any));
    expect(r.status).toBe(400);
  });

  it("picker cannot ship; the message names the missing permission", async () => {
    const s = await login("PICKER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Ship", locationCode: "MAIN", sourceDocumentNo: "WS-1001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }],
    }) as any));
    expect(r.status).toBe(403);
    expect(JSON.stringify(r.body)).toContain("shipping:submit");
  });

  it("picker cannot work in a warehouse they are not assigned to", async () => {
    const s = await login("PICKER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Pick", locationCode: "WEST", sourceDocumentNo: "WS-1", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }],
    }) as any));
    expect(r.status).toBe(403);
  });

  it("shipper (EAST) can submit a partial ship", async () => {
    const s = await login("SHIPPER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Ship", locationCode: "EAST", sourceDocumentNo: "WS-2001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }],
    }) as any));
    expect(r.status).toBe(202);
  });

  it("supervisor-style user can create a pick and pack; others are refused with the permission named", async () => {
    const admin = await login("ADMIN", "MockAdmin!2026");
    const { POST } = await ops();
    for (const operationType of ["Create Pick", "Pack"]) {
      const r = await json(await POST(call("/api/wms/operations", "POST", admin, {
        clientKey: key(), operationType, locationCode: "MAIN", sourceDocumentNo: "WS-1001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }],
      }) as any));
      expect(r.status).toBe(202);
    }
    const shipper = await login("SHIPPER", "Operator!2026");
    const denied = await json(await POST(call("/api/wms/operations", "POST", shipper, {
      clientKey: key(), operationType: "Create Pick", locationCode: "EAST", sourceDocumentNo: "WS-2001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }],
    }) as any));
    expect(denied.status).toBe(403);
    expect(JSON.stringify(denied.body)).toContain("picking:submit");
  });

  it("create pick / pack without a shipment line reference are rejected", async () => {
    const admin = await login("ADMIN", "MockAdmin!2026");
    const { POST } = await ops();
    for (const operationType of ["Create Pick", "Pack"]) {
      const r = await json(await POST(call("/api/wms/operations", "POST", admin, { clientKey: key(), operationType, locationCode: "MAIN", sourceDocumentNo: "WS-1001", lines: [{ itemNo: "1000", quantity: 1 }] }) as any));
      expect(r.status).toBe(400);
    }
  });

  it("same client key twice does not create a second transaction", async () => {
    const s = await login("RECEIVER", "Operator!2026");
    const { POST } = await recv();
    const payload = { clientKey: key(), locationCode: "MAIN", sourceDocumentNo: "PO1001", lines: [{ itemNo: "1000", quantity: 2 }] };
    const a = await json(await POST(call("/api/wms/receiving", "POST", s, payload) as any));
    const b = await json(await POST(call("/api/wms/receiving", "POST", s, payload) as any));
    expect(a.status).toBe(202);
    expect(b.body.transactionId).toBe(a.body.transactionId);
  });

  it("auditor cannot receive and is told which permission is missing", async () => {
    const s = await login("AUDITOR", "Auditor!2026");
    const { POST } = await recv();
    const r = await json(await POST(call("/api/wms/receiving", "POST", s, { clientKey: key(), locationCode: "MAIN", lines: [{ itemNo: "1000", quantity: 1 }] }) as any));
    expect(r.status).toBe(403);
    expect(JSON.stringify(r.body)).toContain("receiving:submit");
  });

  it("admin can submit any outbound operation", async () => {
    const s = await login("ADMIN", "MockAdmin!2026");
    const { POST } = await ops();
    for (const operationType of ["Pick", "Ship"]) {
      const r = await json(await POST(call("/api/wms/operations", "POST", s, {
        clientKey: key(), operationType, locationCode: "MAIN", sourceDocumentNo: "WS-1001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }],
      }) as any));
      expect(r.status).toBe(202);
    }
  });

  it("partly picked and shipped shipment line exposes quantities that give the right remainder", async () => {
    const s = await login("PICKER", "Operator!2026");
    const sl = await import("@/app/api/wms/shipment-lines/route");
    const r = await json(await sl.GET(call("/api/wms/shipment-lines?locationCode=MAIN&number=WS-1003", "GET", s) as any));
    expect(r.status).toBe(200);
    const l = r.body.lines[0];
    expect(pickableQuantity(l)).toBe(4);
    expect(shippableQuantity(l)).toBe(2);
  });

  it("shipments, shipment lines (with picked/shipped) and bins load", async () => {
    const s = await login("PICKER", "Operator!2026");
    const sh = await import("@/app/api/wms/shipments/route");
    expect((await json(await sh.GET(call("/api/wms/shipments?locationCode=MAIN", "GET", s) as any))).status).toBe(200);
    const sl = await import("@/app/api/wms/shipment-lines/route");
    const lines = await json(await sl.GET(call("/api/wms/shipment-lines?locationCode=MAIN&number=WS-1002", "GET", s) as any));
    expect(lines.status).toBe(200);
    expect(lines.body.lines[0]).toHaveProperty("qtyShipped");
    const b = await import("@/app/api/wms/bins/route");
    const bins = await json(await b.GET(call("/api/wms/bins?locationCode=MAIN", "GET", s) as any));
    expect(bins.status).toBe(200);
    expect(bins.body.bins.length).toBeGreaterThan(0);
    const other = await json(await b.GET(call("/api/wms/bins?locationCode=WEST", "GET", s) as any));
    expect(other.status).toBe(403);
  });
});

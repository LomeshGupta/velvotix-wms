import { describe, expect, it } from "vitest";
import { errorResponse } from "@/lib/security/route";
import { submitWmsOperation } from "@/features/transactions/operations";
import type { Principal } from "@/types/principal";

const principal = { userId: "LOMESH", permissions: ["transactions:submit", "picking:submit"], warehouseCodes: ["MAIN"] } as unknown as Principal;

describe("regression: errors from your live log", () => {
  it("a GatewayError from another bundled copy of the class is still mapped, not 500 INTERNAL", async () => {
    // Simulates Next.js bundling errors.ts twice: same shape, different class identity.
    const foreign = Object.assign(new Error("Business Central: Cannot convert the literal '' to the expected type 'Edm.Date'."), {
      name: "GatewayError", code: "BC_BAD_REQUEST", opts: {}, httpStatus: 400, retryable: false,
    });
    const res = errorResponse(foreign, "corr-12345678");
    expect(res.status).toBe(400);
    expect((await res.json()).error.code).toBe("BC_BAD_REQUEST");
  });

  it("a genuinely unknown error is still INTERNAL and leaks nothing", async () => {
    const res = errorResponse(new Error("secret internals"), "corr-12345678");
    expect(res.status).toBe(500);
    expect(JSON.stringify(await res.json())).not.toContain("secret internals");
  });

  it("never sends an empty string for the Edm.Date expirationDate", async () => {
    let sent: any;
    const gateway = { create: async (_k: string, body: unknown) => { sent = body; return { body: { id: "t1", status: "Submitted" }, duplicate: false }; } } as any;
    await submitWmsOperation(gateway, principal, {
      clientKey: crypto.randomUUID(), operationType: "Pick", locationCode: "MAIN", sourceDocumentNo: "WS-1001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }, { itemNo: "1100", quantity: 1, sourceLineNo: 20000, expirationDate: "2027-01-31" }],
    } as any, "corr-12345678");
    expect(sent.lines[0]).not.toHaveProperty("expirationDate");
    expect(sent.lines[1].expirationDate).toBe("2027-01-31");
    expect(JSON.stringify(sent)).not.toContain('"expirationDate":""');
  });
});

import { describe, expect, it } from "vitest";
import { call, login } from "./helpers";
import { documentNoun, isInventoryPutawayLocation, remainingLabel, resolveDocKind, sourceDocumentTypeFor, toWorkDoc, toWorkLine } from "@/features/documents/kinds";
import { expandPermissions } from "@/lib/security/permission-catalog";

const key = () => crypto.randomUUID();
const json = async (r: Response) => ({ status: r.status, body: await r.json() });
const ops = () => import("@/app/api/wms/operations/route");
const docs = () => import("@/app/api/wms/work-docs/route");
const get = async (s: any, path: string) => json(await (await docs()).GET(call(path, "GET", s) as any));

describe("document kinds (pure)", () => {
  const main = { code: "MAIN", requireReceive: true, requirePutaway: true, requirePick: true, requireShipment: true, binMandatory: true, directedPutawayAndPick: false };
  const basic = { ...main, code: "EAST", requireReceive: false, requirePutaway: false, requirePick: false, requireShipment: false, binMandatory: false };
  it("inbound follows the location: receipt when it requires receive, purchase order otherwise", () => {
    expect(resolveDocKind("inbound", main)).toBe("receipt");
    expect(resolveDocKind("inbound", basic)).toBe("purchase");
    expect(resolveDocKind("inbound", undefined)).toBe("receipt");
    expect(resolveDocKind("putaway", main)).toBe("putaway");
    expect(resolveDocKind("shipment", main)).toBe("shipment");
  });
  it("detects an inventory put-away location (put-away without receipt)", () => {
    expect(isInventoryPutawayLocation({ ...basic, requirePutaway: true })).toBe(true);
    expect(isInventoryPutawayLocation(main)).toBe(false);
    expect(isInventoryPutawayLocation(basic)).toBe(false);
  });
  it("source document types match what the AL handlers expect", () => {
    expect(sourceDocumentTypeFor("receipt", "x")).toBe("Warehouse Receipt");
    expect(sourceDocumentTypeFor("purchase", "x")).toBe("Purchase Order");
    expect(sourceDocumentTypeFor("putaway", "x")).toBe("Put-away");
    expect(sourceDocumentTypeFor("shipment", "Warehouse Shipment")).toBe("Warehouse Shipment");
  });
  it("remaining quantities come from BC's own outstanding fields", () => {
    expect(toWorkLine("receipt", "Receipt", { id: "1", lineNo: 10000, itemNo: "1000", qtyOutstanding: 4, qtyReceived: 6 }).remaining).toBe(4);
    expect(toWorkLine("purchase", "Receipt", { id: "1", lineNo: 10000, itemNo: "1000", outstandingQuantity: 5 }).remaining).toBe(5);
    expect(toWorkLine("putaway", "Put-away", { id: "1", lineNo: 20000, itemNo: "1100", qtyOutstanding: 2, binCode: "A-02" })).toMatchObject({ remaining: 2, binCode: "A-02" });
    expect(toWorkLine("receipt", "Receipt", { id: "1", lineNo: 1, itemNo: "x", qtyOutstanding: -1 }).remaining).toBe(0);
  });
  it("labels and nouns", () => {
    expect(remainingLabel("Receipt")).toBe("To receive");
    expect(remainingLabel("Put-away")).toBe("To put away");
    expect(documentNoun("receipt")).toBe("warehouse receipt");
    expect(toWorkDoc("purchase", { id: "1", number: "PO-1", status: "Released", vendorName: "Fabrikam" })).toMatchObject({ number: "PO-1", documentStatus: "Released", externalDocumentNo: "Fabrikam" });
  });
});

describe("inbound API (mock Business Central)", () => {
  it("location setup tells the screen which standard process applies", async () => {
    const s = await login("RECEIVER", "Operator!2026");
    const r = await get(s, "/api/wms/work-docs?kind=location-setup&locationCode=MAIN");
    expect(r.status).toBe(200);
    expect(r.body.rows[0]).toMatchObject({ code: "MAIN", requireReceive: true, requirePutaway: true });
  });

  it("warehouse receipts and their open lines load; a partly received line shows what is left", async () => {
    const s = await login("RECEIVER", "Operator!2026");
    expect((await get(s, "/api/wms/work-docs?kind=receipts&locationCode=MAIN")).body.rows.length).toBeGreaterThan(0);
    const lines = await get(s, "/api/wms/work-docs?kind=receipt-lines&locationCode=MAIN&number=WR-1002");
    const line = toWorkLine("receipt", "Receipt", lines.body.rows[0]);
    expect(line.remaining).toBe(4);
  });

  it("put-aways list and show proposed destination bins", async () => {
    const s = await login("ADMIN", "MockAdmin!2026");
    expect((await get(s, "/api/wms/work-docs?kind=putaways&locationCode=MAIN")).body.rows[0].number).toBe("PA-1001");
    const lines = (await get(s, "/api/wms/work-docs?kind=putaway-lines&locationCode=MAIN&number=PA-1001")).body.rows.map((r: any) => toWorkLine("putaway", "Put-away", r));
    expect(lines.map((l: any) => [l.lineNo, l.binCode, l.remaining])).toEqual([[10000, "A-01", 6], [20000, "A-02", 2]]);
  });

  it("basic location lists only open or released purchase orders and their outstanding lines", async () => {
    const s = await login("ADMIN", "MockAdmin!2026");
    const pos = await get(s, "/api/wms/work-docs?kind=purchase-orders&locationCode=EAST");
    expect(pos.status).toBe(200);
    expect(pos.body.rows.map((r: any) => r.number).sort()).toEqual(["PO-2001", "PO-2002"]); // not Pending Approval
    const lines = (await get(s, "/api/wms/work-docs?kind=purchase-lines&locationCode=EAST&number=PO-2001")).body.rows.map((r: any) => toWorkLine("purchase", "Receipt", r));
    expect(lines.map((l: any) => l.remaining)).toEqual([5, 2]);
  });

  it("is limited to assigned warehouses and to people who may use inbound", async () => {
    const receiver = await login("RECEIVER", "Operator!2026");
    expect((await get(receiver, "/api/wms/work-docs?kind=receipts&locationCode=EAST")).status).toBe(403); // not assigned
    const auditor = await login("AUDITOR", "Auditor!2026");
    expect([200, 403]).toContain((await get(auditor, "/api/wms/work-docs?kind=receipts&locationCode=MAIN")).status);
    expect((await get(receiver, "/api/wms/work-docs?kind=receipt-lines&locationCode=MAIN")).status).toBe(400); // number required
    expect((await get(receiver, "/api/wms/work-docs?kind=nope&locationCode=MAIN")).status).toBe(400);
  });

  it("receiver submits a partial receipt through the operations route (scan allocation, no line ref)", async () => {
    const s = await login("RECEIVER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Receipt", locationCode: "MAIN", sourceDocumentType: "Warehouse Receipt", sourceDocumentNo: "WR-1001",
      lines: [{ itemNo: "1000", quantity: 3 }],
    }) as any));
    expect(r.status).toBe(202);
  });

  it("receipt needs a document; put-away needs the put-away and its line", async () => {
    const s = await login("ADMIN", "MockAdmin!2026");
    const { POST } = await ops();
    const noDoc = await json(await POST(call("/api/wms/operations", "POST", s, { clientKey: key(), operationType: "Receipt", locationCode: "MAIN", lines: [{ itemNo: "1000", quantity: 1 }] }) as any));
    expect(noDoc.status).toBe(400);
    const noLine = await json(await POST(call("/api/wms/operations", "POST", s, { clientKey: key(), operationType: "Put-away", locationCode: "MAIN", sourceDocumentNo: "PA-1001", lines: [{ itemNo: "1000", quantity: 1, toBinCode: "A-01" }] }) as any));
    expect(noLine.status).toBe(400);
    const dup = await json(await POST(call("/api/wms/operations", "POST", s, { clientKey: key(), operationType: "Put-away", locationCode: "MAIN", sourceDocumentNo: "PA-1001", lines: [{ itemNo: "1000", quantity: 1, toBinCode: "A-01", sourceLineNo: 10000 }, { itemNo: "1000", quantity: 1, toBinCode: "A-02", sourceLineNo: 10000 }] }) as any));
    expect(dup.status).toBe(400);
  });

  it("put-away with a changed destination bin and partial quantity is accepted", async () => {
    const s = await login("ADMIN", "MockAdmin!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, {
      clientKey: key(), operationType: "Put-away", locationCode: "MAIN", sourceDocumentType: "Put-away", sourceDocumentNo: "PA-1001",
      lines: [{ itemNo: "1000", quantity: 4, toBinCode: "A-02", sourceLineNo: 10000 }],
    }) as any));
    expect(r.status).toBe(202);
  });

  it("a user without receiving permission is refused and told which permission is missing", async () => {
    const s = await login("PICKER", "Operator!2026");
    const { POST } = await ops();
    const r = await json(await POST(call("/api/wms/operations", "POST", s, { clientKey: key(), operationType: "Receipt", locationCode: "MAIN", sourceDocumentNo: "WR-1001", lines: [{ itemNo: "1000", quantity: 1 }] }) as any));
    expect(r.status).toBe(403);
    expect(JSON.stringify(r.body)).toContain("receiving:submit");
  });

  it("legacy receiving / put-away permission names still work", () => {
    expect(expandPermissions(["RECEIVING:REGISTER", "PUTAWAY:REGISTER", "OPERATIONS:SUBMIT"])).toEqual(expect.arrayContaining(["receiving:submit", "putaway:submit", "transactions:submit"]));
  });
});

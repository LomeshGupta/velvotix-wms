import { describe, expect, it } from "vitest";
import { call, login } from "./helpers";
import { quantityFloor, quantityIsValid, quantityLabel, quantityMode } from "@/features/transactions/quantity-rules";
import { WmsOperationInput } from "@/features/transactions/schema";
import { resolveDocKind, sourceDocumentTypeFor, toWorkDoc, toWorkLine } from "@/features/documents/kinds";

const key = () => crypto.randomUUID();
const json = async (r: Response) => ({ status: r.status, body: await r.json() });
const ops = () => import("@/app/api/wms/operations/route");
const docs = () => import("@/app/api/wms/work-docs/route");
const base = { clientKey: key(), locationCode: "MAIN" };
const ok = (v: unknown) => WmsOperationInput.safeParse(v).success;

describe("quantity meaning per operation", () => {
  it("modes", () => {
    expect(quantityMode("Adjustment")).toBe("signed");
    expect(quantityMode("Cycle Count")).toBe("counted");
    for (const t of ["Movement", "Receipt", "Pick", "Return", "Quality Inspection"]) expect(quantityMode(t)).toBe("positive");
  });
  it("validity", () => {
    expect(quantityIsValid("positive", 0)).toBe(false);
    expect(quantityIsValid("positive", 1)).toBe(true);
    expect(quantityIsValid("signed", -3)).toBe(true);
    expect(quantityIsValid("signed", 0)).toBe(false);
    expect(quantityIsValid("counted", 0)).toBe(true);
    expect(quantityIsValid("counted", -1)).toBe(false);
    expect(quantityIsValid("counted", NaN)).toBe(false);
  });
  it("stepper floor and label", () => {
    expect(quantityFloor("positive")).toBe(1);
    expect(quantityFloor("counted")).toBe(0);
    expect(quantityFloor("signed")).toBeUndefined();
    expect(quantityLabel("Cycle Count")).toBe("Counted");
    expect(quantityLabel("Adjustment")).toBe("+/- Qty");
  });
});

describe("schema rules per module", () => {
  it("adjustment: signed quantity with a reason; 0 and missing reason rejected", () => {
    expect(ok({ ...base, operationType: "Adjustment", reasonCode: "DAMAGE", lines: [{ itemNo: "1000", quantity: -2, fromBinCode: "A-01" }] })).toBe(true);
    expect(ok({ ...base, operationType: "Adjustment", reasonCode: "FOUND", lines: [{ itemNo: "1000", quantity: 5, toBinCode: "A-01" }] })).toBe(true);
    expect(ok({ ...base, operationType: "Adjustment", reasonCode: "DAMAGE", lines: [{ itemNo: "1000", quantity: 0 }] })).toBe(false);
    expect(ok({ ...base, operationType: "Adjustment", lines: [{ itemNo: "1000", quantity: 1 }] })).toBe(false);
  });
  it("cycle count: counted quantity, 0 allowed, negative not", () => {
    expect(ok({ ...base, operationType: "Cycle Count", lines: [{ itemNo: "1000", quantity: 0, fromBinCode: "A-01" }] })).toBe(true);
    expect(ok({ ...base, operationType: "Cycle Count", lines: [{ itemNo: "1000", quantity: 12 }] })).toBe(true);
    expect(ok({ ...base, operationType: "Cycle Count", lines: [{ itemNo: "1000", quantity: -1 }] })).toBe(false);
  });
  it("other operations still need a positive quantity", () => {
    for (const operationType of ["Movement", "Pick", "Receipt"]) {
      expect(ok({ ...base, operationType, sourceDocumentNo: "X1", destinationLocationCode: "EAST", lines: [{ itemNo: "1000", quantity: 0, sourceLineNo: 10000, fromBinCode: "A", toBinCode: "B" }] })).toBe(false);
      expect(ok({ ...base, operationType, sourceDocumentNo: "X1", destinationLocationCode: "EAST", lines: [{ itemNo: "1000", quantity: -1, sourceLineNo: 10000, fromBinCode: "A", toBinCode: "B" }] })).toBe(false);
    }
  });
  it("movement: bins on both sides, unless moving to another warehouse (AL checks each location's setup)", () => {
    expect(ok({ ...base, operationType: "Movement", lines: [{ itemNo: "1000", quantity: 1, fromBinCode: "A-01", toBinCode: "A-02" }] })).toBe(true);
    expect(ok({ ...base, operationType: "Movement", lines: [{ itemNo: "1000", quantity: 1, fromBinCode: "A-01" }] })).toBe(false);
    expect(ok({ ...base, operationType: "Movement", destinationLocationCode: "EAST", lines: [{ itemNo: "1000", quantity: 1 }] })).toBe(true);
  });
  it("quality: result must be PASS/HOLD/REJECT; HOLD/REJECT need the quarantine bin", () => {
    expect(ok({ ...base, operationType: "Quality Inspection", reasonCode: "PASS", lines: [{ itemNo: "1000", quantity: 2 }] })).toBe(true);
    expect(ok({ ...base, operationType: "Quality Inspection", reasonCode: "HOLD", lines: [{ itemNo: "1000", quantity: 2, fromBinCode: "RECEIVE", toBinCode: "QUAR" }] })).toBe(true);
    expect(ok({ ...base, operationType: "Quality Inspection", reasonCode: "REJECT", lines: [{ itemNo: "1000", quantity: 2, fromBinCode: "RECEIVE" }] })).toBe(false);
    expect(ok({ ...base, operationType: "Quality Inspection", reasonCode: "MAYBE", lines: [{ itemNo: "1000", quantity: 2, toBinCode: "QUAR" }] })).toBe(false);
    expect(ok({ ...base, operationType: "Quality Inspection", lines: [{ itemNo: "1000", quantity: 2 }] })).toBe(false);
  });
  it("return needs the sales return order", () => {
    expect(ok({ ...base, operationType: "Return", sourceDocumentType: "Sales Return Order", sourceDocumentNo: "SRO-3001", lines: [{ itemNo: "1000", quantity: 1, sourceLineNo: 10000 }] })).toBe(true);
    expect(ok({ ...base, operationType: "Return", lines: [{ itemNo: "1000", quantity: 1 }] })).toBe(false);
  });
});

describe("return documents", () => {
  it("kind resolution and document type", () => {
    expect(resolveDocKind("return", undefined)).toBe("return");
    expect(sourceDocumentTypeFor("return", "x")).toBe("Sales Return Order");
    expect(toWorkDoc("return", { id: "1", number: "SRO-1", status: "Released", customerName: "Adatum" })).toMatchObject({ documentStatus: "Released", externalDocumentNo: "Adatum" });
    expect(toWorkLine("return", "Return", { id: "1", lineNo: 10000, itemNo: "1000", outstandingQuantity: 3 }).remaining).toBe(3);
  });
  it("open return orders and their outstanding lines load for an assigned warehouse", async () => {
    const s = await login("ADMIN", "MockAdmin!2026");
    const g = (await docs()).GET;
    const orders = await json(await g(call("/api/wms/work-docs?kind=return-orders&locationCode=MAIN", "GET", s) as any));
    expect(orders.status).toBe(200);
    expect(orders.body.rows.map((r: any) => r.number)).toEqual(["SRO-3001"]);
    const lines = await json(await g(call("/api/wms/work-docs?kind=return-lines&locationCode=MAIN&number=SRO-3001", "GET", s) as any));
    expect(toWorkLine("return", "Return", lines.body.rows[0]).remaining).toBe(3);
  });
});

describe("module operations through the API (mock BC)", () => {
  const submit = async (user: [string, string], body: Record<string, unknown>) => {
    const s = await login(user[0], user[1]);
    const { POST } = await ops();
    return json(await POST(call("/api/wms/operations", "POST", s, { clientKey: key(), locationCode: "MAIN", ...body }) as any));
  };
  const admin: [string, string] = ["ADMIN", "MockAdmin!2026"];

  it("admin can submit every module operation", async () => {
    const cases: Record<string, unknown>[] = [
      { operationType: "Movement", lines: [{ itemNo: "1000", quantity: 2, fromBinCode: "A-01", toBinCode: "A-02" }] },
      { operationType: "Adjustment", reasonCode: "DAMAGE", lines: [{ itemNo: "1000", quantity: -1, fromBinCode: "A-01" }] },
      { operationType: "Cycle Count", lines: [{ itemNo: "1000", quantity: 0, fromBinCode: "A-01" }] },
      { operationType: "Return", sourceDocumentType: "Sales Return Order", sourceDocumentNo: "SRO-3001", lines: [{ itemNo: "1000", quantity: 2, sourceLineNo: 10000 }] },
      { operationType: "Quality Inspection", reasonCode: "HOLD", lines: [{ itemNo: "1000", quantity: 1, fromBinCode: "A-01", toBinCode: "QUAR" }] },
    ];
    for (const c of cases) expect((await submit(admin, c)).status, String(c.operationType)).toBe(202);
  });

  it("each module is refused for a read-only user", async () => {
    const picker: [string, string] = ["AUDITOR", "Auditor!2026"]; // read-only user: holds none of these
    const need: Record<string, string> = { Movement: "movements:submit", Adjustment: "inventory:adjust", "Cycle Count": "cyclecounts:submit", Return: "returns:submit", "Quality Inspection": "quality:submit" };
    for (const [operationType, perm] of Object.entries(need)) {
      const r = await submit(picker, {
        operationType, reasonCode: operationType === "Quality Inspection" ? "PASS" : "X", sourceDocumentNo: "SRO-3001",
        lines: [{ itemNo: "1000", quantity: 1, fromBinCode: "A-01", toBinCode: "A-02", sourceLineNo: 10000 }],
      });
      expect(r.status, operationType).toBe(403);
      expect(JSON.stringify(r.body)).toMatch(new RegExp(`${perm}|not allowed to submit`)); // the base submit right is checked first
    }
  });

  it("moving to another warehouse needs assignment there", async () => {
    const r = await submit(["PICKER", "Operator!2026"], { operationType: "Movement", destinationLocationCode: "WEST", lines: [{ itemNo: "1000", quantity: 1, fromBinCode: "A-01", toBinCode: "A-02" }] });
    expect([403]).toContain(r.status);
  });
});

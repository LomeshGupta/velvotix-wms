import "server-only";
import { z } from "zod";
import type { BcGateway } from "@/lib/business-central/client";
import type { Coordinator } from "@/lib/business-central/coordinator";
import { SYSTEM_PRINCIPAL } from "@/types/principal";
import type { UserDirectory, UserProfile, UserStatus } from "./user-directory";

const AuthUserRow = z.object({
  id: z.string().uuid(),
  userId: z.string(),
  displayName: z.string().default(""),
  status: z.enum(["Active", "Suspended", "Deactivated"]),
  mustChangePassword: z.boolean().default(false),
  failedLoginAttempts: z.number().default(0),
  lockedUntil: z.string().nullable().optional(),
});

const sys = { principal: SYSTEM_PRINCIPAL };
const PROFILE_TTL_MS = 30_000;
const ROLE_CATALOG_TTL_MS = 30_000;
const ROLE_CATALOG_CACHE_KEY = "wms:role-catalog:v2";

type RoleCatalog = { activeRoleCodes: string[]; roleNames: Record<string, string>; permissionsByRole: Record<string, string[]> };

/** UserDirectory backed by the VWMS User tables, through the gateway's system-only operations. */
export class BcUserDirectory implements UserDirectory {
  constructor(
    private readonly gateway: BcGateway,
    private readonly coordinator: Coordinator,
  ) {}

  private async loadUser(userId: string) {
    const r = await this.gateway.read<Record<string, unknown>>(
      "authUsers.get",
      { select: ["id", "userId", "displayName", "status", "mustChangePassword", "failedLoginAttempts", "lockedUntil", "lastLoginAt", "defaultLocationCode"], filter: [{ field: "userId", op: "eq", value: userId.trim().toUpperCase() }], top: 1 },
      sys,
    );
    const row = r.rows[0];
    return row ? AuthUserRow.parse(row) : undefined;
  }

  private async loadRoleCatalog(): Promise<RoleCatalog> {
    const cached = await this.coordinator.cacheGet(ROLE_CATALOG_CACHE_KEY).catch(() => null);
    if (cached) {
      try { return JSON.parse(cached) as RoleCatalog; } catch { /* discard a malformed cache entry */ }
    }

    const [roles, rolePermissions] = await Promise.all([
      this.gateway.read<{ roleCode: string; roleName: string; enabled: boolean }>("roles.list", {}, sys),
      this.gateway.read<{ roleCode: string; permissionCode: string }>("rolePermissions.list", {}, sys),
    ]);
    const enabledRoles = roles.rows.filter((r) => r.enabled === true || String(r.enabled).toLowerCase() === "true");
    const activeRoleCodes = enabledRoles.map((r) => String(r.roleCode).toUpperCase());
    const roleNames = Object.fromEntries(enabledRoles.map((r) => [String(r.roleCode).toUpperCase(), String(r.roleName || r.roleCode)]));
    const active = new Set(activeRoleCodes);
    const permissionsByRole: Record<string, string[]> = {};
    for (const row of rolePermissions.rows) {
      const roleCode = String(row.roleCode).toUpperCase();
      if (!active.has(roleCode)) continue;
      (permissionsByRole[roleCode] ??= []).push(String(row.permissionCode).toLowerCase());
    }
    const catalog = { activeRoleCodes, roleNames, permissionsByRole };
    await this.coordinator.cacheSet(ROLE_CATALOG_CACHE_KEY, JSON.stringify(catalog), ROLE_CATALOG_TTL_MS).catch(() => undefined);
    return catalog;
  }

  private async loadAssignments(userId: string): Promise<{ warehouses: string[]; permissions: string[]; roles: string[] }> {
    const [w, direct, userRoles, catalog] = await Promise.all([
      this.gateway.read<{ locationCode: string }>("userWarehouses.list", { filter: [{ field: "userId", op: "eq", value: userId }] }, sys),
      this.gateway.read<{ permissionCode: string }>("userPermissions.list", { filter: [{ field: "userId", op: "eq", value: userId }] }, sys),
      this.gateway.read<{ roleCode: string }>("userRoles.list", { filter: [{ field: "userId", op: "eq", value: userId }] }, sys),
      this.loadRoleCatalog(),
    ]);
    const activeRoleCodes = new Set(catalog.activeRoleCodes);
    const assignedRoleCodes = new Set(
      userRoles.rows.map((r) => String(r.roleCode).toUpperCase()).filter((code) => activeRoleCodes.has(code)),
    );
    const permissions = new Set(direct.rows.map((r) => String(r.permissionCode).toLowerCase()));
    // Only enabled roles assigned to this user can contribute effective permissions.
    for (const roleCode of assignedRoleCodes) {
      for (const permission of catalog.permissionsByRole[roleCode] ?? []) permissions.add(permission);
    }
    return {
      warehouses: w.rows.map((r) => String(r.locationCode).toUpperCase()),
      roles: [...assignedRoleCodes].map((code) => catalog.roleNames[code] ?? code),
      // BC upper-cases Code fields; WMS permission strings are normalized to lower-case.
      permissions: [...permissions],
    };
  }

  /**
   * Live credentials are verified inside Business Central. The stored password hash never
   * crosses the API boundary; only a successful authentication result leads to profile reads.
   */
  async authenticate(userId: string, password: string): Promise<UserProfile | undefined> {
    const result = await this.gateway.invoke<{ success?: boolean; userId?: string }>(
      "auth.login",
      { userId: userId.trim().toUpperCase(), password },
      sys,
    );
    if (!result || result.success !== true) return undefined;

    const canonicalUserId = String(result.userId ?? userId).trim().toUpperCase();
    const user = await this.loadUser(canonicalUserId);
    if (!user || user.status !== "Active") return undefined;
    const assignments = await this.loadAssignments(user.userId);
    return {
      userId: user.userId,
      displayName: user.displayName,
      roles: assignments.roles,
      status: user.status as UserStatus,
      permissions: assignments.permissions,
      warehouseCodes: assignments.warehouses,
      mustChangePassword: user.mustChangePassword,
    };
  }

  async findProfile(userId: string): Promise<UserProfile | undefined> {
    const key = `prof:${userId.toUpperCase()}`;
    const cached = await this.coordinator.cacheGet(key).catch(() => null);
    if (cached) return JSON.parse(cached) as UserProfile;

    const u = await this.loadUser(userId);
    if (!u) return undefined;
    const a = await this.loadAssignments(u.userId);
    const profile: UserProfile = {
      userId: u.userId,
      displayName: u.displayName,
      roles: a.roles,
      status: u.status as UserStatus,
      permissions: a.permissions,
      warehouseCodes: a.warehouses,
      mustChangePassword: u.mustChangePassword,
    };
    // Profile only: the password hash is never written to the cache.
    await this.coordinator.cacheSet(key, JSON.stringify(profile), PROFILE_TTL_MS).catch(() => undefined);
    return profile;
  }


}

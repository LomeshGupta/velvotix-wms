"use client";
import { useSessionStore } from "@/store/uiStore";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly retryAfterMs?: number,
    public readonly correlationId?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
  get retryable(): boolean {
    return this.status === 429 || this.status === 503;
  }
}

/** Plain-language messages for the codes the server can return. Raw server text is never shown. */
const FRIENDLY: Record<string, string> = {
  QUEUE_FULL: "The system is busy. Try again in a moment.",
  RATE_LIMITED: "Too many requests. Wait a few seconds and try again.",
  CIRCUIT_OPEN: "Business Central is temporarily unavailable. Try again shortly.",
  TIMEOUT: "Business Central took too long to respond.",
  NETWORK: "Could not reach Business Central. Check the connection and try again.",
  OUTCOME_UNKNOWN: "We could not confirm the result. Check the transaction list before retrying.",
  UNAUTHENTICATED: "Your session has ended. Sign in again.",
  FORBIDDEN: "You do not have permission for this action.",
  ENDPOINT_NOT_ALLOWED: "You do not have access to this location or action.",
  CSRF: "Your session could not be verified. Reload the page and try again.",
  ITEM_NOT_FOUND: "No item matches this code.",
  BC_CONFLICT: "This receipt was already submitted with different contents. Start a new receipt.",
  VALIDATION: "Some details are missing or not valid.",
};

export function friendlyMessage(e: unknown): string {
  if (e instanceof ApiError) return FRIENDLY[e.code] ?? "Something went wrong. Try again, and contact an administrator if it continues.";
  return "Something went wrong. Check your connection and try again.";
}

export async function apiFetch<T>(path: string, init: { method?: "GET" | "POST"; body?: unknown; signal?: AbortSignal } = {}): Promise<T> {
  const method = init.method ?? "GET";
  const headers: Record<string, string> = { Accept: "application/json" };
  if (init.body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET") {
    const csrf = useSessionStore.getState().csrfToken;
    if (csrf) headers["x-csrf-token"] = csrf;
  }
  let res: Response;
  try {
    res = await fetch(path, { method, headers, body: init.body !== undefined ? JSON.stringify(init.body) : undefined, signal: init.signal, credentials: "same-origin" });
  } catch (e) {
    if (e instanceof DOMException && e.name === "AbortError") throw e;
    throw new ApiError(0, "NETWORK", "Network error");
  }
  if (res.ok) return (await res.json()) as T;

  const payload = (await res.json().catch(() => ({}))) as { error?: { code?: string; message?: string; correlationId?: string } };
  const code = payload.error?.code ?? "ERROR";
  if (res.status === 401 && typeof window !== "undefined" && !window.location.pathname.startsWith("/login")) {
    window.location.assign(`/login?next=${encodeURIComponent(window.location.pathname)}`);
  }
  const ra = Number(res.headers.get("retry-after"));
  throw new ApiError(res.status, code, payload.error?.message ?? "Request failed", Number.isFinite(ra) && ra > 0 ? ra * 1000 : undefined, payload.error?.correlationId);
}

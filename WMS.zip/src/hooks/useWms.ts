"use client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiFetch, ApiError } from "@/lib/api-client";

export interface TransactionRow {
  id: string;
  operationType: string;
  status: string;
  locationCode: string;
  destinationLocationCode?: string;
  wmsUserId?: string;
  attemptCount?: number;
  errorCode?: string;
  errorMessage?: string;
  resultDocumentNo?: string;
  sourceDocumentNo?: string;
  requestedAt?: string;
  completedAt?: string | null;
}

export interface DashboardData {
  generatedAt: string;
  maxAgeSeconds: number;
  source: string;
  sampleSize: number;
  sampleLimit: number;
  counts: Record<string, number>;
  byType: Record<string, number>;
  oldestWaitingMs: number;
  recent: TransactionRow[];
}

const jitter = (ms: number) => Math.round(ms * (0.85 + Math.random() * 0.3));

/** Retry only what is worth retrying, honouring the server's Retry-After. Never retry auth or validation errors. */
const retryPolicy = (count: number, e: unknown) => count < 2 && e instanceof ApiError && e.retryable;

export const useDashboard = () =>
  useQuery({
    queryKey: ["dashboard"],
    queryFn: ({ signal }) => apiFetch<DashboardData>("/api/wms/dashboard", { signal }),
    staleTime: 20_000,
    // Refresh while the tab is visible, with jitter so devices do not hit the server in lockstep.
    refetchInterval: () => jitter(45_000),
    refetchIntervalInBackground: false,
    retry: retryPolicy,
  });

export const useTransactions = (status?: string) =>
  useQuery({
    queryKey: ["transactions", status ?? "all"],
    queryFn: ({ signal }) => apiFetch<{ transactions: TransactionRow[] }>(`/api/wms/transactions?top=100${status ? `&status=${encodeURIComponent(status)}` : ""}`, { signal }),
    staleTime: 15_000,
    retry: retryPolicy,
  });

const TERMINAL = new Set(["Completed", "Failed", "Cancelled", "Requires Reconciliation", "Partially Completed"]);
export const isTerminal = (status: string | undefined) => Boolean(status && TERMINAL.has(status));

/** Tracks one transaction until it is final. Polling slows down the longer it takes. */
export const useTransaction = (id: string | null) =>
  useQuery({
    queryKey: ["transaction", id],
    enabled: Boolean(id),
    queryFn: ({ signal }) => apiFetch<{ transaction: TransactionRow }>(`/api/wms/transactions/${id}`, { signal }),
    refetchInterval: (q) => {
      if (isTerminal(q.state.data?.transaction.status)) return false;
      const n = q.state.dataUpdateCount;
      return jitter(Math.min(8000, 1500 + n * 700));
    },
    retry: retryPolicy,
  });

export interface WarehouseShipmentHit {
  id: string;
  number: string;
  locationCode: string;
  shipmentDate?: string;
  assignedUserId?: string;
  documentStatus?: string;
  status?: string;
  externalDocumentNo?: string;
}

export const useWarehouseShipments = (locationCode: string) =>
  useQuery({
    queryKey: ["warehouse-shipments", locationCode],
    enabled: Boolean(locationCode),
    queryFn: ({ signal }) => apiFetch<{ shipments: WarehouseShipmentHit[] }>(`/api/wms/shipments?locationCode=${encodeURIComponent(locationCode)}`, { signal }),
    staleTime: 15_000,
    retry: retryPolicy,
  });

export interface WarehouseShipmentLineHit {
  id: string;
  documentNo: string;
  lineNo: number;
  locationCode: string;
  itemNo: string;
  description: string;
  quantity: number;
  qtyToShip: number;
  qtyOutstanding: number;
  qtyPicked: number;
  unitOfMeasureCode: string;
  binCode?: string;
  sourceNo?: string;
  sourceLineNo?: number;
  status?: string;
}

export const useWarehouseShipmentLines = (locationCode: string, number: string, enabled: boolean) =>
  useQuery({
    queryKey: ["warehouse-shipment-lines", locationCode, number],
    enabled: Boolean(locationCode && number && enabled),
    queryFn: ({ signal }) => apiFetch<{ lines: WarehouseShipmentLineHit[] }>(`/api/wms/shipment-lines?locationCode=${encodeURIComponent(locationCode)}&number=${encodeURIComponent(number)}`, { signal }),
    staleTime: 15_000,
    retry: retryPolicy,
  });

export interface ItemHit { number: string; displayName: string; baseUnitOfMeasureCode: string; blocked: boolean; gtin?: string; inventory?: number }

export const useItemLookup = () =>
  useMutation({ mutationFn: (code: string) => apiFetch<{ item: ItemHit }>(`/api/wms/items/lookup?code=${encodeURIComponent(code)}`) });

export const useItemSearch = (search: string) =>
  useQuery({
    queryKey: ["items", search],
    queryFn: ({ signal }) => apiFetch<{ items: ItemHit[] }>(`/api/wms/items?top=50${search ? `&search=${encodeURIComponent(search)}` : ""}`, { signal }),
    staleTime: 60_000,
    retry: retryPolicy,
  });

export interface ReceiptPayload {
  clientKey: string;
  locationCode: string;
  sourceDocumentNo?: string;
  lines: { itemNo: string; quantity: number; unitOfMeasureCode?: string; lotNo?: string }[];
}

export const useSubmitReceipt = () =>
  useMutation({
    mutationFn: (p: ReceiptPayload) => apiFetch<{ transactionId: string; status: string; duplicate: boolean }>("/api/wms/receiving", { method: "POST", body: p }),
  });


export type WmsOperationType = "Put-away" | "Movement" | "Pick" | "Pack" | "Ship" | "Cycle Count" | "Adjustment" | "Return" | "Quality Inspection";
export interface WmsOperationPayload {
  clientKey: string;
  operationType: WmsOperationType;
  locationCode: string;
  destinationLocationCode?: string;
  sourceDocumentType?: string;
  sourceDocumentNo?: string;
  reasonCode?: string;
  lines: {
    itemNo: string;
    quantity: number;
    unitOfMeasureCode?: string;
    fromBinCode?: string;
    toBinCode?: string;
    lotNo?: string;
    serialNo?: string;
    expirationDate?: string;
    sourceLineNo?: number;
    reasonCode?: string;
  }[];
}

export const useSubmitOperation = () =>
  useMutation({
    mutationFn: (p: WmsOperationPayload) => apiFetch<{ transactionId: string; status: string; duplicate: boolean }>("/api/wms/operations", { method: "POST", body: p }),
  });

export interface MonitorData {
  generatedAt: string;
  mode: string;
  environment: string;
  redis: string;
  scheduler: { breaker: string; active: Record<string, number>; queued: Record<string, number>; oldestQueuedMs: number; coordinator: string };
  limits: Record<string, number>;
  metrics: { lastSuccessAt?: number; authFailures: number; operations: Record<string, { count: number; errors: number; throttled: number; cacheHits: number; deduped: number; p50: number; p95: number; p99: number; queueWaitP95: number }> };
}

export const useMonitor = () =>
  useQuery({
    queryKey: ["monitor"],
    queryFn: ({ signal }) => apiFetch<MonitorData>("/api/wms/admin/monitor", { signal }),
    refetchInterval: () => jitter(15_000),
    refetchIntervalInBackground: false,
    retry: retryPolicy,
  });

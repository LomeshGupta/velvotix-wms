"use client";
import DarkMode from "@mui/icons-material/DarkMode";
import Inventory2Outlined from "@mui/icons-material/Inventory2Outlined";
import FactCheck from "@mui/icons-material/FactCheck";
import ShoppingCartCheckout from "@mui/icons-material/ShoppingCartCheckout";
import Inventory from "@mui/icons-material/Inventory";
import LocalShipping from "@mui/icons-material/LocalShipping";
import Menu from "@mui/icons-material/Menu";
import MoveDown from "@mui/icons-material/MoveDown";
import Package2 from "@mui/icons-material/Inventory2";
import PlaylistAddCheck from "@mui/icons-material/PlaylistAddCheck";
import SwapHoriz from "@mui/icons-material/SwapHoriz";
import Undo from "@mui/icons-material/Undo";
import Close from "@mui/icons-material/Close";
import LightMode from "@mui/icons-material/LightMode";
import ListAlt from "@mui/icons-material/ListAlt";
import Logout from "@mui/icons-material/Logout";
import MonitorHeart from "@mui/icons-material/MonitorHeart";
import ManageAccounts from "@mui/icons-material/ManageAccounts";
import MoveToInbox from "@mui/icons-material/MoveToInbox";
import SpaceDashboard from "@mui/icons-material/SpaceDashboard";
import Alert from "@mui/material/Alert";
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import Stack from "@mui/material/Stack";
import { useColorScheme } from "@mui/material/styles";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { NetworkStatus } from "./NetworkStatus";
import { apiFetch } from "@/lib/api-client";
import { useDraftStore, useSessionStore } from "@/store/uiStore";

export interface ShellUser {
  displayName: string;
  userId: string;
  roles: string[];
  permissions: string[];
  warehouseCodes: string[];
}

const NAV = [
  { href: "/dashboard", label: "Control Tower", icon: <SpaceDashboard />, perm: "dashboard:view" },
  { href: "/inbound/receiving", label: "Receiving", icon: <MoveToInbox />, perm: "receiving:submit" },
  { href: "/inbound/putaway", label: "Put-away", icon: <MoveDown />, perm: "putaway:submit" },
  { href: "/inventory/items", label: "Items", icon: <Inventory2Outlined />, perm: "items:view" },
  { href: "/inventory/movements", label: "Movements", icon: <SwapHoriz />, perm: "movements:submit" },
  { href: "/inventory/cycle-count", label: "Cycle Count", icon: <FactCheck />, perm: "cyclecounts:submit" },
  { href: "/inventory/adjustments", label: "Adjustments", icon: <Inventory />, perm: "inventory:adjust" },
  { href: "/outbound/picking", label: "Picking", icon: <ShoppingCartCheckout />, perm: "picking:submit" },
  { href: "/outbound/packing", label: "Packing", icon: <Package2 />, perm: "packing:submit" },
  { href: "/outbound/shipping", label: "Shipping", icon: <LocalShipping />, perm: "shipping:submit" },
  { href: "/returns", label: "Returns", icon: <Undo />, perm: "returns:submit" },
  { href: "/quality/inspection", label: "Quality", icon: <PlaylistAddCheck />, perm: "quality:submit" },
  { href: "/tasks", label: "Transactions", icon: <ListAlt />, perm: "transactions:view" },
  { href: "/administration/users", label: "User Administration", icon: <ManageAccounts />, perm: "administration:administer" },
  { href: "/administration/integration-monitor", label: "Integration Monitor", icon: <MonitorHeart />, perm: "administration:administer" },
] as const;

const RAIL = 232;

export function AppShell({ user, csrfToken, mockMode, children }: { user: ShellUser; csrfToken: string; mockMode: boolean; children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const qc = useQueryClient();
  const { mode, setMode } = useColorScheme();
  const { setCsrfToken, setUserId, selectedLocation, setSelectedLocation, setWarehouseCodes } = useSessionStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    setCsrfToken(csrfToken);
    setUserId(user.userId);
    setWarehouseCodes([...user.warehouseCodes]);
    if (!selectedLocation || !user.warehouseCodes.includes(selectedLocation)) setSelectedLocation(user.warehouseCodes[0] ?? "");
  }, [csrfToken, user.userId, user.warehouseCodes, selectedLocation, setCsrfToken, setUserId, setSelectedLocation, setWarehouseCodes]);

  const items = NAV.filter((n) => user.permissions.includes(n.perm));
  const active = items.find((n) => pathname.startsWith(n.href));

  const logout = async () => {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
    } catch {
      // Complete local sign-out even if the server session was already invalid
      // or the session store is temporarily unavailable. The logout endpoint
      // independently verifies same-origin and clears the session cookie.
    } finally {
      // Clear everything user-specific so the next person on a shared device sees nothing.
      useDraftStore.getState().reset();
      useSessionStore.setState({ csrfToken: null, selectedLocation: null, warehouseCodes: [], userId: null });
      qc.clear();
      router.replace("/login");
    }
  };

  const toggleMode = () => setMode(mode === "dark" ? "light" : "dark");

  const warehouse = user.warehouseCodes.length > 0 && (
    <Select
      size="small"
      value={selectedLocation ?? ""}
      onChange={(e) => setSelectedLocation(String(e.target.value))}
      inputProps={{ "aria-label": "Warehouse" }}
      sx={{ minWidth: 96, "& .MuiSelect-select": { py: 0.75, fontWeight: 600 } }}
    >
      {user.warehouseCodes.map((c) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
    </Select>
  );

  return (
    <Box sx={{ display: "flex", minHeight: "100dvh" }}>
      {/* Layout switches with CSS breakpoints (not JS), so there is no wrong-layout flash before hydration. */}
      <Drawer variant="permanent" sx={{ display: { xs: "none", md: "block" }, width: RAIL, flexShrink: 0, "& .MuiDrawer-paper": { width: RAIL, bgcolor: "ink", color: "#E6EDF3", border: 0 } }}>
          <Box sx={{ px: 2.5, pt: 3, pb: 2 }}>
            <Typography variant="h3" sx={{ color: "#fff", letterSpacing: "-0.01em" }}>Velvotix WMS</Typography>
            <Typography variant="caption" sx={{ color: "#9AA9B7" }}>Warehouse execution</Typography>
          </Box>
          <List component="nav" aria-label="Main" sx={{ px: 1 }}>
            {items.map((n) => (
              <ListItemButton
                key={n.href}
                component={Link}
                href={n.href}
                selected={active?.href === n.href}
                sx={{
                  borderRadius: "2px", mb: 0.25, borderLeft: 4, borderColor: "transparent", py: 1,
                  "&.Mui-selected": { bgcolor: "rgba(255,255,255,.08)", borderColor: "secondary.main" },
                  "&.Mui-selected:hover, &:hover": { bgcolor: "rgba(255,255,255,.12)" },
                }}
              >
                <ListItemIcon sx={{ minWidth: 36, color: "inherit" }}>{n.icon}</ListItemIcon>
                <ListItemText primary={n.label} slotProps={{ primary: { fontWeight: active?.href === n.href ? 600 : 400 } }} />
              </ListItemButton>
            ))}
          </List>
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ p: 2, borderTop: 1, borderColor: "rgba(255,255,255,.12)" }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>{user.displayName}</Typography>
            <Typography variant="caption" sx={{ color: "#9AA9B7" }}>{user.userId}</Typography>
            {user.roles.map((role) => <Typography key={role} variant="caption" sx={{ display: "block", color: "#B9C8D5" }}>{role}</Typography>)}
          </Box>
        </Drawer>

      <Drawer anchor="left" open={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} sx={{ display: { xs: "block", md: "none" }, "& .MuiDrawer-paper": { width: 300, maxWidth: "88vw" } }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ px: 2, py: 2, borderBottom: 1, borderColor: "divider" }}>
          <Box><Typography variant="h3">Velvotix WMS</Typography><Typography variant="caption" color="text.secondary">Role-specific workspace</Typography></Box>
          <IconButton aria-label="Close navigation" onClick={() => setMobileMenuOpen(false)}><Close /></IconButton>
        </Stack>
        <List component="nav" aria-label="All warehouse workspaces" sx={{ px: 1 }}>
          {items.map((n) => (
            <ListItemButton key={n.href} component={Link} href={n.href} selected={active?.href === n.href} onClick={() => setMobileMenuOpen(false)} sx={{ borderRadius: 1, mb: .25 }}>
              <ListItemIcon sx={{ minWidth: 40 }}>{n.icon}</ListItemIcon><ListItemText primary={n.label} />
            </ListItemButton>
          ))}
        </List>
        <Box sx={{ mt: "auto", p: 2, borderTop: 1, borderColor: "divider" }}><Typography fontWeight={600}>{user.displayName}</Typography><Typography variant="caption" color="text.secondary">{user.userId}</Typography>{user.roles.map((role) => <Typography key={role} variant="caption" color="text.secondary" sx={{ display: "block" }}>{role}</Typography>)}</Box>
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, minWidth: 0, display: "flex", flexDirection: "column", pb: { xs: "calc(64px + env(safe-area-inset-bottom, 0px))", md: 0 } }}>
        {mockMode && <Alert severity="warning" icon={false} sx={{ borderRadius: 0, py: 0 }}>Mock mode: data is simulated and nothing is sent to Business Central.</Alert>}
        <Stack direction="row" alignItems="center" spacing={1.5} sx={{ px: { xs: 1, md: 3 }, py: 1, borderBottom: 1, borderColor: "divider", bgcolor: "background.paper", position: "sticky", top: 0, zIndex: 10, pt: "calc(8px + env(safe-area-inset-top, 0px))" }}>
          <IconButton aria-label="Open all warehouse workspaces" onClick={() => setMobileMenuOpen(true)} sx={{ display: { xs: "inline-flex", md: "none" } }}><Menu /></IconButton>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, display: { xs: "block", md: "none" }, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{active?.label ?? "Velvotix WMS"}</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <NetworkStatus />
          {warehouse}
          <Tooltip title={mode === "dark" ? "Switch to light" : "Switch to dark"}>
            <IconButton onClick={toggleMode} aria-label="Toggle colour mode" size="small">{mode === "dark" ? <LightMode /> : <DarkMode />}</IconButton>
          </Tooltip>
          <Tooltip title="Sign out">
            <IconButton onClick={logout} aria-label="Sign out" size="small"><Logout /></IconButton>
          </Tooltip>
        </Stack>
        <Box sx={{ flexGrow: 1, px: { xs: 2, md: 4 }, py: { xs: 2, md: 3 }, maxWidth: 1280, width: "100%", mx: "auto" }}>{children}</Box>
      </Box>

      <BottomNavigation
          component="nav"
          aria-label="Main"
          showLabels
          value={active?.href ?? false}
          sx={{ display: { xs: "flex", md: "none" }, position: "fixed", bottom: 0, left: 0, right: 0, borderTop: 1, borderColor: "divider", height: "calc(64px + env(safe-area-inset-bottom, 0px))", pb: "env(safe-area-inset-bottom, 0px)", zIndex: 20 }}
        >
          {items.filter((n) => ["/dashboard", "/inbound/receiving", "/inventory/items", "/outbound/picking", "/outbound/shipping"].includes(n.href)).slice(0, 5).map((n) => (
            <BottomNavigationAction key={n.href} component={Link} href={n.href} value={n.href} label={n.label} icon={n.icon} sx={{ minWidth: 56, "&.Mui-selected": { color: "primary.main" } }} />
          ))}
        </BottomNavigation>
    </Box>
  );
}
